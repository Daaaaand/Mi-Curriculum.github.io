Estos son mis conocimientos. Gracias por leer y tomarme en cuenta!
