﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FichaMédica
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.BtnGuardar = New System.Windows.Forms.Button()
        Me.BtnEliminar = New System.Windows.Forms.Button()
        Me.BtnModificar = New System.Windows.Forms.Button()
        Me.BtnImprimir = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Cédula = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TxtNombre = New System.Windows.Forms.TextBox()
        Me.TxtApellido = New System.Windows.Forms.TextBox()
        Me.TxtCI = New System.Windows.Forms.TextBox()
        Me.DtmFn = New System.Windows.Forms.DateTimePicker()
        Me.TxtDireccion = New System.Windows.Forms.TextBox()
        Me.TxtTelefono1 = New System.Windows.Forms.TextBox()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.TxtContacto = New System.Windows.Forms.TextBox()
        Me.TxtTelContacto = New System.Windows.Forms.TextBox()
        Me.CbxEspecializacion = New System.Windows.Forms.ComboBox()
        Me.CbxGrado = New System.Windows.Forms.ComboBox()
        Me.TxtProcedencia = New System.Windows.Forms.TextBox()
        Me.TxtTelefono2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CbxFormaHoraria = New System.Windows.Forms.ComboBox()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.RbnFemenino = New System.Windows.Forms.RadioButton()
        Me.RbnMasculino = New System.Windows.Forms.RadioButton()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnCancelar)
        Me.Panel1.Controls.Add(Me.BtnGuardar)
        Me.Panel1.Controls.Add(Me.BtnEliminar)
        Me.Panel1.Controls.Add(Me.BtnModificar)
        Me.Panel1.Controls.Add(Me.BtnImprimir)
        Me.Panel1.Location = New System.Drawing.Point(25, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(732, 63)
        Me.Panel1.TabIndex = 0
        '
        'BtnCancelar
        '
        Me.BtnCancelar.Location = New System.Drawing.Point(437, 19)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelar.TabIndex = 67
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'BtnGuardar
        '
        Me.BtnGuardar.Location = New System.Drawing.Point(24, 19)
        Me.BtnGuardar.Name = "BtnGuardar"
        Me.BtnGuardar.Size = New System.Drawing.Size(75, 23)
        Me.BtnGuardar.TabIndex = 66
        Me.BtnGuardar.Text = "Guardar"
        Me.BtnGuardar.UseVisualStyleBackColor = True
        '
        'BtnEliminar
        '
        Me.BtnEliminar.Location = New System.Drawing.Point(304, 19)
        Me.BtnEliminar.Name = "BtnEliminar"
        Me.BtnEliminar.Size = New System.Drawing.Size(75, 23)
        Me.BtnEliminar.TabIndex = 65
        Me.BtnEliminar.Text = "Eliminar"
        Me.BtnEliminar.UseVisualStyleBackColor = True
        '
        'BtnModificar
        '
        Me.BtnModificar.Location = New System.Drawing.Point(207, 19)
        Me.BtnModificar.Name = "BtnModificar"
        Me.BtnModificar.Size = New System.Drawing.Size(75, 23)
        Me.BtnModificar.TabIndex = 64
        Me.BtnModificar.Text = "Modificar"
        Me.BtnModificar.UseVisualStyleBackColor = True
        '
        'BtnImprimir
        '
        Me.BtnImprimir.Location = New System.Drawing.Point(116, 19)
        Me.BtnImprimir.Name = "BtnImprimir"
        Me.BtnImprimir.Size = New System.Drawing.Size(75, 23)
        Me.BtnImprimir.TabIndex = 63
        Me.BtnImprimir.Text = "Imprimir"
        Me.BtnImprimir.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(22, 115)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Nombres"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label2.Location = New System.Drawing.Point(306, 115)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Apellidos"
        '
        'Cédula
        '
        Me.Cédula.AutoSize = True
        Me.Cédula.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Cédula.Location = New System.Drawing.Point(19, 181)
        Me.Cédula.Name = "Cédula"
        Me.Cédula.Size = New System.Drawing.Size(40, 13)
        Me.Cédula.TabIndex = 24
        Me.Cédula.Text = "Cédula"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label4.Location = New System.Drawing.Point(258, 181)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 13)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Fecha de nacimiento"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label5.Location = New System.Drawing.Point(19, 256)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "Dirección"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label6.Location = New System.Drawing.Point(305, 256)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 27
        Me.Label6.Text = "Teléfono"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label7.Location = New System.Drawing.Point(19, 330)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 13)
        Me.Label7.TabIndex = 28
        Me.Label7.Text = "Email"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label8.Location = New System.Drawing.Point(306, 330)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(105, 13)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "Contacto secundario"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label9.Location = New System.Drawing.Point(594, 330)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(22, 13)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Tel"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label10.Location = New System.Drawing.Point(19, 407)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 13)
        Me.Label10.TabIndex = 31
        Me.Label10.Text = "Especialización"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label11.Location = New System.Drawing.Point(287, 407)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(36, 13)
        Me.Label11.TabIndex = 32
        Me.Label11.Text = "Grado"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label12.Location = New System.Drawing.Point(468, 407)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(102, 13)
        Me.Label12.TabIndex = 33
        Me.Label12.Text = "Procedéncia clínica"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label14.Location = New System.Drawing.Point(19, 486)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(71, 13)
        Me.Label14.TabIndex = 35
        Me.Label14.Text = "Forma horaria"
        '
        'TxtNombre
        '
        Me.TxtNombre.Location = New System.Drawing.Point(87, 112)
        Me.TxtNombre.Name = "TxtNombre"
        Me.TxtNombre.Size = New System.Drawing.Size(198, 20)
        Me.TxtNombre.TabIndex = 36
        '
        'TxtApellido
        '
        Me.TxtApellido.Location = New System.Drawing.Point(370, 112)
        Me.TxtApellido.Name = "TxtApellido"
        Me.TxtApellido.Size = New System.Drawing.Size(200, 20)
        Me.TxtApellido.TabIndex = 37
        '
        'TxtCI
        '
        Me.TxtCI.Location = New System.Drawing.Point(87, 178)
        Me.TxtCI.Name = "TxtCI"
        Me.TxtCI.Size = New System.Drawing.Size(153, 20)
        Me.TxtCI.TabIndex = 38
        '
        'DtmFn
        '
        Me.DtmFn.Location = New System.Drawing.Point(370, 178)
        Me.DtmFn.Name = "DtmFn"
        Me.DtmFn.Size = New System.Drawing.Size(200, 20)
        Me.DtmFn.TabIndex = 40
        '
        'TxtDireccion
        '
        Me.TxtDireccion.Location = New System.Drawing.Point(87, 253)
        Me.TxtDireccion.Name = "TxtDireccion"
        Me.TxtDireccion.Size = New System.Drawing.Size(198, 20)
        Me.TxtDireccion.TabIndex = 41
        '
        'TxtTelefono1
        '
        Me.TxtTelefono1.Location = New System.Drawing.Point(370, 253)
        Me.TxtTelefono1.Name = "TxtTelefono1"
        Me.TxtTelefono1.Size = New System.Drawing.Size(98, 20)
        Me.TxtTelefono1.TabIndex = 42
        '
        'TxtEmail
        '
        Me.TxtEmail.Location = New System.Drawing.Point(87, 327)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(198, 20)
        Me.TxtEmail.TabIndex = 43
        '
        'TxtContacto
        '
        Me.TxtContacto.Location = New System.Drawing.Point(417, 327)
        Me.TxtContacto.Name = "TxtContacto"
        Me.TxtContacto.Size = New System.Drawing.Size(153, 20)
        Me.TxtContacto.TabIndex = 44
        '
        'TxtTelContacto
        '
        Me.TxtTelContacto.Location = New System.Drawing.Point(622, 327)
        Me.TxtTelContacto.Name = "TxtTelContacto"
        Me.TxtTelContacto.Size = New System.Drawing.Size(135, 20)
        Me.TxtTelContacto.TabIndex = 45
        '
        'CbxEspecializacion
        '
        Me.CbxEspecializacion.FormattingEnabled = True
        Me.CbxEspecializacion.Location = New System.Drawing.Point(119, 404)
        Me.CbxEspecializacion.Name = "CbxEspecializacion"
        Me.CbxEspecializacion.Size = New System.Drawing.Size(121, 21)
        Me.CbxEspecializacion.TabIndex = 46
        '
        'CbxGrado
        '
        Me.CbxGrado.FormattingEnabled = True
        Me.CbxGrado.Location = New System.Drawing.Point(329, 404)
        Me.CbxGrado.Name = "CbxGrado"
        Me.CbxGrado.Size = New System.Drawing.Size(121, 21)
        Me.CbxGrado.TabIndex = 47
        '
        'TxtProcedencia
        '
        Me.TxtProcedencia.Location = New System.Drawing.Point(586, 404)
        Me.TxtProcedencia.Name = "TxtProcedencia"
        Me.TxtProcedencia.Size = New System.Drawing.Size(153, 20)
        Me.TxtProcedencia.TabIndex = 48
        '
        'TxtTelefono2
        '
        Me.TxtTelefono2.Location = New System.Drawing.Point(519, 253)
        Me.TxtTelefono2.Name = "TxtTelefono2"
        Me.TxtTelefono2.Size = New System.Drawing.Size(98, 20)
        Me.TxtTelefono2.TabIndex = 50
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label3.Location = New System.Drawing.Point(486, 256)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(12, 13)
        Me.Label3.TabIndex = 51
        Me.Label3.Text = "/"
        '
        'CbxFormaHoraria
        '
        Me.CbxFormaHoraria.FormattingEnabled = True
        Me.CbxFormaHoraria.Location = New System.Drawing.Point(119, 483)
        Me.CbxFormaHoraria.Name = "CbxFormaHoraria"
        Me.CbxFormaHoraria.Size = New System.Drawing.Size(121, 21)
        Me.CbxFormaHoraria.TabIndex = 52
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'RbnFemenino
        '
        Me.RbnFemenino.AutoSize = True
        Me.RbnFemenino.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.RbnFemenino.Location = New System.Drawing.Point(727, 295)
        Me.RbnFemenino.Name = "RbnFemenino"
        Me.RbnFemenino.Size = New System.Drawing.Size(31, 17)
        Me.RbnFemenino.TabIndex = 56
        Me.RbnFemenino.Text = "F"
        Me.RbnFemenino.UseVisualStyleBackColor = True
        '
        'RbnMasculino
        '
        Me.RbnMasculino.AutoSize = True
        Me.RbnMasculino.Checked = True
        Me.RbnMasculino.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.RbnMasculino.Location = New System.Drawing.Point(671, 295)
        Me.RbnMasculino.Name = "RbnMasculino"
        Me.RbnMasculino.Size = New System.Drawing.Size(34, 17)
        Me.RbnMasculino.TabIndex = 55
        Me.RbnMasculino.TabStop = True
        Me.RbnMasculino.Text = "M"
        Me.RbnMasculino.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label13.Location = New System.Drawing.Point(679, 251)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(42, 13)
        Me.Label13.TabIndex = 54
        Me.Label13.Text = "Género"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(630, 112)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(127, 118)
        Me.PictureBox1.TabIndex = 53
        Me.PictureBox1.TabStop = False
        '
        'FichaMédica
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(976, 613)
        Me.Controls.Add(Me.RbnFemenino)
        Me.Controls.Add(Me.RbnMasculino)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.CbxFormaHoraria)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtTelefono2)
        Me.Controls.Add(Me.TxtProcedencia)
        Me.Controls.Add(Me.CbxGrado)
        Me.Controls.Add(Me.CbxEspecializacion)
        Me.Controls.Add(Me.TxtTelContacto)
        Me.Controls.Add(Me.TxtContacto)
        Me.Controls.Add(Me.TxtEmail)
        Me.Controls.Add(Me.TxtTelefono1)
        Me.Controls.Add(Me.TxtDireccion)
        Me.Controls.Add(Me.DtmFn)
        Me.Controls.Add(Me.TxtCI)
        Me.Controls.Add(Me.TxtApellido)
        Me.Controls.Add(Me.TxtNombre)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Cédula)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FichaMédica"
        Me.Text = "FichaMédica"
        Me.Panel1.ResumeLayout(False)
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Cédula As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents BtnGuardar As Button
    Friend WithEvents BtnEliminar As Button
    Friend WithEvents BtnModificar As Button
    Friend WithEvents BtnImprimir As Button
    Friend WithEvents TxtNombre As TextBox
    Friend WithEvents TxtApellido As TextBox
    Friend WithEvents TxtCI As TextBox
    Friend WithEvents DtmFn As DateTimePicker
    Friend WithEvents TxtDireccion As TextBox
    Friend WithEvents TxtTelefono1 As TextBox
    Friend WithEvents TxtEmail As TextBox
    Friend WithEvents TxtContacto As TextBox
    Friend WithEvents TxtTelContacto As TextBox
    Friend WithEvents CbxEspecializacion As ComboBox
    Friend WithEvents CbxGrado As ComboBox
    Friend WithEvents TxtProcedencia As TextBox
    Friend WithEvents TxtTelefono2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents BtnCancelar As Button
    Friend WithEvents CbxFormaHoraria As ComboBox
    Friend WithEvents ErrorProvider1 As ErrorProvider
    Friend WithEvents RbnFemenino As RadioButton
    Friend WithEvents RbnMasculino As RadioButton
    Friend WithEvents Label13 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
