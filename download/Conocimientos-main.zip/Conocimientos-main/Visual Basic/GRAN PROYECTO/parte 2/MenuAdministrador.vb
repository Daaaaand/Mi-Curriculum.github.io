﻿Public Class MenuAdministrador
    Public Tipo As String


    Private Sub openchildform(childform As Object)
        If (PanelMedio.Controls.Count > 0) Then
            PanelMedio.Controls.RemoveAt(0)
        End If
        Dim frm As Form
        frm = childform
        frm.TopLevel = False
        frm.Dock = DockStyle.Fill
        frm.FormBorderStyle = FormBorderStyle.None
        PanelMedio.Controls.Add(frm)
        PanelMedio.Tag = frm
        frm.Show()


    End Sub
    Private Sub Label4_Click(sender As Object, e As EventArgs)


    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label2.Text = DateTime.Now.ToString

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub MenuAdministrador_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True

    End Sub

    Private Sub BtnIngresar_Click(sender As Object, e As EventArgs) Handles BtnIngresar.Click

        openchildform(New AdministradorIngresarLateral)

    End Sub

    Private Sub BtnSala_Click(sender As Object, e As EventArgs) Handles BtnSala.Click
        openchildform(New AdministradorSalaLateral)
    End Sub

    Public Sub CbxTipo_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub PanelLateral_Paint(sender As Object, e As PaintEventArgs)

    End Sub

    Private Sub BtnConsultas_Click(sender As Object, e As EventArgs) Handles BtnConsultas.Click
        openchildform(New Horarios)
    End Sub

    Private Sub BtnBuscar_Click(sender As Object, e As EventArgs)
        openchildform(New Buscar)
    End Sub

    Private Sub BtnBuscar_Click_1(sender As Object, e As EventArgs) Handles BtnBuscar.Click
        openchildform(New Buscar)
    End Sub
End Class