﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Historia_paciente
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtDiagnóstico = New System.Windows.Forms.TextBox()
        Me.TxtFechaConsulta = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtDuraciónProceso = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TxtCiPaciente = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TxtFechaAlta = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtTratamiento = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LbxDatos = New System.Windows.Forms.ListBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.LbxObservaciones = New System.Windows.Forms.ListBox()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.GroupBox1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(232, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fecha de consulta"
        '
        'TxtDiagnóstico
        '
        Me.TxtDiagnóstico.Location = New System.Drawing.Point(81, 147)
        Me.TxtDiagnóstico.Name = "TxtDiagnóstico"
        Me.TxtDiagnóstico.Size = New System.Drawing.Size(370, 20)
        Me.TxtDiagnóstico.TabIndex = 1
        '
        'TxtFechaConsulta
        '
        Me.TxtFechaConsulta.Location = New System.Drawing.Point(333, 24)
        Me.TxtFechaConsulta.Name = "TxtFechaConsulta"
        Me.TxtFechaConsulta.Size = New System.Drawing.Size(100, 20)
        Me.TxtFechaConsulta.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 73)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Fecha de Alta"
        '
        'TxtDuraciónProceso
        '
        Me.TxtDuraciónProceso.Location = New System.Drawing.Point(333, 70)
        Me.TxtDuraciónProceso.Name = "TxtDuraciónProceso"
        Me.TxtDuraciónProceso.Size = New System.Drawing.Size(100, 20)
        Me.TxtDuraciónProceso.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(221, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Duración de proceso"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TxtCiPaciente)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.TxtFechaAlta)
        Me.GroupBox1.Controls.Add(Me.TxtDuraciónProceso)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.TxtFechaConsulta)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(439, 122)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Historia"
        '
        'TxtCiPaciente
        '
        Me.TxtCiPaciente.Location = New System.Drawing.Point(107, 24)
        Me.TxtCiPaciente.Name = "TxtCiPaciente"
        Me.TxtCiPaciente.Size = New System.Drawing.Size(100, 20)
        Me.TxtCiPaciente.TabIndex = 12
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 27)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "CI paciente"
        '
        'TxtFechaAlta
        '
        Me.TxtFechaAlta.Location = New System.Drawing.Point(107, 70)
        Me.TxtFechaAlta.Name = "TxtFechaAlta"
        Me.TxtFechaAlta.Size = New System.Drawing.Size(100, 20)
        Me.TxtFechaAlta.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 150)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Diagnóstico"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 207)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Tratamiento"
        '
        'TxtTratamiento
        '
        Me.TxtTratamiento.Location = New System.Drawing.Point(81, 204)
        Me.TxtTratamiento.Name = "TxtTratamiento"
        Me.TxtTratamiento.Size = New System.Drawing.Size(370, 20)
        Me.TxtTratamiento.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 258)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(84, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Datos de interés"
        '
        'LbxDatos
        '
        Me.LbxDatos.FormattingEnabled = True
        Me.LbxDatos.Location = New System.Drawing.Point(96, 258)
        Me.LbxDatos.Name = "LbxDatos"
        Me.LbxDatos.Size = New System.Drawing.Size(349, 95)
        Me.LbxDatos.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 384)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(78, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Observaciones"
        '
        'LbxObservaciones
        '
        Me.LbxObservaciones.FormattingEnabled = True
        Me.LbxObservaciones.Location = New System.Drawing.Point(96, 384)
        Me.LbxObservaciones.Name = "LbxObservaciones"
        Me.LbxObservaciones.Size = New System.Drawing.Size(349, 95)
        Me.LbxObservaciones.TabIndex = 13
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'Historia_paciente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(463, 491)
        Me.Controls.Add(Me.LbxObservaciones)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.LbxDatos)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TxtTratamiento)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TxtDiagnóstico)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Historia_paciente"
        Me.Text = "Historia_paciente"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtDiagnóstico As System.Windows.Forms.TextBox
    Friend WithEvents TxtFechaConsulta As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtDuraciónProceso As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtFechaAlta As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TxtTratamiento As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LbxDatos As System.Windows.Forms.ListBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LbxObservaciones As System.Windows.Forms.ListBox
    Friend WithEvents TxtCiPaciente As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
End Class
