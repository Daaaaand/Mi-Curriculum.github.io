﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Horarios
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtCiDoctor = New System.Windows.Forms.TextBox()
        Me.TxtNombreDoctor = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtApellidoDoctor = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtNúmeroDoctor = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtNúmeroPaciente = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TxtApellidoPaciente = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TxtNombrePaciente = New System.Windows.Forms.TextBox()
        Me.TxtCiPaciente = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TxtHorario = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TxtNúmeroalternativoDoctor = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TxtNúmeroalternativoPaciente = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TxtConsultorio = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Doctor = New System.Windows.Forms.GroupBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.BtnRellenar = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnImprimir = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CbxConsultorio = New System.Windows.Forms.ComboBox()
        Me.TxtConsulta1 = New System.Windows.Forms.TextBox()
        Me.TxtConsulta2 = New System.Windows.Forms.TextBox()
        Me.CbxConsulta2 = New System.Windows.Forms.ComboBox()
        Me.BtnBuscar = New System.Windows.Forms.Button()
        Me.Doctor.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(266, -14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fecha del día"
        '
        'TxtCiDoctor
        '
        Me.TxtCiDoctor.Location = New System.Drawing.Point(85, 67)
        Me.TxtCiDoctor.Name = "TxtCiDoctor"
        Me.TxtCiDoctor.Size = New System.Drawing.Size(100, 20)
        Me.TxtCiDoctor.TabIndex = 4
        '
        'TxtNombreDoctor
        '
        Me.TxtNombreDoctor.Location = New System.Drawing.Point(85, 19)
        Me.TxtNombreDoctor.Name = "TxtNombreDoctor"
        Me.TxtNombreDoctor.Size = New System.Drawing.Size(100, 20)
        Me.TxtNombreDoctor.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Nombre Doctor"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(203, 21)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Apellido"
        '
        'TxtApellidoDoctor
        '
        Me.TxtApellidoDoctor.Location = New System.Drawing.Point(253, 18)
        Me.TxtApellidoDoctor.Name = "TxtApellidoDoctor"
        Me.TxtApellidoDoctor.Size = New System.Drawing.Size(100, 20)
        Me.TxtApellidoDoctor.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(203, 70)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Número"
        '
        'TxtNúmeroDoctor
        '
        Me.TxtNúmeroDoctor.Location = New System.Drawing.Point(253, 67)
        Me.TxtNúmeroDoctor.Name = "TxtNúmeroDoctor"
        Me.TxtNúmeroDoctor.Size = New System.Drawing.Size(100, 20)
        Me.TxtNúmeroDoctor.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(34, 80)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Número"
        '
        'TxtNúmeroPaciente
        '
        Me.TxtNúmeroPaciente.Location = New System.Drawing.Point(83, 76)
        Me.TxtNúmeroPaciente.Name = "TxtNúmeroPaciente"
        Me.TxtNúmeroPaciente.Size = New System.Drawing.Size(89, 20)
        Me.TxtNúmeroPaciente.TabIndex = 17
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(361, 27)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Apellido"
        '
        'TxtApellidoPaciente
        '
        Me.TxtApellidoPaciente.Location = New System.Drawing.Point(411, 24)
        Me.TxtApellidoPaciente.Name = "TxtApellidoPaciente"
        Me.TxtApellidoPaciente.Size = New System.Drawing.Size(100, 20)
        Me.TxtApellidoPaciente.TabIndex = 15
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(201, 27)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(47, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Nombre "
        '
        'TxtNombrePaciente
        '
        Me.TxtNombrePaciente.Location = New System.Drawing.Point(254, 24)
        Me.TxtNombrePaciente.Name = "TxtNombrePaciente"
        Me.TxtNombrePaciente.Size = New System.Drawing.Size(100, 20)
        Me.TxtNombrePaciente.TabIndex = 13
        '
        'TxtCiPaciente
        '
        Me.TxtCiPaciente.Location = New System.Drawing.Point(83, 24)
        Me.TxtCiPaciente.Name = "TxtCiPaciente"
        Me.TxtCiPaciente.Size = New System.Drawing.Size(100, 20)
        Me.TxtCiPaciente.TabIndex = 12
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 27)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(61, 13)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "CI paciente"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(363, 22)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(83, 13)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "Especialización "
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(18, 9)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(80, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Fecha consulta"
        '
        'TxtHorario
        '
        Me.TxtHorario.Location = New System.Drawing.Point(97, 53)
        Me.TxtHorario.Name = "TxtHorario"
        Me.TxtHorario.Size = New System.Drawing.Size(100, 20)
        Me.TxtHorario.TabIndex = 24
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(18, 53)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(41, 13)
        Me.Label13.TabIndex = 23
        Me.Label13.Text = "Horario"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(363, 70)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(96, 13)
        Me.Label14.TabIndex = 26
        Me.Label14.Text = "Número alternativo"
        '
        'TxtNúmeroalternativoDoctor
        '
        Me.TxtNúmeroalternativoDoctor.Location = New System.Drawing.Point(464, 69)
        Me.TxtNúmeroalternativoDoctor.Name = "TxtNúmeroalternativoDoctor"
        Me.TxtNúmeroalternativoDoctor.Size = New System.Drawing.Size(100, 20)
        Me.TxtNúmeroalternativoDoctor.TabIndex = 25
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(187, 79)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(96, 13)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "Número alternativo"
        '
        'TxtNúmeroalternativoPaciente
        '
        Me.TxtNúmeroalternativoPaciente.Location = New System.Drawing.Point(288, 76)
        Me.TxtNúmeroalternativoPaciente.Name = "TxtNúmeroalternativoPaciente"
        Me.TxtNúmeroalternativoPaciente.Size = New System.Drawing.Size(98, 20)
        Me.TxtNúmeroalternativoPaciente.TabIndex = 29
        '
        'Button1
        '
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(509, 426)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 31
        Me.Button1.Text = "Guardar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Label17.Location = New System.Drawing.Point(6, 283)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(0, 13)
        Me.Label17.TabIndex = 32
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Label18.Location = New System.Drawing.Point(6, 283)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(0, 13)
        Me.Label18.TabIndex = 33
        '
        'TxtConsultorio
        '
        Me.TxtConsultorio.Location = New System.Drawing.Point(294, 53)
        Me.TxtConsultorio.Name = "TxtConsultorio"
        Me.TxtConsultorio.Size = New System.Drawing.Size(100, 20)
        Me.TxtConsultorio.TabIndex = 42
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(215, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 13)
        Me.Label3.TabIndex = 41
        Me.Label3.Text = "Consultorio"
        '
        'Button5
        '
        Me.Button5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button5.Location = New System.Drawing.Point(396, 426)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 45
        Me.Button5.Text = "Cancelar"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Doctor
        '
        Me.Doctor.Controls.Add(Me.Label20)
        Me.Doctor.Controls.Add(Me.ComboBox4)
        Me.Doctor.Controls.Add(Me.TxtCiDoctor)
        Me.Doctor.Controls.Add(Me.TxtNombreDoctor)
        Me.Doctor.Controls.Add(Me.Label4)
        Me.Doctor.Controls.Add(Me.TxtApellidoDoctor)
        Me.Doctor.Controls.Add(Me.Label5)
        Me.Doctor.Controls.Add(Me.TxtNúmeroDoctor)
        Me.Doctor.Controls.Add(Me.Label6)
        Me.Doctor.Controls.Add(Me.Label12)
        Me.Doctor.Controls.Add(Me.TxtNúmeroalternativoDoctor)
        Me.Doctor.Controls.Add(Me.Label14)
        Me.Doctor.Location = New System.Drawing.Point(12, 104)
        Me.Doctor.Name = "Doctor"
        Me.Doctor.Size = New System.Drawing.Size(572, 108)
        Me.Doctor.TabIndex = 46
        Me.Doctor.TabStop = False
        Me.Doctor.Text = "Doctor"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(17, 70)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(52, 13)
        Me.Label20.TabIndex = 31
        Me.Label20.Text = "CI Doctor"
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(452, 18)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(100, 21)
        Me.ComboBox4.TabIndex = 47
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.TxtCiPaciente)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.TxtNombrePaciente)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.TxtApellidoPaciente)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.TxtNúmeroPaciente)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.TxtNúmeroalternativoPaciente)
        Me.GroupBox2.Location = New System.Drawing.Point(14, 247)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(570, 119)
        Me.GroupBox2.TabIndex = 47
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Paciente"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(104, 3)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 48
        '
        'BtnRellenar
        '
        Me.BtnRellenar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnRellenar.Location = New System.Drawing.Point(590, 115)
        Me.BtnRellenar.Name = "BtnRellenar"
        Me.BtnRellenar.Size = New System.Drawing.Size(75, 23)
        Me.BtnRellenar.TabIndex = 49
        Me.BtnRellenar.Text = "Rellenar"
        Me.BtnRellenar.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(590, 264)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 50
        Me.Button2.Text = "Rellenar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'BtnImprimir
        '
        Me.BtnImprimir.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnImprimir.Location = New System.Drawing.Point(14, 426)
        Me.BtnImprimir.Name = "BtnImprimir"
        Me.BtnImprimir.Size = New System.Drawing.Size(75, 23)
        Me.BtnImprimir.TabIndex = 51
        Me.BtnImprimir.Text = "Imprimir"
        Me.BtnImprimir.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(694, 104)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(290, 439)
        Me.DataGridView1.TabIndex = 52
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(652, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 53
        Me.Label2.Text = "Buscar"
        '
        'CbxConsultorio
        '
        Me.CbxConsultorio.FormattingEnabled = True
        Me.CbxConsultorio.Location = New System.Drawing.Point(698, 12)
        Me.CbxConsultorio.Name = "CbxConsultorio"
        Me.CbxConsultorio.Size = New System.Drawing.Size(100, 21)
        Me.CbxConsultorio.TabIndex = 55
        '
        'TxtConsulta1
        '
        Me.TxtConsulta1.Location = New System.Drawing.Point(698, 53)
        Me.TxtConsulta1.Name = "TxtConsulta1"
        Me.TxtConsulta1.Size = New System.Drawing.Size(100, 20)
        Me.TxtConsulta1.TabIndex = 48
        '
        'TxtConsulta2
        '
        Me.TxtConsulta2.Location = New System.Drawing.Point(814, 53)
        Me.TxtConsulta2.Name = "TxtConsulta2"
        Me.TxtConsulta2.Size = New System.Drawing.Size(100, 20)
        Me.TxtConsulta2.TabIndex = 56
        '
        'CbxConsulta2
        '
        Me.CbxConsulta2.FormattingEnabled = True
        Me.CbxConsulta2.Location = New System.Drawing.Point(814, 12)
        Me.CbxConsulta2.Name = "CbxConsulta2"
        Me.CbxConsulta2.Size = New System.Drawing.Size(100, 21)
        Me.CbxConsulta2.TabIndex = 57
        '
        'BtnBuscar
        '
        Me.BtnBuscar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnBuscar.Location = New System.Drawing.Point(920, 33)
        Me.BtnBuscar.Name = "BtnBuscar"
        Me.BtnBuscar.Size = New System.Drawing.Size(64, 23)
        Me.BtnBuscar.TabIndex = 58
        Me.BtnBuscar.Text = "Buscar"
        Me.BtnBuscar.UseVisualStyleBackColor = True
        '
        'Horarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(996, 613)
        Me.Controls.Add(Me.BtnBuscar)
        Me.Controls.Add(Me.TxtConsulta2)
        Me.Controls.Add(Me.CbxConsulta2)
        Me.Controls.Add(Me.TxtConsulta1)
        Me.Controls.Add(Me.CbxConsultorio)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.BtnImprimir)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.BtnRellenar)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Doctor)
        Me.Controls.Add(Me.TxtConsultorio)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtHorario)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Name = "Horarios"
        Me.Text = "Horario-Consulta"
        Me.Doctor.ResumeLayout(False)
        Me.Doctor.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtCiDoctor As System.Windows.Forms.TextBox
    Friend WithEvents TxtNombreDoctor As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TxtApellidoDoctor As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TxtNúmeroDoctor As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TxtNúmeroPaciente As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TxtApellidoPaciente As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TxtNombrePaciente As System.Windows.Forms.TextBox
    Friend WithEvents TxtCiPaciente As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TxtHorario As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TxtNúmeroalternativoDoctor As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TxtNúmeroalternativoPaciente As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TxtConsultorio As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Doctor As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents BtnImprimir As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents BtnRellenar As Button
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents BtnBuscar As Button
    Friend WithEvents TxtConsulta2 As TextBox
    Friend WithEvents CbxConsulta2 As ComboBox
    Friend WithEvents TxtConsulta1 As TextBox
    Friend WithEvents CbxConsultorio As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents DataGridView1 As DataGridView
End Class
