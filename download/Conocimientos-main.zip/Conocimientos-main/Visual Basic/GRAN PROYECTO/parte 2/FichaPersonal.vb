﻿Imports System.Text.RegularExpressions
Public Class FichaPersonal

    Private Sub TxtTeléfono2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtTeléfono2.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox11_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtTeléfono2.TextChanged

    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RbnMasculino.CheckedChanged

    End Sub

    Private Sub TxtNombre_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtNombre.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtNombre_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtNombre.TextChanged

    End Sub

    Private Sub TxtApellido_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtApellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtApellido_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtApellido.TextChanged

    End Sub

    Private Sub TxtCi_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCi.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtCi_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCi.TextChanged

    End Sub

    Private Sub TxtNacimiento_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TxtNacimiento_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)


    End Sub

    Private Sub TxtEmail_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtEmail.TextChanged

    End Sub

    Private Sub TxtEmail_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TxtEmail.Validating
        Dim EmailPaciente As String
        EmailPaciente = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        If Regex.IsMatch(TxtEmail.Text, EmailPaciente) Then

        Else
            ErrorProvider1.SetError(TxtEmail, "Ingrese un email válido")
        End If
    End Sub

    Private Sub TxtTeléfono1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtTeléfono1.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtTeléfono1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtTeléfono1.TextChanged

    End Sub

    Private Sub TxtContactoemergencia_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtContactoemergencia.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtContactoemergencia_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtContactoemergencia.TextChanged

    End Sub

    Private Sub TxtTeléfonoemergencia_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtTeléfonoemergencia.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtTeléfonoemergencia_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtTeléfonoemergencia.TextChanged
        
    End Sub

    Private Sub BtnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim nombre As String = TxtNombre.Text.Trim
        Dim apellido As String = TxtApellido.Text.Trim
        Dim ci As String = TxtCi.Text.Trim
        Dim Direccion As String = TxtDirección.Text.Trim
        Dim Email As String = TxtEmail.Text.Trim
        Dim Telefono As String = TxtTeléfono1.Text.Trim
        Dim Telefono2 As String = TxtTeléfono2.Text.Trim
        Dim ContactoE As String = TxtContactoemergencia.Text.Trim
        Dim TelefonoE As String = TxtTeléfonoemergencia.Text.Trim
    End Sub

    Private Sub FichaPersonal_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TxtDirección_TextChanged(sender As Object, e As EventArgs) Handles TxtDirección.TextChanged

    End Sub

    Private Sub TxtDirección_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtDirección.KeyPress

    End Sub
End Class