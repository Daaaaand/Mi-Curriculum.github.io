﻿Imports System.Text.RegularExpressions
Public Class FichaAuxiliar

    Private Sub TxtNacimientoaño_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TxtNacimiento_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)



    End Sub

    Private Sub TxtNombre_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtNombre.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtNombre_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtNombre.TextChanged

    End Sub

    Private Sub TxtApellido_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtApellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub

    Private Sub TxtApellido1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtApellido.TextChanged

    End Sub

    Private Sub TxtApellido2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
     
    End Sub

    Private Sub TxtApellido2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TxtCi_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCi.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub

    Private Sub TxtCi_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCi.TextChanged


    End Sub

    Private Sub TxtTeléfono1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtTeléfono1.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub

    Private Sub TxtTeléfono1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtTeléfono1.TextChanged

    End Sub

    Private Sub TxtTeléfono2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtTeléfono2.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub

    Private Sub TxtTeléfono2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtTeléfono2.TextChanged

    End Sub

    Private Sub TxtEmail_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtEmail.TextChanged

    End Sub

    Private Sub TxtEmail_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TxtEmail.Validating
        Dim EmailPaciente As String
        EmailPaciente = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        If Regex.IsMatch(TxtEmail.Text, EmailPaciente) Then

        Else
            ErrorProvider1.SetError(TxtEmail, "Ingrese un email válido")
        End If
    End Sub

    Private Sub TxtContactosecundario_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtContactosecundario.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtContactosecundario_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtContactosecundario.TextChanged

    End Sub

    Private Sub TxtTeléfonosecundario_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtTeléfonosecundario.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtTeléfonosecundario_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtTeléfonosecundario.TextChanged
       
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtFecha.TextChanged

    End Sub

    Private Sub BtnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim nombre As String = TxtNombre.Text.Trim
        Dim apellido As String = TxtApellido.Text.Trim
        Dim fecha As String = TxtFecha.Text.Trim
        Dim ci As String = TxtCi.Text.Trim
        Dim Direccion As String = TxtDirección.Text.Trim
        Dim Email As String = TxtEmail.Text.Trim
        Dim Telefono As String = TxtTeléfono1.Text.Trim
        Dim Telefono2 As String = TxtTeléfono2.Text.Trim
        Dim Contacto As String = TxtContactosecundario.Text.Trim
        Dim TelefonoC As String = TxtTeléfonosecundario.Text.Trim



        'Dim Validar As Boolean
        'Validar = True
        'If TxtNombre.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar nombre")
        'End If

        'If TxtApellido.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar apellido")
        'End If

        'If TxtCi.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar cédula")
        'End If

        'If TxtNacimiento.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar fecha de nacimiento")
        'End If

        'If TxtDirección.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar dirección")
        'End If

        'If TxtTeléfono1.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar teléfono")
        'End If

        'If TxtTeléfono2.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar teléfono")
        'End If

        'If TxtEmail.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar email")
        'End If

        'If TxtContactosecundario.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar contácto")
        'End If

        'If TxtTeléfonosecundario.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar teléfono")
        'End If

        'If TxtFirma.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar firma")
        'End If
        'If CbxArea.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar área")
        'End If

        'If CbxHorario.Text = "" Then
        '    Validar = False
        '    ErrorProvider1.SetError(TxtNombre, "Ingresar horario")
        'End If
    End Sub

    Private Sub FichaAuxiliar_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class