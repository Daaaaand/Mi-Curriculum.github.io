﻿Public Class Evolución

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TxtFecha_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BtnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnGuardar.Click

    End Sub

    Private Sub TxtCi_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCi.TextChanged

    End Sub
End Class