﻿Public Class DoctorRecetasMedio

End Class