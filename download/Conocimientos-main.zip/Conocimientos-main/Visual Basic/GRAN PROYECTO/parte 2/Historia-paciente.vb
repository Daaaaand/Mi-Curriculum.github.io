﻿Public Class Historia_paciente

    Private Sub TxtCiPaciente_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCiPaciente.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtCiPaciente_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCiPaciente.TextChanged

    End Sub

    Private Sub TxtFechaConsulta_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtFechaConsulta.TextChanged
      
    End Sub

    Private Sub TxtFechaConsulta_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TxtFechaConsulta.Validating
        Dim FechaconsultaPaciente As DateTime
        If DateTime.TryParse(TxtFechaConsulta.Text, FechaconsultaPaciente) Then
            ErrorProvider1.SetError(TxtFechaConsulta, "El formato debe ser DD-MM-YY")
        End If
    End Sub

    Private Sub TxtFechaAlta_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtFechaAlta.TextChanged

    End Sub

    Private Sub TxtFechaAlta_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TxtFechaAlta.Validating
        Dim FechaconsultaPaciente As DateTime
        If DateTime.TryParse(TxtFechaConsulta.Text, FechaconsultaPaciente) Then
            ErrorProvider1.SetError(TxtFechaConsulta, "El formato debe ser DD-MM-YY")
        End If
    End Sub
End Class