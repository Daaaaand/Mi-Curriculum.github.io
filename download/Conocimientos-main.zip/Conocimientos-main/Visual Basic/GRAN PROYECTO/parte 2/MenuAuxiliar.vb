﻿Public Class MenuAuxiliar
    Private Sub BtnConsulta_Click(sender As Object, e As EventArgs) Handles BtnConsulta.Click
        openchildform(New DoctorConsultaLateral)
    End Sub

    Private Sub BtnIngresar_Click(sender As Object, e As EventArgs) Handles BtnIngresar.Click
        openchildform(New DoctorIngresarLateral)
    End Sub
    Private Sub openchildform(childform As Object)
        If (PanelMedio.Controls.Count > 0) Then
            PanelMedio.Controls.RemoveAt(0)
        End If
        Dim frm As Form
        frm = childform
        frm.TopLevel = False
        frm.Dock = DockStyle.Fill
        frm.FormBorderStyle = FormBorderStyle.None
        PanelMedio.Controls.Add(frm)
        PanelMedio.Tag = frm
        frm.Show()
    End Sub
    Private Sub MenuAuxiliar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label2.Text = DateTime.Now.ToString
    End Sub

    Private Sub BtnInternacion_Click(sender As Object, e As EventArgs) Handles BtnInternacion.Click
        openchildform(New AuxiliarInternacion)
    End Sub
End Class