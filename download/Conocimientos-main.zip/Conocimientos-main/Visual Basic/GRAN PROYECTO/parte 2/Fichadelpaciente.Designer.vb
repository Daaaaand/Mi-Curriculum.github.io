﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Fichadelpaciente
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Cédula = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtCi = New System.Windows.Forms.TextBox()
        Me.TxtNombre = New System.Windows.Forms.TextBox()
        Me.TxtApellido = New System.Windows.Forms.TextBox()
        Me.TxtTeléfono1 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.RbnMasculino = New System.Windows.Forms.RadioButton()
        Me.RbnFemenino = New System.Windows.Forms.RadioButton()
        Me.TxtDirección = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TxtTeléfono2 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TxtOcupación = New System.Windows.Forms.TextBox()
        Me.TxtEstudios = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TxtContactoemergencia = New System.Windows.Forms.TextBox()
        Me.TxtTeléfonoemergencia = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.CbxEC = New System.Windows.Forms.ComboBox()
        Me.BtnImprimir = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CbxTipodesangre = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtNacionalidad = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TxtInformante = New System.Windows.Forms.TextBox()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.BtnModificar = New System.Windows.Forms.Panel()
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnEliminar = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.BtnModificar.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Cédula
        '
        Me.Cédula.AutoSize = True
        Me.Cédula.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Cédula.Location = New System.Drawing.Point(45, 154)
        Me.Cédula.Name = "Cédula"
        Me.Cédula.Size = New System.Drawing.Size(40, 13)
        Me.Cédula.TabIndex = 0
        Me.Cédula.Text = "Cédula"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label2.Location = New System.Drawing.Point(41, 93)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Nombre"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label4.Location = New System.Drawing.Point(278, 93)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Apellido "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label5.Location = New System.Drawing.Point(217, 154)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(108, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Fecha de Nacimiento"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label6.Location = New System.Drawing.Point(335, 278)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Teléfono"
        '
        'TxtCi
        '
        Me.TxtCi.Location = New System.Drawing.Point(95, 151)
        Me.TxtCi.Name = "TxtCi"
        Me.TxtCi.Size = New System.Drawing.Size(100, 20)
        Me.TxtCi.TabIndex = 8
        '
        'TxtNombre
        '
        Me.TxtNombre.Location = New System.Drawing.Point(95, 90)
        Me.TxtNombre.Name = "TxtNombre"
        Me.TxtNombre.Size = New System.Drawing.Size(163, 20)
        Me.TxtNombre.TabIndex = 9
        '
        'TxtApellido
        '
        Me.TxtApellido.Location = New System.Drawing.Point(342, 90)
        Me.TxtApellido.Name = "TxtApellido"
        Me.TxtApellido.Size = New System.Drawing.Size(198, 20)
        Me.TxtApellido.TabIndex = 10
        '
        'TxtTeléfono1
        '
        Me.TxtTeléfono1.Location = New System.Drawing.Point(395, 275)
        Me.TxtTeléfono1.Name = "TxtTeléfono1"
        Me.TxtTeléfono1.Size = New System.Drawing.Size(89, 20)
        Me.TxtTeléfono1.TabIndex = 12
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label9.Location = New System.Drawing.Point(655, 275)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(42, 13)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "Género"
        '
        'RbnMasculino
        '
        Me.RbnMasculino.AutoSize = True
        Me.RbnMasculino.Checked = True
        Me.RbnMasculino.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.RbnMasculino.Location = New System.Drawing.Point(647, 319)
        Me.RbnMasculino.Name = "RbnMasculino"
        Me.RbnMasculino.Size = New System.Drawing.Size(34, 17)
        Me.RbnMasculino.TabIndex = 24
        Me.RbnMasculino.TabStop = True
        Me.RbnMasculino.Text = "M"
        Me.RbnMasculino.UseVisualStyleBackColor = True
        '
        'RbnFemenino
        '
        Me.RbnFemenino.AutoSize = True
        Me.RbnFemenino.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.RbnFemenino.Location = New System.Drawing.Point(703, 319)
        Me.RbnFemenino.Name = "RbnFemenino"
        Me.RbnFemenino.Size = New System.Drawing.Size(31, 17)
        Me.RbnFemenino.TabIndex = 25
        Me.RbnFemenino.Text = "F"
        Me.RbnFemenino.UseVisualStyleBackColor = True
        '
        'TxtDirección
        '
        Me.TxtDirección.Location = New System.Drawing.Point(95, 212)
        Me.TxtDirección.Name = "TxtDirección"
        Me.TxtDirección.Size = New System.Drawing.Size(226, 20)
        Me.TxtDirección.TabIndex = 33
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label12.Location = New System.Drawing.Point(42, 215)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(52, 13)
        Me.Label12.TabIndex = 32
        Me.Label12.Text = "Dirección"
        '
        'TxtTeléfono2
        '
        Me.TxtTeléfono2.Location = New System.Drawing.Point(506, 275)
        Me.TxtTeléfono2.Name = "TxtTeléfono2"
        Me.TxtTeléfono2.Size = New System.Drawing.Size(89, 20)
        Me.TxtTeléfono2.TabIndex = 34
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label13.Location = New System.Drawing.Point(490, 278)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(12, 13)
        Me.Label13.TabIndex = 35
        Me.Label13.Text = "/"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label14.Location = New System.Drawing.Point(41, 408)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(59, 13)
        Me.Label14.TabIndex = 36
        Me.Label14.Text = "Ocupación"
        '
        'TxtOcupación
        '
        Me.TxtOcupación.Location = New System.Drawing.Point(105, 405)
        Me.TxtOcupación.Name = "TxtOcupación"
        Me.TxtOcupación.Size = New System.Drawing.Size(220, 20)
        Me.TxtOcupación.TabIndex = 37
        '
        'TxtEstudios
        '
        Me.TxtEstudios.Location = New System.Drawing.Point(404, 405)
        Me.TxtEstudios.Name = "TxtEstudios"
        Me.TxtEstudios.Size = New System.Drawing.Size(195, 20)
        Me.TxtEstudios.TabIndex = 39
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label15.Location = New System.Drawing.Point(338, 408)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(47, 13)
        Me.Label15.TabIndex = 38
        Me.Label15.Text = "Estudios"
        '
        'TxtEmail
        '
        Me.TxtEmail.Location = New System.Drawing.Point(99, 275)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(226, 20)
        Me.TxtEmail.TabIndex = 41
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label16.Location = New System.Drawing.Point(39, 282)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(32, 13)
        Me.Label16.TabIndex = 40
        Me.Label16.Text = "Email"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label17.Location = New System.Drawing.Point(41, 342)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(108, 13)
        Me.Label17.TabIndex = 42
        Me.Label17.Text = "Contacto emergencia"
        '
        'TxtContactoemergencia
        '
        Me.TxtContactoemergencia.Location = New System.Drawing.Point(154, 339)
        Me.TxtContactoemergencia.Name = "TxtContactoemergencia"
        Me.TxtContactoemergencia.Size = New System.Drawing.Size(164, 20)
        Me.TxtContactoemergencia.TabIndex = 43
        '
        'TxtTeléfonoemergencia
        '
        Me.TxtTeléfonoemergencia.Location = New System.Drawing.Point(396, 339)
        Me.TxtTeléfonoemergencia.Name = "TxtTeléfonoemergencia"
        Me.TxtTeléfonoemergencia.Size = New System.Drawing.Size(195, 20)
        Me.TxtTeléfonoemergencia.TabIndex = 45
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label19.Location = New System.Drawing.Point(336, 342)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(49, 13)
        Me.Label19.TabIndex = 44
        Me.Label19.Text = "Teléfono"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label21.Location = New System.Drawing.Point(55, 529)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(24, 13)
        Me.Label21.TabIndex = 50
        Me.Label21.Text = "E.C"
        '
        'CbxEC
        '
        Me.CbxEC.FormattingEnabled = True
        Me.CbxEC.Location = New System.Drawing.Point(92, 525)
        Me.CbxEC.Name = "CbxEC"
        Me.CbxEC.Size = New System.Drawing.Size(105, 21)
        Me.CbxEC.TabIndex = 51
        '
        'BtnImprimir
        '
        Me.BtnImprimir.Location = New System.Drawing.Point(110, 20)
        Me.BtnImprimir.Name = "BtnImprimir"
        Me.BtnImprimir.Size = New System.Drawing.Size(75, 23)
        Me.BtnImprimir.TabIndex = 59
        Me.BtnImprimir.Text = "Imprimir"
        Me.BtnImprimir.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(43, 471)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(78, 13)
        Me.Label1.TabIndex = 67
        Me.Label1.Text = "Tipo de sangre"
        '
        'CbxTipodesangre
        '
        Me.CbxTipodesangre.FormattingEnabled = True
        Me.CbxTipodesangre.Location = New System.Drawing.Point(123, 468)
        Me.CbxTipodesangre.Name = "CbxTipodesangre"
        Me.CbxTipodesangre.Size = New System.Drawing.Size(137, 21)
        Me.CbxTipodesangre.TabIndex = 69
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label3.Location = New System.Drawing.Point(340, 215)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 13)
        Me.Label3.TabIndex = 70
        Me.Label3.Text = "Nacionalidad"
        '
        'TxtNacionalidad
        '
        Me.TxtNacionalidad.Location = New System.Drawing.Point(415, 212)
        Me.TxtNacionalidad.Name = "TxtNacionalidad"
        Me.TxtNacionalidad.Size = New System.Drawing.Size(128, 20)
        Me.TxtNacionalidad.TabIndex = 71
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label8.Location = New System.Drawing.Point(271, 471)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(57, 13)
        Me.Label8.TabIndex = 75
        Me.Label8.Text = "Informante"
        '
        'TxtInformante
        '
        Me.TxtInformante.Location = New System.Drawing.Point(343, 468)
        Me.TxtInformante.Name = "TxtInformante"
        Me.TxtInformante.Size = New System.Drawing.Size(144, 20)
        Me.TxtInformante.TabIndex = 76
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'BtnModificar
        '
        Me.BtnModificar.Controls.Add(Me.BtnCancelar)
        Me.BtnModificar.Controls.Add(Me.Button2)
        Me.BtnModificar.Controls.Add(Me.BtnEliminar)
        Me.BtnModificar.Controls.Add(Me.Button1)
        Me.BtnModificar.Controls.Add(Me.BtnImprimir)
        Me.BtnModificar.Location = New System.Drawing.Point(39, 12)
        Me.BtnModificar.Name = "BtnModificar"
        Me.BtnModificar.Size = New System.Drawing.Size(732, 63)
        Me.BtnModificar.TabIndex = 93
        '
        'BtnCancelar
        '
        Me.BtnCancelar.Location = New System.Drawing.Point(426, 20)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelar.TabIndex = 63
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(18, 20)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 62
        Me.Button2.Text = "Guardar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'BtnEliminar
        '
        Me.BtnEliminar.Location = New System.Drawing.Point(298, 20)
        Me.BtnEliminar.Name = "BtnEliminar"
        Me.BtnEliminar.Size = New System.Drawing.Size(75, 23)
        Me.BtnEliminar.TabIndex = 61
        Me.BtnEliminar.Text = "Eliminar"
        Me.BtnEliminar.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(201, 20)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 60
        Me.Button1.Text = "Modificar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(606, 136)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(127, 118)
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(343, 151)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 94
        '
        'Fichadelpaciente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(976, 613)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.BtnModificar)
        Me.Controls.Add(Me.TxtInformante)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TxtNacionalidad)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.CbxTipodesangre)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CbxEC)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.TxtTeléfonoemergencia)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.TxtContactoemergencia)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.TxtEmail)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.TxtEstudios)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.TxtOcupación)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TxtTeléfono2)
        Me.Controls.Add(Me.TxtDirección)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.RbnFemenino)
        Me.Controls.Add(Me.RbnMasculino)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TxtTeléfono1)
        Me.Controls.Add(Me.TxtApellido)
        Me.Controls.Add(Me.TxtNombre)
        Me.Controls.Add(Me.TxtCi)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Cédula)
        Me.Name = "Fichadelpaciente"
        Me.Text = " "
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.BtnModificar.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Cédula As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TxtCi As System.Windows.Forms.TextBox
    Friend WithEvents TxtNombre As System.Windows.Forms.TextBox
    Friend WithEvents TxtApellido As System.Windows.Forms.TextBox
    Friend WithEvents TxtTeléfono1 As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents RbnMasculino As System.Windows.Forms.RadioButton
    Friend WithEvents RbnFemenino As System.Windows.Forms.RadioButton
    Friend WithEvents TxtDirección As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TxtTeléfono2 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TxtOcupación As System.Windows.Forms.TextBox
    Friend WithEvents TxtEstudios As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TxtEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TxtContactoemergencia As System.Windows.Forms.TextBox
    Friend WithEvents TxtTeléfonoemergencia As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents CbxEC As System.Windows.Forms.ComboBox
    Friend WithEvents BtnImprimir As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CbxTipodesangre As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtNacionalidad As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TxtInformante As System.Windows.Forms.TextBox
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents BtnModificar As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents BtnEliminar As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents BtnCancelar As Button
    Friend WithEvents DateTimePicker1 As DateTimePicker
End Class
