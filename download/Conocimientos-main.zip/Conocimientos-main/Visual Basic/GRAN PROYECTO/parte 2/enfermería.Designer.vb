﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class enfermería
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LbxIndícaciones = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtCi = New System.Windows.Forms.TextBox()
        Me.TxtNombre = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtApellido = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtConsultorio = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TxtCama = New System.Windows.Forms.TextBox()
        Me.BtnHistorial = New System.Windows.Forms.Button()
        Me.BtnEvolución = New System.Windows.Forms.Button()
        Me.LbxProcedimientos = New System.Windows.Forms.ListBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.BtnControles = New System.Windows.Forms.Button()
        Me.LbxMedicación = New System.Windows.Forms.ListBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.TxtFecha = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 109)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(123, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Indícaciones del médico"
        '
        'LbxIndícaciones
        '
        Me.LbxIndícaciones.FormattingEnabled = True
        Me.LbxIndícaciones.Location = New System.Drawing.Point(139, 109)
        Me.LbxIndícaciones.Name = "LbxIndícaciones"
        Me.LbxIndícaciones.Size = New System.Drawing.Size(287, 82)
        Me.LbxIndícaciones.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "CI paciente"
        '
        'TxtCi
        '
        Me.TxtCi.Location = New System.Drawing.Point(74, 21)
        Me.TxtCi.Name = "TxtCi"
        Me.TxtCi.Size = New System.Drawing.Size(100, 20)
        Me.TxtCi.TabIndex = 3
        '
        'TxtNombre
        '
        Me.TxtNombre.Location = New System.Drawing.Point(240, 21)
        Me.TxtNombre.Name = "TxtNombre"
        Me.TxtNombre.Size = New System.Drawing.Size(100, 20)
        Me.TxtNombre.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(180, 24)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Nombre"
        '
        'TxtApellido
        '
        Me.TxtApellido.Location = New System.Drawing.Point(397, 21)
        Me.TxtApellido.Name = "TxtApellido"
        Me.TxtApellido.Size = New System.Drawing.Size(100, 20)
        Me.TxtApellido.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(347, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Apellido"
        '
        'TxtConsultorio
        '
        Me.TxtConsultorio.Location = New System.Drawing.Point(74, 56)
        Me.TxtConsultorio.Name = "TxtConsultorio"
        Me.TxtConsultorio.Size = New System.Drawing.Size(100, 20)
        Me.TxtConsultorio.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(7, 59)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(59, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Consultorio"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(347, 59)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Fecha "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TxtFecha)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.TxtCama)
        Me.GroupBox1.Controls.Add(Me.TxtCi)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.TxtConsultorio)
        Me.GroupBox1.Controls.Add(Me.TxtNombre)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.TxtApellido)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 7)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(613, 96)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(180, 59)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(54, 13)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Nro Cama"
        '
        'TxtCama
        '
        Me.TxtCama.Location = New System.Drawing.Point(240, 56)
        Me.TxtCama.Name = "TxtCama"
        Me.TxtCama.Size = New System.Drawing.Size(100, 20)
        Me.TxtCama.TabIndex = 13
        '
        'BtnHistorial
        '
        Me.BtnHistorial.Location = New System.Drawing.Point(432, 109)
        Me.BtnHistorial.Name = "BtnHistorial"
        Me.BtnHistorial.Size = New System.Drawing.Size(89, 31)
        Me.BtnHistorial.TabIndex = 13
        Me.BtnHistorial.Text = "Historial clínico"
        Me.BtnHistorial.UseVisualStyleBackColor = True
        '
        'BtnEvolución
        '
        Me.BtnEvolución.Location = New System.Drawing.Point(432, 209)
        Me.BtnEvolución.Name = "BtnEvolución"
        Me.BtnEvolución.Size = New System.Drawing.Size(89, 31)
        Me.BtnEvolución.TabIndex = 14
        Me.BtnEvolución.Text = "Evolución"
        Me.BtnEvolución.UseVisualStyleBackColor = True
        '
        'LbxProcedimientos
        '
        Me.LbxProcedimientos.FormattingEnabled = True
        Me.LbxProcedimientos.Location = New System.Drawing.Point(139, 209)
        Me.LbxProcedimientos.Name = "LbxProcedimientos"
        Me.LbxProcedimientos.Size = New System.Drawing.Size(287, 69)
        Me.LbxProcedimientos.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 209)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Procedimientos"
        '
        'BtnControles
        '
        Me.BtnControles.Location = New System.Drawing.Point(432, 161)
        Me.BtnControles.Name = "BtnControles"
        Me.BtnControles.Size = New System.Drawing.Size(89, 30)
        Me.BtnControles.TabIndex = 17
        Me.BtnControles.Text = "Controles"
        Me.BtnControles.UseVisualStyleBackColor = True
        '
        'LbxMedicación
        '
        Me.LbxMedicación.FormattingEnabled = True
        Me.LbxMedicación.Location = New System.Drawing.Point(139, 306)
        Me.LbxMedicación.Name = "LbxMedicación"
        Me.LbxMedicación.Size = New System.Drawing.Size(287, 82)
        Me.LbxMedicación.TabIndex = 19
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 306)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 13)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Medicacion"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'TxtFecha
        '
        Me.TxtFecha.Location = New System.Drawing.Point(397, 56)
        Me.TxtFecha.Name = "TxtFecha"
        Me.TxtFecha.Size = New System.Drawing.Size(100, 20)
        Me.TxtFecha.TabIndex = 14
        '
        'enfermería
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(642, 402)
        Me.Controls.Add(Me.LbxMedicación)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.BtnControles)
        Me.Controls.Add(Me.LbxProcedimientos)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.BtnEvolución)
        Me.Controls.Add(Me.BtnHistorial)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.LbxIndícaciones)
        Me.Controls.Add(Me.Label1)
        Me.Name = "enfermería"
        Me.Text = "enfermería"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LbxIndícaciones As System.Windows.Forms.ListBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtCi As System.Windows.Forms.TextBox
    Friend WithEvents TxtNombre As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtApellido As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TxtConsultorio As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TxtCama As System.Windows.Forms.TextBox
    Friend WithEvents BtnHistorial As System.Windows.Forms.Button
    Friend WithEvents BtnEvolución As System.Windows.Forms.Button
    Friend WithEvents LbxProcedimientos As System.Windows.Forms.ListBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents BtnControles As System.Windows.Forms.Button
    Friend WithEvents LbxMedicación As System.Windows.Forms.ListBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents TxtFecha As System.Windows.Forms.TextBox
End Class
