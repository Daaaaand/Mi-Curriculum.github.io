﻿Public Class DoctorMisTratamientos
    Private Sub DoctorMisTratamientos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class