﻿Public Class Médico_Sala

End Class