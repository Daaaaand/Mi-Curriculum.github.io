﻿Public Class IniciarSesión

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MenuAdministrador.Show()
        Me.Close()
    End Sub

    Private Sub TxtSala_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtSala.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtSala_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtSala.TextChanged

    End Sub

    Private Sub TxtFecha_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtFecha.TextChanged
        Dim fecha As Date
        fecha = Date.Today
    End Sub

    Private Sub TxtCiSesión_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCiSesión.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtCiSesión_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCiSesión.TextChanged

    End Sub
End Class