﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MenuAdministrador
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MenuAdministrador))
        Me.PanelFlecha = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PanelSuperior = New System.Windows.Forms.Panel()
        Me.BtnConsultas = New System.Windows.Forms.Button()
        Me.BtnSala = New System.Windows.Forms.Button()
        Me.BtnIngresar = New System.Windows.Forms.Button()
        Me.PanelMedio = New System.Windows.Forms.Panel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.BtnBuscar = New System.Windows.Forms.Button()
        Me.PanelFlecha.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelSuperior.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelFlecha
        '
        Me.PanelFlecha.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.PanelFlecha.Controls.Add(Me.Label2)
        Me.PanelFlecha.Controls.Add(Me.Label1)
        Me.PanelFlecha.Controls.Add(Me.PictureBox1)
        Me.PanelFlecha.Location = New System.Drawing.Point(2, 0)
        Me.PanelFlecha.Name = "PanelFlecha"
        Me.PanelFlecha.Size = New System.Drawing.Size(320, 85)
        Me.PanelFlecha.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label2.Location = New System.Drawing.Point(114, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 13)
        Me.Label2.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(45, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "FECHA : "
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 31)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(320, 51)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PanelSuperior
        '
        Me.PanelSuperior.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.PanelSuperior.Controls.Add(Me.BtnBuscar)
        Me.PanelSuperior.Controls.Add(Me.BtnConsultas)
        Me.PanelSuperior.Controls.Add(Me.BtnSala)
        Me.PanelSuperior.Controls.Add(Me.BtnIngresar)
        Me.PanelSuperior.Location = New System.Drawing.Point(321, 0)
        Me.PanelSuperior.Name = "PanelSuperior"
        Me.PanelSuperior.Size = New System.Drawing.Size(871, 85)
        Me.PanelSuperior.TabIndex = 7
        '
        'BtnConsultas
        '
        Me.BtnConsultas.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnConsultas.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnConsultas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnConsultas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnConsultas.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnConsultas.Location = New System.Drawing.Point(546, 3)
        Me.BtnConsultas.Name = "BtnConsultas"
        Me.BtnConsultas.Size = New System.Drawing.Size(186, 76)
        Me.BtnConsultas.TabIndex = 3
        Me.BtnConsultas.Text = "Consultas"
        Me.BtnConsultas.UseVisualStyleBackColor = False
        '
        'BtnSala
        '
        Me.BtnSala.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnSala.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSala.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnSala.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSala.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnSala.Location = New System.Drawing.Point(366, 3)
        Me.BtnSala.Name = "BtnSala"
        Me.BtnSala.Size = New System.Drawing.Size(186, 76)
        Me.BtnSala.TabIndex = 2
        Me.BtnSala.Text = "Sala"
        Me.BtnSala.UseVisualStyleBackColor = False
        '
        'BtnIngresar
        '
        Me.BtnIngresar.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnIngresar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnIngresar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnIngresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnIngresar.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnIngresar.Location = New System.Drawing.Point(0, 3)
        Me.BtnIngresar.Name = "BtnIngresar"
        Me.BtnIngresar.Size = New System.Drawing.Size(186, 76)
        Me.BtnIngresar.TabIndex = 0
        Me.BtnIngresar.Text = "Ingresar"
        Me.BtnIngresar.UseVisualStyleBackColor = False
        '
        'PanelMedio
        '
        Me.PanelMedio.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelMedio.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PanelMedio.Location = New System.Drawing.Point(2, 85)
        Me.PanelMedio.Name = "PanelMedio"
        Me.PanelMedio.Size = New System.Drawing.Size(1190, 621)
        Me.PanelMedio.TabIndex = 10
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'BtnBuscar
        '
        Me.BtnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnBuscar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnBuscar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnBuscar.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnBuscar.Location = New System.Drawing.Point(183, 3)
        Me.BtnBuscar.Name = "BtnBuscar"
        Me.BtnBuscar.Size = New System.Drawing.Size(186, 76)
        Me.BtnBuscar.TabIndex = 4
        Me.BtnBuscar.Text = "Buscar"
        Me.BtnBuscar.UseVisualStyleBackColor = False
        '
        'MenuAdministrador
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1193, 695)
        Me.Controls.Add(Me.PanelMedio)
        Me.Controls.Add(Me.PanelSuperior)
        Me.Controls.Add(Me.PanelFlecha)
        Me.Name = "MenuAdministrador"
        Me.Text = "MenuAdministrador"
        Me.PanelFlecha.ResumeLayout(False)
        Me.PanelFlecha.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelSuperior.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelFlecha As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PanelSuperior As Panel
    Friend WithEvents BtnConsultas As Button
    Friend WithEvents BtnSala As Button
    Friend WithEvents BtnIngresar As Button
    Friend WithEvents PanelMedio As Panel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents BtnBuscar As Button
End Class
