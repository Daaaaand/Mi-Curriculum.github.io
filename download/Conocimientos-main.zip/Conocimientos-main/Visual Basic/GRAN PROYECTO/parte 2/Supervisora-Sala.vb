﻿Public Class Supervisora_Sala

    Private Sub TxtFecha_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtFecha.TextChanged
        Dim fecha As Date
        fecha = Date.Today
    End Sub

    Private Sub TxtNúmeroSala_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtNúmeroSala.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtNúmeroSala_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtNúmeroSala.TextChanged

    End Sub

    Private Sub TxtCiSupervisora_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCiSupervisora.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtCiSupervisora_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCiSupervisora.TextChanged

    End Sub
End Class