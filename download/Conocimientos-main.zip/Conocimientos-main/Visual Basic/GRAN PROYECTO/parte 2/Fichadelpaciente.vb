﻿Imports System.Text.RegularExpressions
Public Class Fichadelpaciente
    Public Tipo As String

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TxtNombre_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtNombre.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtNombre.TextChanged

    End Sub

    Private Sub Label9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label9.Click

    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click

    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Label10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TxtFecha_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True

        End If
    End Sub

    Private Sub TxtFecha_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)



    End Sub

    Private Sub TxtFecha_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)

    End Sub

    Private Sub TxtApellido_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtApellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtApellido_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtApellido.TextChanged

    End Sub

    Private Sub TxtCi_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCi.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtCi_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCi.TextChanged

    End Sub

    Private Sub TxtFechanacimiento_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub





    Private Sub TxtNacionalidad_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtNacionalidad.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtNacionalidad_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtNacionalidad.TextChanged

    End Sub

    Private Sub TxtTeléfono1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtTeléfono1.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtTeléfono1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtTeléfono1.TextChanged

    End Sub

    Private Sub TxtTeléfono2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtTeléfono2.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtTeléfono2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtTeléfono2.TextChanged

    End Sub

    Private Sub TxtEmail_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtEmail.TextChanged

    End Sub

    Private Sub TxtEmail_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TxtEmail.Validating
        Dim EmailPaciente As String
        EmailPaciente = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        If Regex.IsMatch(TxtEmail.Text, EmailPaciente) Then

        Else
            ErrorProvider1.SetError(TxtEmail, "Ingrese un email válido")
        End If
    End Sub

    Private Sub TxtContactoemergencia_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtContactoemergencia.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtContactoemergencia_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtContactoemergencia.TextChanged

    End Sub

    Private Sub TxtTeléfonoemergencia_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtTeléfonoemergencia.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtTeléfonoemergencia_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtTeléfonoemergencia.TextChanged

    End Sub

    Private Sub TxtDirección_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtDirección.TextChanged

    End Sub

    Private Sub TxtInformante_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtInformante.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtInformante_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtInformante.TextChanged

    End Sub

    Private Sub TxtPeso_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)

    End Sub

    Private Sub TxtPeso_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TxtAltura_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)

    End Sub

    Private Sub TxtAltura_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BtnIngresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnImprimir.Click
        Dim nombre As String = TxtNombre.Text.Trim
        Dim apellido As String = TxtApellido.Text.Trim
        Dim ci As String = TxtCi.Text.Trim
        Dim Direccion As String = TxtDirección.Text.Trim
        Dim Nacionalidad As String = TxtNacionalidad.Text.Trim
        Dim Email As String = TxtEmail.Text.Trim
        Dim Telefono As String = TxtTeléfono1.Text.Trim
        Dim Telefono2 As String = TxtTeléfono2.Text.Trim
        Dim ContactoE As String = TxtContactoemergencia.Text.Trim
        Dim TelefonoE As String = TxtTeléfonoemergencia.Text.Trim
        Dim Ocupacion As String = TxtOcupación.Text.Trim
        Dim Estudios As String = TxtEstudios.Text.Trim
        Dim Informante As String = TxtInformante.Text.Trim

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles BtnModificar.Paint


    End Sub
End Class