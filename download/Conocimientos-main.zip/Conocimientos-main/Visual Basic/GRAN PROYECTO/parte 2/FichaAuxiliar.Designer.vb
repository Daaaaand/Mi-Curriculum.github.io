﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FichaAuxiliar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TxtContactosecundario = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TxtTeléfono2 = New System.Windows.Forms.TextBox()
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TxtDirección = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TxtTeléfono1 = New System.Windows.Forms.TextBox()
        Me.TxtApellido = New System.Windows.Forms.TextBox()
        Me.TxtNombre = New System.Windows.Forms.TextBox()
        Me.TxtCi = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Teléfono = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.RbnFemenino = New System.Windows.Forms.RadioButton()
        Me.RbnMasculino = New System.Windows.Forms.RadioButton()
        Me.ChxCti = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CbxArea = New System.Windows.Forms.ComboBox()
        Me.CbxHorario = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TxtTeléfonosecundario = New System.Windows.Forms.TextBox()
        Me.Tel = New System.Windows.Forms.Label()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.TxtFecha = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnEliminar = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BtnImprimir = New System.Windows.Forms.Button()
        Me.DtpF = New System.Windows.Forms.DateTimePicker()
        Me.PicturAuxiliar = New System.Windows.Forms.PictureBox()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PicturAuxiliar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TxtContactosecundario
        '
        Me.TxtContactosecundario.Location = New System.Drawing.Point(391, 330)
        Me.TxtContactosecundario.Name = "TxtContactosecundario"
        Me.TxtContactosecundario.Size = New System.Drawing.Size(98, 20)
        Me.TxtContactosecundario.TabIndex = 65
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(490, 111)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(37, 13)
        Me.Label14.TabIndex = 64
        Me.Label14.Text = "Fecha"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(484, 251)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(12, 13)
        Me.Label13.TabIndex = 63
        Me.Label13.Text = "/"
        '
        'TxtTeléfono2
        '
        Me.TxtTeléfono2.Location = New System.Drawing.Point(501, 248)
        Me.TxtTeléfono2.Name = "TxtTeléfono2"
        Me.TxtTeléfono2.Size = New System.Drawing.Size(86, 20)
        Me.TxtTeléfono2.TabIndex = 62
        '
        'TxtEmail
        '
        Me.TxtEmail.Location = New System.Drawing.Point(91, 330)
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(202, 20)
        Me.TxtEmail.TabIndex = 61
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(26, 333)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(32, 13)
        Me.Label12.TabIndex = 60
        Me.Label12.Text = "Email"
        '
        'TxtDirección
        '
        Me.TxtDirección.Location = New System.Drawing.Point(91, 248)
        Me.TxtDirección.Name = "TxtDirección"
        Me.TxtDirección.Size = New System.Drawing.Size(224, 20)
        Me.TxtDirección.TabIndex = 59
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(25, 251)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(52, 13)
        Me.Label11.TabIndex = 58
        Me.Label11.Text = "Dirección"
        '
        'TxtTeléfono1
        '
        Me.TxtTeléfono1.Location = New System.Drawing.Point(392, 248)
        Me.TxtTeléfono1.Name = "TxtTeléfono1"
        Me.TxtTeléfono1.Size = New System.Drawing.Size(86, 20)
        Me.TxtTeléfono1.TabIndex = 50
        '
        'TxtApellido
        '
        Me.TxtApellido.Location = New System.Drawing.Point(330, 108)
        Me.TxtApellido.Name = "TxtApellido"
        Me.TxtApellido.Size = New System.Drawing.Size(148, 20)
        Me.TxtApellido.TabIndex = 48
        '
        'TxtNombre
        '
        Me.TxtNombre.Location = New System.Drawing.Point(91, 107)
        Me.TxtNombre.Name = "TxtNombre"
        Me.TxtNombre.Size = New System.Drawing.Size(171, 20)
        Me.TxtNombre.TabIndex = 47
        '
        'TxtCi
        '
        Me.TxtCi.Location = New System.Drawing.Point(93, 176)
        Me.TxtCi.Name = "TxtCi"
        Me.TxtCi.Size = New System.Drawing.Size(100, 20)
        Me.TxtCi.TabIndex = 46
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(268, 110)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(47, 13)
        Me.Label10.TabIndex = 45
        Me.Label10.Text = "Apellido "
        '
        'Teléfono
        '
        Me.Teléfono.AutoSize = True
        Me.Teléfono.Location = New System.Drawing.Point(327, 251)
        Me.Teléfono.Name = "Teléfono"
        Me.Teléfono.Size = New System.Drawing.Size(49, 13)
        Me.Teléfono.TabIndex = 44
        Me.Teléfono.Text = "Teléfono"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(209, 178)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(108, 13)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "Fecha de Nacimiento"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(28, 178)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 42
        Me.Label2.Text = "Cédula"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 111)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 41
        Me.Label1.Text = "Nombre"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(656, 268)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(42, 13)
        Me.Label7.TabIndex = 68
        Me.Label7.Text = "Género"
        '
        'RbnFemenino
        '
        Me.RbnFemenino.AutoSize = True
        Me.RbnFemenino.Location = New System.Drawing.Point(731, 284)
        Me.RbnFemenino.Name = "RbnFemenino"
        Me.RbnFemenino.Size = New System.Drawing.Size(31, 17)
        Me.RbnFemenino.TabIndex = 67
        Me.RbnFemenino.Text = "F"
        Me.RbnFemenino.UseVisualStyleBackColor = True
        '
        'RbnMasculino
        '
        Me.RbnMasculino.AutoSize = True
        Me.RbnMasculino.Checked = True
        Me.RbnMasculino.Location = New System.Drawing.Point(691, 284)
        Me.RbnMasculino.Name = "RbnMasculino"
        Me.RbnMasculino.Size = New System.Drawing.Size(34, 17)
        Me.RbnMasculino.TabIndex = 66
        Me.RbnMasculino.TabStop = True
        Me.RbnMasculino.Text = "M"
        Me.RbnMasculino.UseVisualStyleBackColor = True
        '
        'ChxCti
        '
        Me.ChxCti.AutoSize = True
        Me.ChxCti.Location = New System.Drawing.Point(29, 414)
        Me.ChxCti.Name = "ChxCti"
        Me.ChxCti.Size = New System.Drawing.Size(113, 17)
        Me.ChxCti.TabIndex = 71
        Me.ChxCti.Text = "Especialización cti"
        Me.ChxCti.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(162, 415)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 13)
        Me.Label3.TabIndex = 72
        Me.Label3.Text = "Area"
        '
        'CbxArea
        '
        Me.CbxArea.FormattingEnabled = True
        Me.CbxArea.Location = New System.Drawing.Point(210, 412)
        Me.CbxArea.Name = "CbxArea"
        Me.CbxArea.Size = New System.Drawing.Size(68, 21)
        Me.CbxArea.TabIndex = 73
        '
        'CbxHorario
        '
        Me.CbxHorario.FormattingEnabled = True
        Me.CbxHorario.Location = New System.Drawing.Point(360, 410)
        Me.CbxHorario.Name = "CbxHorario"
        Me.CbxHorario.Size = New System.Drawing.Size(87, 21)
        Me.CbxHorario.TabIndex = 77
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(304, 412)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(41, 13)
        Me.Label17.TabIndex = 76
        Me.Label17.Text = "Horario"
        '
        'TxtTeléfonosecundario
        '
        Me.TxtTeléfonosecundario.Location = New System.Drawing.Point(533, 330)
        Me.TxtTeléfonosecundario.Name = "TxtTeléfonosecundario"
        Me.TxtTeléfonosecundario.Size = New System.Drawing.Size(86, 20)
        Me.TxtTeléfonosecundario.TabIndex = 85
        '
        'Tel
        '
        Me.Tel.AutoSize = True
        Me.Tel.Location = New System.Drawing.Point(498, 333)
        Me.Tel.Name = "Tel"
        Me.Tel.Size = New System.Drawing.Size(22, 13)
        Me.Tel.TabIndex = 84
        Me.Tel.Text = "Tel"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'TxtFecha
        '
        Me.TxtFecha.Location = New System.Drawing.Point(533, 108)
        Me.TxtFecha.Name = "TxtFecha"
        Me.TxtFecha.Size = New System.Drawing.Size(97, 20)
        Me.TxtFecha.TabIndex = 88
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(327, 333)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 87
        Me.Label8.Text = "Contacto "
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnCancelar)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.BtnEliminar)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.BtnImprimir)
        Me.Panel1.Location = New System.Drawing.Point(29, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(732, 63)
        Me.Panel1.TabIndex = 89
        '
        'BtnCancelar
        '
        Me.BtnCancelar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnCancelar.Location = New System.Drawing.Point(431, 19)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelar.TabIndex = 67
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(24, 19)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 66
        Me.Button2.Text = "Guardar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'BtnEliminar
        '
        Me.BtnEliminar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnEliminar.Location = New System.Drawing.Point(304, 19)
        Me.BtnEliminar.Name = "BtnEliminar"
        Me.BtnEliminar.Size = New System.Drawing.Size(75, 23)
        Me.BtnEliminar.TabIndex = 65
        Me.BtnEliminar.Text = "Eliminar"
        Me.BtnEliminar.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(207, 19)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 64
        Me.Button1.Text = "Modificar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BtnImprimir
        '
        Me.BtnImprimir.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnImprimir.Location = New System.Drawing.Point(116, 19)
        Me.BtnImprimir.Name = "BtnImprimir"
        Me.BtnImprimir.Size = New System.Drawing.Size(75, 23)
        Me.BtnImprimir.TabIndex = 63
        Me.BtnImprimir.Text = "Imprimir"
        Me.BtnImprimir.UseVisualStyleBackColor = True
        '
        'DtpF
        '
        Me.DtpF.Location = New System.Drawing.Point(335, 176)
        Me.DtpF.Name = "DtpF"
        Me.DtpF.Size = New System.Drawing.Size(200, 20)
        Me.DtpF.TabIndex = 90
        '
        'PicturAuxiliar
        '
        Me.PicturAuxiliar.Location = New System.Drawing.Point(643, 142)
        Me.PicturAuxiliar.Name = "PicturAuxiliar"
        Me.PicturAuxiliar.Size = New System.Drawing.Size(111, 112)
        Me.PicturAuxiliar.TabIndex = 51
        Me.PicturAuxiliar.TabStop = False
        '
        'FichaAuxiliar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(976, 613)
        Me.Controls.Add(Me.DtpF)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TxtFecha)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TxtTeléfonosecundario)
        Me.Controls.Add(Me.Tel)
        Me.Controls.Add(Me.CbxHorario)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.CbxArea)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ChxCti)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.RbnFemenino)
        Me.Controls.Add(Me.RbnMasculino)
        Me.Controls.Add(Me.TxtContactosecundario)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TxtTeléfono2)
        Me.Controls.Add(Me.TxtEmail)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.TxtDirección)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.PicturAuxiliar)
        Me.Controls.Add(Me.TxtTeléfono1)
        Me.Controls.Add(Me.TxtApellido)
        Me.Controls.Add(Me.TxtNombre)
        Me.Controls.Add(Me.TxtCi)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Teléfono)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Name = "FichaAuxiliar"
        Me.Text = " Ficha Auxiliar"
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        CType(Me.PicturAuxiliar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TxtContactosecundario As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TxtTeléfono2 As System.Windows.Forms.TextBox
    Friend WithEvents TxtEmail As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TxtDirección As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PicturAuxiliar As System.Windows.Forms.PictureBox
    Friend WithEvents TxtTeléfono1 As System.Windows.Forms.TextBox
    Friend WithEvents TxtApellido As System.Windows.Forms.TextBox
    Friend WithEvents TxtNombre As System.Windows.Forms.TextBox
    Friend WithEvents TxtCi As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Teléfono As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents RbnFemenino As System.Windows.Forms.RadioButton
    Friend WithEvents RbnMasculino As System.Windows.Forms.RadioButton
    Friend WithEvents ChxCti As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CbxArea As System.Windows.Forms.ComboBox
    Friend WithEvents CbxHorario As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TxtTeléfonosecundario As System.Windows.Forms.TextBox
    Friend WithEvents Tel As System.Windows.Forms.Label
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents TxtFecha As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents BtnEliminar As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents BtnImprimir As Button
    Friend WithEvents BtnCancelar As Button
    Friend WithEvents DtpF As DateTimePicker
End Class
