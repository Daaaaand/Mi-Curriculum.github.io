﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Menu_doctor
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Menu_doctor))
        Me.PanelFlecha = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FotoFlecha = New System.Windows.Forms.PictureBox()
        Me.PanelFormulario = New System.Windows.Forms.Panel()
        Me.BtnAtras = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.PanelSuperior = New System.Windows.Forms.Panel()
        Me.BtnInternacion = New System.Windows.Forms.Button()
        Me.BtnMis = New System.Windows.Forms.Button()
        Me.BtnCitas = New System.Windows.Forms.Button()
        Me.BtnConsulta = New System.Windows.Forms.Button()
        Me.BtnHistorial = New System.Windows.Forms.Button()
        Me.PanelLateral = New System.Windows.Forms.Panel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.PanelFlecha.SuspendLayout()
        CType(Me.FotoFlecha, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelFormulario.SuspendLayout()
        Me.PanelSuperior.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelFlecha
        '
        Me.PanelFlecha.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.PanelFlecha.Controls.Add(Me.Label2)
        Me.PanelFlecha.Controls.Add(Me.Label1)
        Me.PanelFlecha.Controls.Add(Me.FotoFlecha)
        Me.PanelFlecha.Controls.Add(Me.PanelFormulario)
        Me.PanelFlecha.Location = New System.Drawing.Point(0, 1)
        Me.PanelFlecha.Name = "PanelFlecha"
        Me.PanelFlecha.Size = New System.Drawing.Size(310, 86)
        Me.PanelFlecha.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label2.Location = New System.Drawing.Point(127, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 13)
        Me.Label2.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(38, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "FECHA : "
        '
        'FotoFlecha
        '
        Me.FotoFlecha.Image = CType(resources.GetObject("FotoFlecha.Image"), System.Drawing.Image)
        Me.FotoFlecha.Location = New System.Drawing.Point(3, 26)
        Me.FotoFlecha.Name = "FotoFlecha"
        Me.FotoFlecha.Size = New System.Drawing.Size(304, 60)
        Me.FotoFlecha.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.FotoFlecha.TabIndex = 0
        Me.FotoFlecha.TabStop = False
        '
        'PanelFormulario
        '
        Me.PanelFormulario.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelFormulario.Controls.Add(Me.BtnAtras)
        Me.PanelFormulario.Controls.Add(Me.Panel1)
        Me.PanelFormulario.Controls.Add(Me.Button8)
        Me.PanelFormulario.Location = New System.Drawing.Point(316, 57)
        Me.PanelFormulario.Name = "PanelFormulario"
        Me.PanelFormulario.Size = New System.Drawing.Size(738, 668)
        Me.PanelFormulario.TabIndex = 4
        '
        'BtnAtras
        '
        Me.BtnAtras.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnAtras.Location = New System.Drawing.Point(233, 223)
        Me.BtnAtras.Name = "BtnAtras"
        Me.BtnAtras.Size = New System.Drawing.Size(177, 92)
        Me.BtnAtras.TabIndex = 3
        Me.BtnAtras.Text = "Button1"
        Me.BtnAtras.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel1.Location = New System.Drawing.Point(204, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(844, 106)
        Me.Panel1.TabIndex = 1
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.FromArgb(CType(CType(11, Byte), Integer), CType(CType(7, Byte), Integer), CType(CType(21, Byte), Integer))
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button8.Location = New System.Drawing.Point(85, 343)
        Me.Button8.Name = "Button8"
        Me.Button8.Padding = New System.Windows.Forms.Padding(35, 0, 0, 0)
        Me.Button8.Size = New System.Drawing.Size(84, 32)
        Me.Button8.TabIndex = 3
        Me.Button8.Text = "Button8"
        Me.Button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button8.UseVisualStyleBackColor = False
        '
        'PanelSuperior
        '
        Me.PanelSuperior.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.PanelSuperior.Controls.Add(Me.BtnInternacion)
        Me.PanelSuperior.Controls.Add(Me.BtnMis)
        Me.PanelSuperior.Controls.Add(Me.BtnCitas)
        Me.PanelSuperior.Controls.Add(Me.BtnConsulta)
        Me.PanelSuperior.Controls.Add(Me.BtnHistorial)
        Me.PanelSuperior.Location = New System.Drawing.Point(310, 1)
        Me.PanelSuperior.Name = "PanelSuperior"
        Me.PanelSuperior.Size = New System.Drawing.Size(972, 86)
        Me.PanelSuperior.TabIndex = 6
        '
        'BtnInternacion
        '
        Me.BtnInternacion.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnInternacion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnInternacion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnInternacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnInternacion.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnInternacion.Location = New System.Drawing.Point(548, 3)
        Me.BtnInternacion.Name = "BtnInternacion"
        Me.BtnInternacion.Size = New System.Drawing.Size(183, 76)
        Me.BtnInternacion.TabIndex = 5
        Me.BtnInternacion.Text = "Internación"
        Me.BtnInternacion.UseVisualStyleBackColor = False
        '
        'BtnMis
        '
        Me.BtnMis.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnMis.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnMis.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnMis.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMis.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnMis.Location = New System.Drawing.Point(727, 3)
        Me.BtnMis.Name = "BtnMis"
        Me.BtnMis.Size = New System.Drawing.Size(183, 76)
        Me.BtnMis.TabIndex = 4
        Me.BtnMis.Text = "Mis"
        Me.BtnMis.UseVisualStyleBackColor = False
        '
        'BtnCitas
        '
        Me.BtnCitas.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnCitas.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnCitas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnCitas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCitas.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnCitas.Location = New System.Drawing.Point(365, 3)
        Me.BtnCitas.Name = "BtnCitas"
        Me.BtnCitas.Size = New System.Drawing.Size(186, 76)
        Me.BtnCitas.TabIndex = 3
        Me.BtnCitas.Text = "Citas"
        Me.BtnCitas.UseVisualStyleBackColor = False
        '
        'BtnConsulta
        '
        Me.BtnConsulta.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnConsulta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnConsulta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnConsulta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnConsulta.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnConsulta.Location = New System.Drawing.Point(183, 3)
        Me.BtnConsulta.Name = "BtnConsulta"
        Me.BtnConsulta.Size = New System.Drawing.Size(186, 76)
        Me.BtnConsulta.TabIndex = 1
        Me.BtnConsulta.Text = "Consulta"
        Me.BtnConsulta.UseVisualStyleBackColor = False
        '
        'BtnHistorial
        '
        Me.BtnHistorial.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnHistorial.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnHistorial.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnHistorial.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnHistorial.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnHistorial.Location = New System.Drawing.Point(0, 3)
        Me.BtnHistorial.Name = "BtnHistorial"
        Me.BtnHistorial.Size = New System.Drawing.Size(186, 76)
        Me.BtnHistorial.TabIndex = 0
        Me.BtnHistorial.Text = "Historial clínico"
        Me.BtnHistorial.UseVisualStyleBackColor = False
        '
        'PanelLateral
        '
        Me.PanelLateral.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelLateral.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PanelLateral.Location = New System.Drawing.Point(0, 86)
        Me.PanelLateral.Name = "PanelLateral"
        Me.PanelLateral.Size = New System.Drawing.Size(1282, 599)
        Me.PanelLateral.TabIndex = 7
        '
        'Timer1
        '
        '
        'Menu_doctor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1283, 684)
        Me.Controls.Add(Me.PanelLateral)
        Me.Controls.Add(Me.PanelSuperior)
        Me.Controls.Add(Me.PanelFlecha)
        Me.MinimumSize = New System.Drawing.Size(900, 550)
        Me.Name = "Menu_doctor"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu Doctor"
        Me.PanelFlecha.ResumeLayout(False)
        Me.PanelFlecha.PerformLayout()
        CType(Me.FotoFlecha, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelFormulario.ResumeLayout(False)
        Me.PanelSuperior.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelFlecha As Panel
    Friend WithEvents Button8 As Button
    Friend WithEvents FotoFlecha As PictureBox
    Friend WithEvents PanelFormulario As Panel
    Friend WithEvents BtnAtras As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PanelSuperior As Panel
    Friend WithEvents BtnConsulta As Button
    Friend WithEvents BtnCitas As Button
    Friend WithEvents BtnHistorial As Button
    Friend WithEvents BtnMis As Button
    Friend WithEvents PanelLateral As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents BtnInternacion As Button
End Class
