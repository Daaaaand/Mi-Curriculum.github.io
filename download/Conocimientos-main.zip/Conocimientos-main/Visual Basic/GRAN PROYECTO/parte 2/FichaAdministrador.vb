﻿Imports System.ComponentModel
Imports System.Text.RegularExpressions

Public Class FichaAdministrador
    Private Sub FichaAdministrador_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TxtNombre_TextChanged(sender As Object, e As EventArgs) Handles TxtNombre.TextChanged

    End Sub

    Private Sub TxtNombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtNombre.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub

    Private Sub TxtApellido_TextChanged(sender As Object, e As EventArgs) Handles TxtApellido.TextChanged


    End Sub

    Private Sub TxtApellido_KeyDown(sender As Object, e As KeyEventArgs) Handles TxtApellido.KeyDown


    End Sub

    Private Sub TxtContacto_TextChanged(sender As Object, e As EventArgs) Handles TxtContacto.TextChanged

    End Sub

    Private Sub TxtContacto_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtContacto.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub

    Private Sub TxtCI_TextChanged(sender As Object, e As EventArgs) Handles TxtCI.TextChanged

    End Sub

    Private Sub TxtApellido_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtApellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If

    End Sub

    Private Sub TxtCI_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCI.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtTelefono1_TextChanged(sender As Object, e As EventArgs) Handles TxtTelefono1.TextChanged

    End Sub

    Private Sub TxtTelefono1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtTelefono1.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtTelefono2_TextChanged(sender As Object, e As EventArgs) Handles TxtTelefono2.TextChanged

    End Sub

    Private Sub TxtTelefono2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtTelefono2.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtContactoTel_TextChanged(sender As Object, e As EventArgs) Handles TxtContactoTel.TextChanged

    End Sub

    Private Sub TxtContactoTel_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtContactoTel.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtEmail_TextChanged(sender As Object, e As EventArgs) Handles TxtEmail.TextChanged

    End Sub

    Private Sub TxtEmail_Validating(sender As Object, e As CancelEventArgs) Handles TxtEmail.Validating
        Dim EmailPaciente As String
        EmailPaciente = "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"
        If Regex.IsMatch(TxtEmail.Text, EmailPaciente) Then

        Else
            ErrorProvider1.SetError(TxtEmail, "Ingrese un email válido")
        End If
    End Sub

    Private Sub BtnGuardar_Click(sender As Object, e As EventArgs) Handles BtnGuardar.Click
        Dim nombre As String = TxtNombre.Text.Trim
        Dim apellido As String = TxtApellido.Text.Trim
        Dim ci As String = TxtCI.Text.Trim
        Dim Email As String = TxtEmail.Text.Trim
        Dim Telefono As String = TxtTelefono1.Text.Trim
        Dim Telefono2 As String = TxtTelefono2.Text.Trim
        Dim ContactoE As String = TxtContacto.Text.Trim
        Dim TelefonoE As String = TxtContactoTel.Text.Trim
    End Sub
End Class