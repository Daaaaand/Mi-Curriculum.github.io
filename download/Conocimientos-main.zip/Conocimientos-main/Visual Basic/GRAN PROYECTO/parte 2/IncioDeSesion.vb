﻿Imports MySql.Data.MySqlClient

Public Class IncioDeSesion

    Private Sub BtnIngresar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnIngresar.Click
        Dim cx As New MySqlConnection
        Dim cm As New MySqlCommand
        Dim lector As MySqlDataReader

        If CbxTipo.Text = "Administrador" Then
            Try
                cx.ConnectionString = "server=192.168.2.195;database=administrador;user=" + TxtCi.Text + ";password=" + TxtContraseña.Text
                cx.Open()
                cm.Connection = cx
                MenuAdministrador.Show()
                Me.Close()
            Catch ex As Exception
                MsgBox("Error!")
            End Try
            Me.Close()
        ElseIf CbxTipo.Text = "Médico" Then
            Menu_doctor.Show()
            Me.Close()
        ElseIf CbxTipo.Text = "Auxiliar" Then
            MenuAuxiliar.Show()
            Me.Close()
        Else
            MenuPaciente.Show()
            Me.Close()
        End If
    End Sub

    Private Sub IncioDeSesion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class