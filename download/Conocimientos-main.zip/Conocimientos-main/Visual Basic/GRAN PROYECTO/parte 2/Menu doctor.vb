﻿Public Class Menu_doctor

    Private Sub openchildform(childform As Object)
        If (PanelLateral.Controls.Count > 0) Then
            PanelLateral.Controls.RemoveAt(0)
        End If
        Dim frm As Form
        frm = childform
        frm.TopLevel = False
        frm.Dock = DockStyle.Fill
        frm.FormBorderStyle = FormBorderStyle.None
        PanelLateral.Controls.Add(frm)
        PanelLateral.Tag = frm
        frm.Show()

    End Sub

    Private Sub Menu_doctor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True

    End Sub




    'Private Sub AbrirFormPanel(Of MiForm As {Form, New})()
    '    Dim formulario As Form
    '    formulario = PanelFormulario.Controls.OfType(Of MiForm)().FirstOrDefault()
    '    If formulario Is Nothing Then
    '        formulario = New MiForm()
    '        formulario.TopLevel = False
    '        PanelFormulario.Controls.Add(formulario)
    '        PanelFormulario.Tag = formulario
    '        formulario.Show()
    '        formulario.BringToFront()
    '    Else
    '        formulario.BringToFront()
    '    'End If
    'End Sub
    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles PanelFormulario.Paint

    End Sub

    Private Sub BtnHistorial_Click(sender As Object, e As EventArgs) Handles BtnHistorial.Click
        openchildform(New DoctorIngresarLateral)
    End Sub


    Private Sub BtnConsulta_Click(sender As Object, e As EventArgs) Handles BtnConsulta.Click
        openchildform(New DoctorConsultaLateral)
    End Sub

    Private Sub BtnCitas_Click(sender As Object, e As EventArgs) Handles BtnCitas.Click
        openchildform(New DoctorCitas)
    End Sub

    Private Sub BtnMis_Click(sender As Object, e As EventArgs) Handles BtnMis.Click
        openchildform(New DoctorMisLateral)
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label2.Text = DateTime.Now.ToString
    End Sub

    Private Sub BtnInternacion_Click(sender As Object, e As EventArgs) Handles BtnInternacion.Click
        openchildform(New DoctorInternacion)
    End Sub
End Class