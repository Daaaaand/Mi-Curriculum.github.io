﻿Public Class Verificación_Personal

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCi.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCi.TextChanged

    End Sub

    Private Sub TxtFecha_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtFecha.TextChanged
        Dim fecha As Date
        fecha = Date.Today
    End Sub

    Private Sub TxtFecha_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TxtFecha.Validating
        Dim NacimientoPaciente As DateTime
        If DateTime.TryParse(TxtFecha.Text, NacimientoPaciente) Then
            ErrorProvider1.SetError(TxtFecha, "El formato debe ser DD-MM-YY")
        End If
    End Sub

    Private Sub TextBox1_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

        Dim tiempo As Date
        tiempo = String.Format("{0:HH:mm:ss}", DateTime.Now)
    End Sub
End Class