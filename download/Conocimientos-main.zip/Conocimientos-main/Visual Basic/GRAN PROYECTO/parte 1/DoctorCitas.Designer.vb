﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorCitas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnBuscar = New System.Windows.Forms.Button()
        Me.CbxBuscar2 = New System.Windows.Forms.ComboBox()
        Me.TxtBuscar2 = New System.Windows.Forms.TextBox()
        Me.CbxBuscar1 = New System.Windows.Forms.ComboBox()
        Me.TxtBuscar1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelMedio = New System.Windows.Forms.Panel()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        Me.PanelMedio.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnBuscar)
        Me.Panel1.Controls.Add(Me.CbxBuscar2)
        Me.Panel1.Controls.Add(Me.TxtBuscar2)
        Me.Panel1.Controls.Add(Me.CbxBuscar1)
        Me.Panel1.Controls.Add(Me.TxtBuscar1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(309, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(920, 67)
        Me.Panel1.TabIndex = 22
        '
        'BtnBuscar
        '
        Me.BtnBuscar.Location = New System.Drawing.Point(453, 21)
        Me.BtnBuscar.Name = "BtnBuscar"
        Me.BtnBuscar.Size = New System.Drawing.Size(87, 24)
        Me.BtnBuscar.TabIndex = 5
        Me.BtnBuscar.Text = "Buscar"
        Me.BtnBuscar.UseVisualStyleBackColor = True
        '
        'CbxBuscar2
        '
        Me.CbxBuscar2.FormattingEnabled = True
        Me.CbxBuscar2.Location = New System.Drawing.Point(294, 5)
        Me.CbxBuscar2.Name = "CbxBuscar2"
        Me.CbxBuscar2.Size = New System.Drawing.Size(138, 21)
        Me.CbxBuscar2.TabIndex = 4
        '
        'TxtBuscar2
        '
        Me.TxtBuscar2.Location = New System.Drawing.Point(294, 37)
        Me.TxtBuscar2.Name = "TxtBuscar2"
        Me.TxtBuscar2.Size = New System.Drawing.Size(138, 20)
        Me.TxtBuscar2.TabIndex = 3
        '
        'CbxBuscar1
        '
        Me.CbxBuscar1.FormattingEnabled = True
        Me.CbxBuscar1.Location = New System.Drawing.Point(128, 5)
        Me.CbxBuscar1.Name = "CbxBuscar1"
        Me.CbxBuscar1.Size = New System.Drawing.Size(138, 21)
        Me.CbxBuscar1.TabIndex = 2
        '
        'TxtBuscar1
        '
        Me.TxtBuscar1.Location = New System.Drawing.Point(128, 37)
        Me.TxtBuscar1.Name = "TxtBuscar1"
        Me.TxtBuscar1.Size = New System.Drawing.Size(138, 20)
        Me.TxtBuscar1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(55, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Buscar por"
        '
        'PanelMedio
        '
        Me.PanelMedio.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelMedio.Controls.Add(Me.DataGridView1)
        Me.PanelMedio.Location = New System.Drawing.Point(309, 65)
        Me.PanelMedio.Name = "PanelMedio"
        Me.PanelMedio.Size = New System.Drawing.Size(843, 580)
        Me.PanelMedio.TabIndex = 21
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(128, 39)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(599, 415)
        Me.DataGridView1.TabIndex = 0
        '
        'DoctorCitas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1111, 649)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelMedio)
        Me.Name = "DoctorCitas"
        Me.Text = "DoctorCitas"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.PanelMedio.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnBuscar As Button
    Friend WithEvents CbxBuscar2 As ComboBox
    Friend WithEvents TxtBuscar2 As TextBox
    Friend WithEvents CbxBuscar1 As ComboBox
    Friend WithEvents TxtBuscar1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PanelMedio As Panel
    Friend WithEvents DataGridView1 As DataGridView
End Class
