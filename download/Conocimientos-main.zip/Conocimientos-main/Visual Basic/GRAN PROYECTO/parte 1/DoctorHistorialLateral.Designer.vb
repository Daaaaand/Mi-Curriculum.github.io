﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorHistorialLateral
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnEvolucion = New System.Windows.Forms.Button()
        Me.BtnBiometria = New System.Windows.Forms.Button()
        Me.BtnTratamiento = New System.Windows.Forms.Button()
        Me.BtnDiagnostico = New System.Windows.Forms.Button()
        Me.BtnExamen = New System.Windows.Forms.Button()
        Me.BtnAmnesis = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnBuscar = New System.Windows.Forms.Button()
        Me.CbxBuscar2 = New System.Windows.Forms.ComboBox()
        Me.TxtBuscar2 = New System.Windows.Forms.TextBox()
        Me.CbxBuscar1 = New System.Windows.Forms.ComboBox()
        Me.TxtBuscar1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelMedio = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnEvolucion
        '
        Me.BtnEvolucion.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnEvolucion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnEvolucion.FlatAppearance.BorderSize = 0
        Me.BtnEvolucion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnEvolucion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnEvolucion.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnEvolucion.Location = New System.Drawing.Point(2, 312)
        Me.BtnEvolucion.Name = "BtnEvolucion"
        Me.BtnEvolucion.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnEvolucion.Size = New System.Drawing.Size(291, 67)
        Me.BtnEvolucion.TabIndex = 14
        Me.BtnEvolucion.Text = "Evolución"
        Me.BtnEvolucion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnEvolucion.UseVisualStyleBackColor = False
        '
        'BtnBiometria
        '
        Me.BtnBiometria.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnBiometria.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnBiometria.FlatAppearance.BorderSize = 0
        Me.BtnBiometria.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnBiometria.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnBiometria.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnBiometria.Location = New System.Drawing.Point(2, 249)
        Me.BtnBiometria.Name = "BtnBiometria"
        Me.BtnBiometria.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnBiometria.Size = New System.Drawing.Size(291, 67)
        Me.BtnBiometria.TabIndex = 12
        Me.BtnBiometria.Text = "Biometría"
        Me.BtnBiometria.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnBiometria.UseVisualStyleBackColor = False
        '
        'BtnTratamiento
        '
        Me.BtnTratamiento.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnTratamiento.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnTratamiento.FlatAppearance.BorderSize = 0
        Me.BtnTratamiento.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnTratamiento.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTratamiento.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnTratamiento.Location = New System.Drawing.Point(2, 186)
        Me.BtnTratamiento.Name = "BtnTratamiento"
        Me.BtnTratamiento.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnTratamiento.Size = New System.Drawing.Size(291, 67)
        Me.BtnTratamiento.TabIndex = 11
        Me.BtnTratamiento.Text = "Tratamiento"
        Me.BtnTratamiento.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnTratamiento.UseVisualStyleBackColor = False
        '
        'BtnDiagnostico
        '
        Me.BtnDiagnostico.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnDiagnostico.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnDiagnostico.FlatAppearance.BorderSize = 0
        Me.BtnDiagnostico.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnDiagnostico.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnDiagnostico.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnDiagnostico.Location = New System.Drawing.Point(2, 122)
        Me.BtnDiagnostico.Name = "BtnDiagnostico"
        Me.BtnDiagnostico.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnDiagnostico.Size = New System.Drawing.Size(291, 67)
        Me.BtnDiagnostico.TabIndex = 10
        Me.BtnDiagnostico.Text = "Diágnostico"
        Me.BtnDiagnostico.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnDiagnostico.UseVisualStyleBackColor = False
        '
        'BtnExamen
        '
        Me.BtnExamen.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnExamen.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnExamen.FlatAppearance.BorderSize = 0
        Me.BtnExamen.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnExamen.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnExamen.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnExamen.Location = New System.Drawing.Point(2, 1)
        Me.BtnExamen.Name = "BtnExamen"
        Me.BtnExamen.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnExamen.Size = New System.Drawing.Size(291, 67)
        Me.BtnExamen.TabIndex = 9
        Me.BtnExamen.Text = "Examen"
        Me.BtnExamen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnExamen.UseVisualStyleBackColor = False
        '
        'BtnAmnesis
        '
        Me.BtnAmnesis.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnAmnesis.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnAmnesis.FlatAppearance.BorderSize = 0
        Me.BtnAmnesis.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnAmnesis.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAmnesis.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnAmnesis.Location = New System.Drawing.Point(2, 64)
        Me.BtnAmnesis.Name = "BtnAmnesis"
        Me.BtnAmnesis.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnAmnesis.Size = New System.Drawing.Size(291, 67)
        Me.BtnAmnesis.TabIndex = 8
        Me.BtnAmnesis.Text = "Amnesis"
        Me.BtnAmnesis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnAmnesis.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnBuscar)
        Me.Panel1.Controls.Add(Me.CbxBuscar2)
        Me.Panel1.Controls.Add(Me.TxtBuscar2)
        Me.Panel1.Controls.Add(Me.CbxBuscar1)
        Me.Panel1.Controls.Add(Me.TxtBuscar1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(310, 1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(920, 67)
        Me.Panel1.TabIndex = 20
        '
        'BtnBuscar
        '
        Me.BtnBuscar.Location = New System.Drawing.Point(444, 21)
        Me.BtnBuscar.Name = "BtnBuscar"
        Me.BtnBuscar.Size = New System.Drawing.Size(87, 24)
        Me.BtnBuscar.TabIndex = 5
        Me.BtnBuscar.Text = "Buscar"
        Me.BtnBuscar.UseVisualStyleBackColor = True
        '
        'CbxBuscar2
        '
        Me.CbxBuscar2.FormattingEnabled = True
        Me.CbxBuscar2.Location = New System.Drawing.Point(285, 5)
        Me.CbxBuscar2.Name = "CbxBuscar2"
        Me.CbxBuscar2.Size = New System.Drawing.Size(138, 21)
        Me.CbxBuscar2.TabIndex = 4
        '
        'TxtBuscar2
        '
        Me.TxtBuscar2.Location = New System.Drawing.Point(285, 37)
        Me.TxtBuscar2.Name = "TxtBuscar2"
        Me.TxtBuscar2.Size = New System.Drawing.Size(138, 20)
        Me.TxtBuscar2.TabIndex = 3
        '
        'CbxBuscar1
        '
        Me.CbxBuscar1.FormattingEnabled = True
        Me.CbxBuscar1.Location = New System.Drawing.Point(119, 5)
        Me.CbxBuscar1.Name = "CbxBuscar1"
        Me.CbxBuscar1.Size = New System.Drawing.Size(138, 21)
        Me.CbxBuscar1.TabIndex = 2
        '
        'TxtBuscar1
        '
        Me.TxtBuscar1.Location = New System.Drawing.Point(119, 37)
        Me.TxtBuscar1.Name = "TxtBuscar1"
        Me.TxtBuscar1.Size = New System.Drawing.Size(138, 20)
        Me.TxtBuscar1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(55, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Buscar por"
        '
        'PanelMedio
        '
        Me.PanelMedio.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelMedio.Location = New System.Drawing.Point(310, 64)
        Me.PanelMedio.Name = "PanelMedio"
        Me.PanelMedio.Size = New System.Drawing.Size(843, 580)
        Me.PanelMedio.TabIndex = 19
        '
        'DoctorHistorialLateral
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1111, 649)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelMedio)
        Me.Controls.Add(Me.BtnEvolucion)
        Me.Controls.Add(Me.BtnBiometria)
        Me.Controls.Add(Me.BtnTratamiento)
        Me.Controls.Add(Me.BtnDiagnostico)
        Me.Controls.Add(Me.BtnExamen)
        Me.Controls.Add(Me.BtnAmnesis)
        Me.Name = "DoctorHistorialLateral"
        Me.Text = "DoctorHistorialLateral"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnEvolucion As Button
    Friend WithEvents BtnBiometria As Button
    Friend WithEvents BtnTratamiento As Button
    Friend WithEvents BtnDiagnostico As Button
    Friend WithEvents BtnExamen As Button
    Friend WithEvents BtnAmnesis As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnBuscar As Button
    Friend WithEvents CbxBuscar2 As ComboBox
    Friend WithEvents TxtBuscar2 As TextBox
    Friend WithEvents CbxBuscar1 As ComboBox
    Friend WithEvents TxtBuscar1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PanelMedio As Panel
End Class
