﻿Public Class ConsultaP_M

    Private Sub ConsultaP_M_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub TxtConsultorio_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtConsultorio.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtConsultorio_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtConsultorio.TextChanged

    End Sub

    Private Sub TxtFecha_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtFecha_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim fecha As Date
        fecha = Date.Today



    End Sub

    Private Sub TxtCi_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TxtCi.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TxtCi_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtCi.TextChanged

    End Sub

    Private Sub TxtFecha_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
        Dim FechaPaciente As DateTime
        If DateTime.TryParse(TxtFecha.Text, FechaPaciente) Then
            ErrorProvider1.SetError(TxtFecha, "El formato debe ser DD-MM-YY")

        End If

    End Sub

    Private Sub TxtHora_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtHora.TextChanged

    End Sub

    Private Sub TxtHora_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TxtHora.Validating
        Dim HoraPaciente As Date
        HoraPaciente = String.Format("{0:HH:mm:ss}", DateTime.Now)
    End Sub

    Private Sub Label14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim fecha As Date
        fecha = Date.Today
        Text = fecha
    End Sub

    Private Sub BtnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnGuardar.Click
        Dim Consultorio As String = TxtConsultorio.Text.Trim
        Dim Fecha As String = TxtConsultorio.Text.Trim
        Dim Ci As String = TxtCi.Text.Trim
        Dim Cronica As String = TxtCronicas.Text.Trim
        Dim Remedios As String = TxtRemedios.Text.Trim
        Dim Operaciones As String = TxtOperaciones.Text.Trim
        Dim Alergia As String = TxtAlérgia.Text.Trim
        Dim RemediosN As String = TxtRemediosN.Text.Trim
    End Sub
End Class