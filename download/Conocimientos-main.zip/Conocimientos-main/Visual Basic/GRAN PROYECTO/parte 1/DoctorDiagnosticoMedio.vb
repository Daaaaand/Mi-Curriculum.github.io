﻿Public Class DoctorDiagnosticoMedio

End Class