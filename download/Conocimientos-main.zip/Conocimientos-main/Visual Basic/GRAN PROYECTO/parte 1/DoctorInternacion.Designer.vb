﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorInternacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TxtCi = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelMedio = New System.Windows.Forms.Panel()
        Me.TxtSala = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtCama = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BtnMediciones = New System.Windows.Forms.Button()
        Me.BtnRecetas = New System.Windows.Forms.Button()
        Me.BtnInternacion = New System.Windows.Forms.Button()
        Me.BtnGuardar = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TxtCama)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.TxtSala)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.TxtCi)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(326, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(843, 67)
        Me.Panel1.TabIndex = 20
        '
        'TxtCi
        '
        Me.TxtCi.Location = New System.Drawing.Point(129, 24)
        Me.TxtCi.Name = "TxtCi"
        Me.TxtCi.Size = New System.Drawing.Size(138, 20)
        Me.TxtCi.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(59, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "CI paciente:"
        '
        'PanelMedio
        '
        Me.PanelMedio.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelMedio.Location = New System.Drawing.Point(326, 65)
        Me.PanelMedio.Name = "PanelMedio"
        Me.PanelMedio.Size = New System.Drawing.Size(843, 580)
        Me.PanelMedio.TabIndex = 19
        '
        'TxtSala
        '
        Me.TxtSala.Location = New System.Drawing.Point(344, 24)
        Me.TxtSala.Name = "TxtSala"
        Me.TxtSala.Size = New System.Drawing.Size(138, 20)
        Me.TxtSala.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label2.Location = New System.Drawing.Point(290, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Nro Sala:"
        '
        'TxtCama
        '
        Me.TxtCama.Location = New System.Drawing.Point(581, 24)
        Me.TxtCama.Name = "TxtCama"
        Me.TxtCama.Size = New System.Drawing.Size(138, 20)
        Me.TxtCama.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label3.Location = New System.Drawing.Point(504, 27)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Nro de cama:"
        '
        'BtnMediciones
        '
        Me.BtnMediciones.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnMediciones.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnMediciones.FlatAppearance.BorderSize = 0
        Me.BtnMediciones.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnMediciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMediciones.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnMediciones.Location = New System.Drawing.Point(0, 129)
        Me.BtnMediciones.Name = "BtnMediciones"
        Me.BtnMediciones.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnMediciones.Size = New System.Drawing.Size(291, 67)
        Me.BtnMediciones.TabIndex = 23
        Me.BtnMediciones.Text = "Mediciones"
        Me.BtnMediciones.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnMediciones.UseVisualStyleBackColor = False
        '
        'BtnRecetas
        '
        Me.BtnRecetas.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnRecetas.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnRecetas.FlatAppearance.BorderSize = 0
        Me.BtnRecetas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnRecetas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRecetas.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnRecetas.Location = New System.Drawing.Point(0, 65)
        Me.BtnRecetas.Name = "BtnRecetas"
        Me.BtnRecetas.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnRecetas.Size = New System.Drawing.Size(291, 67)
        Me.BtnRecetas.TabIndex = 22
        Me.BtnRecetas.Text = "Recetas"
        Me.BtnRecetas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnRecetas.UseVisualStyleBackColor = False
        '
        'BtnInternacion
        '
        Me.BtnInternacion.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnInternacion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnInternacion.FlatAppearance.BorderSize = 0
        Me.BtnInternacion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnInternacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnInternacion.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnInternacion.Location = New System.Drawing.Point(0, 2)
        Me.BtnInternacion.Name = "BtnInternacion"
        Me.BtnInternacion.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnInternacion.Size = New System.Drawing.Size(291, 67)
        Me.BtnInternacion.TabIndex = 21
        Me.BtnInternacion.Text = "Internación"
        Me.BtnInternacion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnInternacion.UseVisualStyleBackColor = False
        '
        'BtnGuardar
        '
        Me.BtnGuardar.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnGuardar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnGuardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnGuardar.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnGuardar.Location = New System.Drawing.Point(0, 202)
        Me.BtnGuardar.Name = "BtnGuardar"
        Me.BtnGuardar.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnGuardar.Size = New System.Drawing.Size(310, 67)
        Me.BtnGuardar.TabIndex = 24
        Me.BtnGuardar.Text = "Guardar"
        Me.BtnGuardar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnGuardar.UseVisualStyleBackColor = False
        '
        'DoctorInternacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1169, 649)
        Me.Controls.Add(Me.BtnGuardar)
        Me.Controls.Add(Me.BtnMediciones)
        Me.Controls.Add(Me.BtnRecetas)
        Me.Controls.Add(Me.BtnInternacion)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelMedio)
        Me.Name = "DoctorInternacion"
        Me.Text = "DoctorInternacion"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents TxtCi As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PanelMedio As Panel
    Friend WithEvents TxtCama As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TxtSala As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents BtnMediciones As Button
    Friend WithEvents BtnRecetas As Button
    Friend WithEvents BtnInternacion As Button
    Friend WithEvents BtnGuardar As Button
End Class
