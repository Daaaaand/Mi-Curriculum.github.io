﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdministradorIngresarLateral
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BtnPaciente = New System.Windows.Forms.Button()
        Me.BtnMedico = New System.Windows.Forms.Button()
        Me.BtnAuxiliar = New System.Windows.Forms.Button()
        Me.BtnPersonal = New System.Windows.Forms.Button()
        Me.BtnAdministrador = New System.Windows.Forms.Button()
        Me.PanelMedio = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.BtnGuardar = New System.Windows.Forms.Button()
        Me.PanelMedio.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnPaciente
        '
        Me.BtnPaciente.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnPaciente.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnPaciente.FlatAppearance.BorderSize = 0
        Me.BtnPaciente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnPaciente.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPaciente.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnPaciente.Location = New System.Drawing.Point(1, 1)
        Me.BtnPaciente.Name = "BtnPaciente"
        Me.BtnPaciente.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnPaciente.Size = New System.Drawing.Size(291, 67)
        Me.BtnPaciente.TabIndex = 12
        Me.BtnPaciente.Text = "Paciente"
        Me.BtnPaciente.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPaciente.UseVisualStyleBackColor = False
        '
        'BtnMedico
        '
        Me.BtnMedico.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnMedico.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnMedico.FlatAppearance.BorderSize = 0
        Me.BtnMedico.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnMedico.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnMedico.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnMedico.Location = New System.Drawing.Point(1, 65)
        Me.BtnMedico.Name = "BtnMedico"
        Me.BtnMedico.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnMedico.Size = New System.Drawing.Size(291, 67)
        Me.BtnMedico.TabIndex = 13
        Me.BtnMedico.Text = "Médico"
        Me.BtnMedico.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnMedico.UseVisualStyleBackColor = False
        '
        'BtnAuxiliar
        '
        Me.BtnAuxiliar.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnAuxiliar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnAuxiliar.FlatAppearance.BorderSize = 0
        Me.BtnAuxiliar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnAuxiliar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAuxiliar.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnAuxiliar.Location = New System.Drawing.Point(1, 128)
        Me.BtnAuxiliar.Name = "BtnAuxiliar"
        Me.BtnAuxiliar.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnAuxiliar.Size = New System.Drawing.Size(291, 67)
        Me.BtnAuxiliar.TabIndex = 14
        Me.BtnAuxiliar.Text = "Auxiliar"
        Me.BtnAuxiliar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnAuxiliar.UseVisualStyleBackColor = False
        '
        'BtnPersonal
        '
        Me.BtnPersonal.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnPersonal.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnPersonal.FlatAppearance.BorderSize = 0
        Me.BtnPersonal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnPersonal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPersonal.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnPersonal.Location = New System.Drawing.Point(1, 201)
        Me.BtnPersonal.Name = "BtnPersonal"
        Me.BtnPersonal.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnPersonal.Size = New System.Drawing.Size(291, 67)
        Me.BtnPersonal.TabIndex = 15
        Me.BtnPersonal.Text = "Personal"
        Me.BtnPersonal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPersonal.UseVisualStyleBackColor = False
        '
        'BtnAdministrador
        '
        Me.BtnAdministrador.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnAdministrador.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnAdministrador.FlatAppearance.BorderSize = 0
        Me.BtnAdministrador.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.BtnAdministrador.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAdministrador.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnAdministrador.Location = New System.Drawing.Point(1, 264)
        Me.BtnAdministrador.Name = "BtnAdministrador"
        Me.BtnAdministrador.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnAdministrador.Size = New System.Drawing.Size(291, 67)
        Me.BtnAdministrador.TabIndex = 16
        Me.BtnAdministrador.Text = "Administrador"
        Me.BtnAdministrador.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnAdministrador.UseVisualStyleBackColor = False
        '
        'PanelMedio
        '
        Me.PanelMedio.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelMedio.Controls.Add(Me.Panel1)
        Me.PanelMedio.ForeColor = System.Drawing.SystemColors.ControlText
        Me.PanelMedio.Location = New System.Drawing.Point(331, 1)
        Me.PanelMedio.Name = "PanelMedio"
        Me.PanelMedio.Size = New System.Drawing.Size(992, 580)
        Me.PanelMedio.TabIndex = 17
        '
        'Panel1
        '
        Me.Panel1.Location = New System.Drawing.Point(40, 21)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(732, 63)
        Me.Panel1.TabIndex = 0
        '
        'Timer1
        '
        '
        'BtnGuardar
        '
        Me.BtnGuardar.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnGuardar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnGuardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnGuardar.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnGuardar.Location = New System.Drawing.Point(1, 337)
        Me.BtnGuardar.Name = "BtnGuardar"
        Me.BtnGuardar.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnGuardar.Size = New System.Drawing.Size(310, 67)
        Me.BtnGuardar.TabIndex = 21
        Me.BtnGuardar.Text = "Guardar"
        Me.BtnGuardar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnGuardar.UseVisualStyleBackColor = False
        '
        'AdministradorIngresarLateral
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1328, 582)
        Me.Controls.Add(Me.BtnGuardar)
        Me.Controls.Add(Me.PanelMedio)
        Me.Controls.Add(Me.BtnAdministrador)
        Me.Controls.Add(Me.BtnPersonal)
        Me.Controls.Add(Me.BtnAuxiliar)
        Me.Controls.Add(Me.BtnMedico)
        Me.Controls.Add(Me.BtnPaciente)
        Me.Name = "AdministradorIngresarLateral"
        Me.Text = "AdministradorIngresarLateral"
        Me.PanelMedio.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnPaciente As Button
    Friend WithEvents BtnMedico As Button
    Friend WithEvents BtnAuxiliar As Button
    Friend WithEvents BtnPersonal As Button
    Friend WithEvents BtnAdministrador As Button
    Friend WithEvents PanelMedio As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents BtnGuardar As Button
End Class
