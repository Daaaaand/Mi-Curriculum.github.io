﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Buscar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CbxBuscar1 = New System.Windows.Forms.ComboBox()
        Me.CbxBuscar2 = New System.Windows.Forms.ComboBox()
        Me.TxtBuscar2 = New System.Windows.Forms.TextBox()
        Me.TxtBuscar4 = New System.Windows.Forms.TextBox()
        Me.TxtBuscar3 = New System.Windows.Forms.TextBox()
        Me.CbxBuscar4 = New System.Windows.Forms.ComboBox()
        Me.CbxBuscar3 = New System.Windows.Forms.ComboBox()
        Me.BtnBuscar = New System.Windows.Forms.Button()
        Me.BtnEliminar = New System.Windows.Forms.Button()
        Me.BtnModifcar = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(374, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Buscar por"
        '
        'CbxBuscar1
        '
        Me.CbxBuscar1.FormattingEnabled = True
        Me.CbxBuscar1.Location = New System.Drawing.Point(438, 12)
        Me.CbxBuscar1.Name = "CbxBuscar1"
        Me.CbxBuscar1.Size = New System.Drawing.Size(100, 21)
        Me.CbxBuscar1.TabIndex = 1
        '
        'CbxBuscar2
        '
        Me.CbxBuscar2.FormattingEnabled = True
        Me.CbxBuscar2.Location = New System.Drawing.Point(592, 12)
        Me.CbxBuscar2.Name = "CbxBuscar2"
        Me.CbxBuscar2.Size = New System.Drawing.Size(100, 21)
        Me.CbxBuscar2.TabIndex = 2
        '
        'TxtBuscar2
        '
        Me.TxtBuscar2.Location = New System.Drawing.Point(592, 48)
        Me.TxtBuscar2.Name = "TxtBuscar2"
        Me.TxtBuscar2.Size = New System.Drawing.Size(100, 20)
        Me.TxtBuscar2.TabIndex = 4
        '
        'TxtBuscar4
        '
        Me.TxtBuscar4.Location = New System.Drawing.Point(899, 48)
        Me.TxtBuscar4.Name = "TxtBuscar4"
        Me.TxtBuscar4.Size = New System.Drawing.Size(100, 20)
        Me.TxtBuscar4.TabIndex = 8
        '
        'TxtBuscar3
        '
        Me.TxtBuscar3.Location = New System.Drawing.Point(744, 48)
        Me.TxtBuscar3.Name = "TxtBuscar3"
        Me.TxtBuscar3.Size = New System.Drawing.Size(100, 20)
        Me.TxtBuscar3.TabIndex = 7
        '
        'CbxBuscar4
        '
        Me.CbxBuscar4.FormattingEnabled = True
        Me.CbxBuscar4.Location = New System.Drawing.Point(899, 12)
        Me.CbxBuscar4.Name = "CbxBuscar4"
        Me.CbxBuscar4.Size = New System.Drawing.Size(100, 21)
        Me.CbxBuscar4.TabIndex = 6
        '
        'CbxBuscar3
        '
        Me.CbxBuscar3.FormattingEnabled = True
        Me.CbxBuscar3.Location = New System.Drawing.Point(744, 12)
        Me.CbxBuscar3.Name = "CbxBuscar3"
        Me.CbxBuscar3.Size = New System.Drawing.Size(100, 21)
        Me.CbxBuscar3.TabIndex = 5
        '
        'BtnBuscar
        '
        Me.BtnBuscar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnBuscar.Location = New System.Drawing.Point(1039, 30)
        Me.BtnBuscar.Name = "BtnBuscar"
        Me.BtnBuscar.Size = New System.Drawing.Size(75, 23)
        Me.BtnBuscar.TabIndex = 9
        Me.BtnBuscar.Text = "Buscar"
        Me.BtnBuscar.UseVisualStyleBackColor = True
        '
        'BtnEliminar
        '
        Me.BtnEliminar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnEliminar.Location = New System.Drawing.Point(1039, 184)
        Me.BtnEliminar.Name = "BtnEliminar"
        Me.BtnEliminar.Size = New System.Drawing.Size(75, 23)
        Me.BtnEliminar.TabIndex = 12
        Me.BtnEliminar.Text = "Eliminar"
        Me.BtnEliminar.UseVisualStyleBackColor = True
        '
        'BtnModifcar
        '
        Me.BtnModifcar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnModifcar.Location = New System.Drawing.Point(1039, 114)
        Me.BtnModifcar.Name = "BtnModifcar"
        Me.BtnModifcar.Size = New System.Drawing.Size(75, 23)
        Me.BtnModifcar.TabIndex = 13
        Me.BtnModifcar.Text = "Modificar"
        Me.BtnModifcar.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(377, 114)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(622, 443)
        Me.DataGridView1.TabIndex = 14
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.Panel1.Location = New System.Drawing.Point(1, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(322, 581)
        Me.Panel1.TabIndex = 15
        '
        'Buscar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1174, 582)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.BtnModifcar)
        Me.Controls.Add(Me.BtnEliminar)
        Me.Controls.Add(Me.BtnBuscar)
        Me.Controls.Add(Me.TxtBuscar4)
        Me.Controls.Add(Me.TxtBuscar3)
        Me.Controls.Add(Me.CbxBuscar4)
        Me.Controls.Add(Me.CbxBuscar3)
        Me.Controls.Add(Me.TxtBuscar2)
        Me.Controls.Add(Me.CbxBuscar2)
        Me.Controls.Add(Me.CbxBuscar1)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Name = "Buscar"
        Me.Text = "Buscar"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CbxBuscar1 As System.Windows.Forms.ComboBox
    Friend WithEvents CbxBuscar2 As System.Windows.Forms.ComboBox
    Friend WithEvents TxtBuscar2 As System.Windows.Forms.TextBox
    Friend WithEvents TxtBuscar4 As System.Windows.Forms.TextBox
    Friend WithEvents TxtBuscar3 As System.Windows.Forms.TextBox
    Friend WithEvents CbxBuscar4 As System.Windows.Forms.ComboBox
    Friend WithEvents CbxBuscar3 As System.Windows.Forms.ComboBox
    Friend WithEvents BtnBuscar As System.Windows.Forms.Button
    Friend WithEvents BtnEliminar As System.Windows.Forms.Button
    Friend WithEvents BtnModifcar As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Panel1 As Panel
End Class
