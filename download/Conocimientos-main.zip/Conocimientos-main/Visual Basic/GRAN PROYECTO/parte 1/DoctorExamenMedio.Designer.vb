﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorExamenMedio
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LbxInspeccion = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtPalpacion = New System.Windows.Forms.TextBox()
        Me.TxtPercusion = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtAuscultacion = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtOlfacion = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.CbxTipo = New System.Windows.Forms.ComboBox()
        Me.LbxResultado = New System.Windows.Forms.ListBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.BtnGuardar = New System.Windows.Forms.Button()
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.BtnImprimir = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(53, 54)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(133, 34)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Examen físico"
        '
        'Label2
        '
        Me.Label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label2.Location = New System.Drawing.Point(435, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(229, 34)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Examen complementario"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label3.Location = New System.Drawing.Point(55, 136)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Inspección"
        '
        'LbxInspeccion
        '
        Me.LbxInspeccion.FormattingEnabled = True
        Me.LbxInspeccion.Location = New System.Drawing.Point(135, 136)
        Me.LbxInspeccion.Name = "LbxInspeccion"
        Me.LbxInspeccion.Size = New System.Drawing.Size(276, 69)
        Me.LbxInspeccion.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label4.Location = New System.Drawing.Point(55, 266)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Palpación"
        '
        'TxtPalpacion
        '
        Me.TxtPalpacion.Location = New System.Drawing.Point(135, 263)
        Me.TxtPalpacion.Name = "TxtPalpacion"
        Me.TxtPalpacion.Size = New System.Drawing.Size(276, 20)
        Me.TxtPalpacion.TabIndex = 5
        '
        'TxtPercusion
        '
        Me.TxtPercusion.Location = New System.Drawing.Point(135, 335)
        Me.TxtPercusion.Name = "TxtPercusion"
        Me.TxtPercusion.Size = New System.Drawing.Size(276, 20)
        Me.TxtPercusion.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label5.Location = New System.Drawing.Point(55, 338)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Percusión"
        '
        'TxtAuscultacion
        '
        Me.TxtAuscultacion.Location = New System.Drawing.Point(135, 398)
        Me.TxtAuscultacion.Name = "TxtAuscultacion"
        Me.TxtAuscultacion.Size = New System.Drawing.Size(276, 20)
        Me.TxtAuscultacion.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label6.Location = New System.Drawing.Point(55, 401)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(68, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Auscultación"
        '
        'TxtOlfacion
        '
        Me.TxtOlfacion.Location = New System.Drawing.Point(135, 465)
        Me.TxtOlfacion.Name = "TxtOlfacion"
        Me.TxtOlfacion.Size = New System.Drawing.Size(276, 20)
        Me.TxtOlfacion.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label7.Location = New System.Drawing.Point(55, 468)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Olfación"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label8.Location = New System.Drawing.Point(437, 136)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Tipo"
        '
        'CbxTipo
        '
        Me.CbxTipo.FormattingEnabled = True
        Me.CbxTipo.Location = New System.Drawing.Point(501, 133)
        Me.CbxTipo.Name = "CbxTipo"
        Me.CbxTipo.Size = New System.Drawing.Size(163, 21)
        Me.CbxTipo.TabIndex = 13
        '
        'LbxResultado
        '
        Me.LbxResultado.FormattingEnabled = True
        Me.LbxResultado.Location = New System.Drawing.Point(501, 263)
        Me.LbxResultado.Name = "LbxResultado"
        Me.LbxResultado.Size = New System.Drawing.Size(276, 69)
        Me.LbxResultado.TabIndex = 15
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label9.Location = New System.Drawing.Point(421, 263)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Resultado"
        '
        'BtnGuardar
        '
        Me.BtnGuardar.Location = New System.Drawing.Point(706, 463)
        Me.BtnGuardar.Name = "BtnGuardar"
        Me.BtnGuardar.Size = New System.Drawing.Size(75, 23)
        Me.BtnGuardar.TabIndex = 16
        Me.BtnGuardar.Text = "Guardar"
        Me.BtnGuardar.UseVisualStyleBackColor = True
        '
        'BtnCancelar
        '
        Me.BtnCancelar.Location = New System.Drawing.Point(612, 463)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelar.TabIndex = 17
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'BtnImprimir
        '
        Me.BtnImprimir.Location = New System.Drawing.Point(460, 463)
        Me.BtnImprimir.Name = "BtnImprimir"
        Me.BtnImprimir.Size = New System.Drawing.Size(75, 23)
        Me.BtnImprimir.TabIndex = 18
        Me.BtnImprimir.Text = "Imprimir"
        Me.BtnImprimir.UseVisualStyleBackColor = True
        '
        'DoctorExamenMedio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(827, 541)
        Me.Controls.Add(Me.BtnImprimir)
        Me.Controls.Add(Me.BtnCancelar)
        Me.Controls.Add(Me.BtnGuardar)
        Me.Controls.Add(Me.LbxResultado)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.CbxTipo)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TxtOlfacion)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TxtAuscultacion)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TxtPercusion)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TxtPalpacion)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LbxInspeccion)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "DoctorExamenMedio"
        Me.Text = "DoctorExamenMedio"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents LbxInspeccion As ListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TxtPalpacion As TextBox
    Friend WithEvents TxtPercusion As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TxtAuscultacion As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtOlfacion As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents CbxTipo As ComboBox
    Friend WithEvents LbxResultado As ListBox
    Friend WithEvents Label9 As Label
    Friend WithEvents BtnGuardar As Button
    Friend WithEvents BtnCancelar As Button
    Friend WithEvents BtnImprimir As Button
End Class
