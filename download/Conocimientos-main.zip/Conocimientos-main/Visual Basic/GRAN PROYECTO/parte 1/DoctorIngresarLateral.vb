﻿Public Class DoctorIngresarLateral
    Private Sub openchildform(childform As Object)
        If (PanelMedio.Controls.Count > 0) Then
            PanelMedio.Controls.RemoveAt(0)
        End If
        Dim frm As Form
        frm = childform
        frm.TopLevel = False
        frm.Dock = DockStyle.Fill
        frm.FormBorderStyle = FormBorderStyle.None
        PanelMedio.Controls.Add(frm)
        PanelMedio.Tag = frm
        frm.Show()

    End Sub
    Private Sub DoctorIngresarLateral_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BtnExamen_Click(sender As Object, e As EventArgs) Handles BtnExamen.Click
        openchildform(New DoctorExamenMedio)
    End Sub

    Private Sub BtnAmnesis_Click(sender As Object, e As EventArgs)
        openchildform(New DoctorAmnesisMedio)
    End Sub

    Private Sub BtnDiagnostico_Click(sender As Object, e As EventArgs) Handles BtnDiagnostico.Click
        openchildform(New DoctorDiagnosticoMedio)
    End Sub

    Private Sub BtnTratamiento_Click(sender As Object, e As EventArgs) Handles BtnTratamiento.Click
        openchildform(New DoctorTratamientoMedio)
    End Sub

    Private Sub BtnBiometria_Click(sender As Object, e As EventArgs) Handles BtnBiometria.Click
        openchildform(New DoctorBiometriaMedio)
    End Sub

    Private Sub BtnRecetas_Click(sender As Object, e As EventArgs) Handles BtnRecetas.Click
        openchildform(New DoctorRecetasMedio)
    End Sub

    Private Sub BtnEvolucion_Click(sender As Object, e As EventArgs) Handles BtnEvolucion.Click
        openchildform(New DoctorEvolucionMedio)
    End Sub

    Private Sub BtnBuscar_Click(sender As Object, e As EventArgs) Handles BtnBuscar.Click
        Label1.Text = "Buscar por"
        TxtCi.Visible = False
        CbxBuscar1.Visible = True
        CbxBuscar2.Visible = True
        TxtBuscar1.Visible = True
        TxtBuscar2.Visible = True
        BtnBuscar2.Visible = True

    End Sub

    Private Sub TxtCi_TextChanged(sender As Object, e As EventArgs) Handles TxtCi.TextChanged

    End Sub

    Private Sub TxtCi_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TxtCi.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
End Class