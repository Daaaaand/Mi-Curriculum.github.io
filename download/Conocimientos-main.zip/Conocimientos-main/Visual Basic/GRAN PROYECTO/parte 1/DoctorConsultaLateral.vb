﻿Public Class DoctorConsultaLateral
    Private Sub openchildform(childform As Object)
        If (PanelMedio.Controls.Count > 0) Then
            PanelMedio.Controls.RemoveAt(0)
        End If
        Dim frm As Form
        frm = childform
        frm.TopLevel = False
        frm.Dock = DockStyle.Fill
        frm.FormBorderStyle = FormBorderStyle.None
        PanelMedio.Controls.Add(frm)
        PanelMedio.Tag = frm
        frm.Show()

    End Sub
    Private Sub BtnAnamnesis_Click(sender As Object, e As EventArgs) Handles BtnAnamnesis.Click
        openchildform(New DoctorAmnesisMedio)
    End Sub

    Private Sub DoctorConsultaLateral_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BtnAnalisis_Click(sender As Object, e As EventArgs) Handles BtnAnalisis.Click
        openchildform(New DoctorAnalisisMedio)
    End Sub

    Private Sub BtnReceta_Click(sender As Object, e As EventArgs) Handles BtnReceta.Click
        openchildform(New DoctorRecetasMedio)
    End Sub

    Private Sub BtnOrden_Click(sender As Object, e As EventArgs) Handles BtnOrden.Click
        openchildform(New DoctorOrdenMedio)
    End Sub

    Private Sub BtnBuscar_Click(sender As Object, e As EventArgs) Handles BtnBuscar.Click
        Label1.Text = "Buscar por"
        TxtCi.Visible = False
        CbxBuscar1.Visible = True
        CbxBuscar2.Visible = True
        TxtBuscar1.Visible = True
        TxtBuscar2.Visible = True
        BtnBuscar2.Visible = True
    End Sub
End Class