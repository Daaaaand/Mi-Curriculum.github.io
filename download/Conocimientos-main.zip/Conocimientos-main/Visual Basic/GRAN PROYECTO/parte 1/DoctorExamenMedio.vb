﻿Public Class DoctorExamenMedio
    Private Sub LbxInspeccion_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LbxInspeccion.SelectedIndexChanged

    End Sub

    Private Sub LbxInspeccion_KeyPress(sender As Object, e As KeyPressEventArgs) Handles LbxInspeccion.KeyPress

    End Sub
End Class