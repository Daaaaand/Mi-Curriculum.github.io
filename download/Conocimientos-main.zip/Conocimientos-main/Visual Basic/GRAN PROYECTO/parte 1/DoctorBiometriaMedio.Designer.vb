﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorBiometriaMedio
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PBHuellas = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PBPatrones = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PBRetina = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PBIris = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PBVenas = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.PBMano = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnEliminar = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BtnImprimir = New System.Windows.Forms.Button()
        CType(Me.PBHuellas, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PBPatrones, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PBRetina, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PBIris, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PBVenas, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PBMano, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PBHuellas
        '
        Me.PBHuellas.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.PBHuellas.Location = New System.Drawing.Point(152, 106)
        Me.PBHuellas.Name = "PBHuellas"
        Me.PBHuellas.Size = New System.Drawing.Size(222, 109)
        Me.PBHuellas.TabIndex = 0
        Me.PBHuellas.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(32, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Huellas dactilares"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label2.Location = New System.Drawing.Point(32, 252)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Patrones faciales"
        '
        'PBPatrones
        '
        Me.PBPatrones.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.PBPatrones.Location = New System.Drawing.Point(152, 252)
        Me.PBPatrones.Name = "PBPatrones"
        Me.PBPatrones.Size = New System.Drawing.Size(222, 109)
        Me.PBPatrones.TabIndex = 2
        Me.PBPatrones.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label3.Location = New System.Drawing.Point(400, 106)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Retina"
        '
        'PBRetina
        '
        Me.PBRetina.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.PBRetina.Location = New System.Drawing.Point(469, 106)
        Me.PBRetina.Name = "PBRetina"
        Me.PBRetina.Size = New System.Drawing.Size(222, 109)
        Me.PBRetina.TabIndex = 4
        Me.PBRetina.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label4.Location = New System.Drawing.Point(400, 252)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(20, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Iris"
        '
        'PBIris
        '
        Me.PBIris.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.PBIris.Location = New System.Drawing.Point(469, 252)
        Me.PBIris.Name = "PBIris"
        Me.PBIris.Size = New System.Drawing.Size(222, 109)
        Me.PBIris.TabIndex = 6
        Me.PBIris.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label5.Location = New System.Drawing.Point(32, 402)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Venas"
        '
        'PBVenas
        '
        Me.PBVenas.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.PBVenas.Location = New System.Drawing.Point(152, 402)
        Me.PBVenas.Name = "PBVenas"
        Me.PBVenas.Size = New System.Drawing.Size(222, 109)
        Me.PBVenas.TabIndex = 8
        Me.PBVenas.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label6.Location = New System.Drawing.Point(400, 402)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Mano"
        '
        'PBMano
        '
        Me.PBMano.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.PBMano.Location = New System.Drawing.Point(469, 402)
        Me.PBMano.Name = "PBMano"
        Me.PBMano.Size = New System.Drawing.Size(222, 109)
        Me.PBMano.TabIndex = 10
        Me.PBMano.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnCancelar)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.BtnEliminar)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.BtnImprimir)
        Me.Panel1.Location = New System.Drawing.Point(36, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(732, 63)
        Me.Panel1.TabIndex = 90
        '
        'BtnCancelar
        '
        Me.BtnCancelar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnCancelar.Location = New System.Drawing.Point(431, 19)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelar.TabIndex = 67
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(24, 19)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 66
        Me.Button2.Text = "Guardar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'BtnEliminar
        '
        Me.BtnEliminar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnEliminar.Location = New System.Drawing.Point(304, 19)
        Me.BtnEliminar.Name = "BtnEliminar"
        Me.BtnEliminar.Size = New System.Drawing.Size(75, 23)
        Me.BtnEliminar.TabIndex = 65
        Me.BtnEliminar.Text = "Eliminar"
        Me.BtnEliminar.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(207, 19)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 64
        Me.Button1.Text = "Modificar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BtnImprimir
        '
        Me.BtnImprimir.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnImprimir.Location = New System.Drawing.Point(116, 19)
        Me.BtnImprimir.Name = "BtnImprimir"
        Me.BtnImprimir.Size = New System.Drawing.Size(75, 23)
        Me.BtnImprimir.TabIndex = 63
        Me.BtnImprimir.Text = "Imprimir"
        Me.BtnImprimir.UseVisualStyleBackColor = True
        '
        'DoctorBiometriaMedio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(827, 541)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.PBMano)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PBVenas)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PBIris)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PBRetina)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PBPatrones)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PBHuellas)
        Me.Name = "DoctorBiometriaMedio"
        Me.Text = "DoctorBiometriaMedio"
        CType(Me.PBHuellas, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PBPatrones, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PBRetina, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PBIris, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PBVenas, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PBMano, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PBHuellas As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PBPatrones As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents PBRetina As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents PBIris As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PBVenas As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents PBMano As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnCancelar As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents BtnEliminar As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents BtnImprimir As Button
End Class
