﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorEvolucionMedio
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LbxProblema = New System.Windows.Forms.ListBox()
        Me.LbxSubjetivo = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LbxObjetivo = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LbxAnalisis = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ListBox5 = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnEliminar = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BtnImprimir = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(46, 118)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Problema"
        '
        'LbxProblema
        '
        Me.LbxProblema.FormattingEnabled = True
        Me.LbxProblema.Location = New System.Drawing.Point(130, 118)
        Me.LbxProblema.Name = "LbxProblema"
        Me.LbxProblema.Size = New System.Drawing.Size(210, 95)
        Me.LbxProblema.TabIndex = 1
        '
        'LbxSubjetivo
        '
        Me.LbxSubjetivo.FormattingEnabled = True
        Me.LbxSubjetivo.Location = New System.Drawing.Point(444, 118)
        Me.LbxSubjetivo.Name = "LbxSubjetivo"
        Me.LbxSubjetivo.Size = New System.Drawing.Size(210, 95)
        Me.LbxSubjetivo.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label2.Location = New System.Drawing.Point(360, 118)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Subjetivo"
        '
        'LbxObjetivo
        '
        Me.LbxObjetivo.FormattingEnabled = True
        Me.LbxObjetivo.Location = New System.Drawing.Point(130, 261)
        Me.LbxObjetivo.Name = "LbxObjetivo"
        Me.LbxObjetivo.Size = New System.Drawing.Size(210, 95)
        Me.LbxObjetivo.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label3.Location = New System.Drawing.Point(46, 261)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Objetivo"
        '
        'LbxAnalisis
        '
        Me.LbxAnalisis.FormattingEnabled = True
        Me.LbxAnalisis.Location = New System.Drawing.Point(444, 261)
        Me.LbxAnalisis.Name = "LbxAnalisis"
        Me.LbxAnalisis.Size = New System.Drawing.Size(210, 95)
        Me.LbxAnalisis.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label4.Location = New System.Drawing.Point(360, 261)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Análisis"
        '
        'ListBox5
        '
        Me.ListBox5.FormattingEnabled = True
        Me.ListBox5.Location = New System.Drawing.Point(130, 400)
        Me.ListBox5.Name = "ListBox5"
        Me.ListBox5.Size = New System.Drawing.Size(210, 95)
        Me.ListBox5.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label5.Location = New System.Drawing.Point(46, 400)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Plan"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnCancelar)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.BtnEliminar)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.BtnImprimir)
        Me.Panel1.Location = New System.Drawing.Point(34, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(732, 63)
        Me.Panel1.TabIndex = 92
        '
        'BtnCancelar
        '
        Me.BtnCancelar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnCancelar.Location = New System.Drawing.Point(431, 19)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelar.TabIndex = 67
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(24, 19)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 66
        Me.Button2.Text = "Guardar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'BtnEliminar
        '
        Me.BtnEliminar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnEliminar.Location = New System.Drawing.Point(304, 19)
        Me.BtnEliminar.Name = "BtnEliminar"
        Me.BtnEliminar.Size = New System.Drawing.Size(75, 23)
        Me.BtnEliminar.TabIndex = 65
        Me.BtnEliminar.Text = "Eliminar"
        Me.BtnEliminar.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(207, 19)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 64
        Me.Button1.Text = "Modificar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BtnImprimir
        '
        Me.BtnImprimir.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnImprimir.Location = New System.Drawing.Point(116, 19)
        Me.BtnImprimir.Name = "BtnImprimir"
        Me.BtnImprimir.Size = New System.Drawing.Size(75, 23)
        Me.BtnImprimir.TabIndex = 63
        Me.BtnImprimir.Text = "Imprimir"
        Me.BtnImprimir.UseVisualStyleBackColor = True
        '
        'DoctorEvolucionMedio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(827, 541)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.ListBox5)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.LbxAnalisis)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LbxObjetivo)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.LbxSubjetivo)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LbxProblema)
        Me.Controls.Add(Me.Label1)
        Me.Name = "DoctorEvolucionMedio"
        Me.Text = "DoctorEvolucionMedio"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents LbxProblema As ListBox
    Friend WithEvents LbxSubjetivo As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents LbxObjetivo As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents LbxAnalisis As ListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents ListBox5 As ListBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnCancelar As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents BtnEliminar As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents BtnImprimir As Button
End Class
