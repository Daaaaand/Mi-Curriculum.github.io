﻿Public Class AdministradorSalaLateral
    Public Sub openchildform(childform As Object)
        If (PanelMedio.Controls.Count > 0) Then
            PanelMedio.Controls.RemoveAt(0)
        End If
        Dim frm As Form
        frm = childform
        frm.TopLevel = False
        frm.Dock = DockStyle.Fill
        frm.FormBorderStyle = FormBorderStyle.None
        PanelMedio.Controls.Add(frm)
        PanelMedio.Tag = frm
        frm.Show()

    End Sub
    Private Sub BtnIngresar_Click(sender As Object, e As EventArgs) Handles BtnIngresar.Click
        openchildform(New Sala)
    End Sub



    Private Sub BtnBuscar_Click(sender As Object, e As EventArgs) Handles BtnBuscar.Click
        openchildform(New BuscarSala)
    End Sub
End Class