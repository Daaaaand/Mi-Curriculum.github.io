﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BuscarSala
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtBuscar1 = New System.Windows.Forms.TextBox()
        Me.CbxBuscar1 = New System.Windows.Forms.ComboBox()
        Me.CbxBuscar2 = New System.Windows.Forms.ComboBox()
        Me.TxtBuscar2 = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.BtnBuscar = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(122, 89)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Buscar por "
        '
        'TxtBuscar1
        '
        Me.TxtBuscar1.Location = New System.Drawing.Point(197, 135)
        Me.TxtBuscar1.Name = "TxtBuscar1"
        Me.TxtBuscar1.Size = New System.Drawing.Size(121, 20)
        Me.TxtBuscar1.TabIndex = 1
        '
        'CbxBuscar1
        '
        Me.CbxBuscar1.FormattingEnabled = True
        Me.CbxBuscar1.Location = New System.Drawing.Point(197, 86)
        Me.CbxBuscar1.Name = "CbxBuscar1"
        Me.CbxBuscar1.Size = New System.Drawing.Size(121, 21)
        Me.CbxBuscar1.TabIndex = 2
        '
        'CbxBuscar2
        '
        Me.CbxBuscar2.FormattingEnabled = True
        Me.CbxBuscar2.Location = New System.Drawing.Point(339, 86)
        Me.CbxBuscar2.Name = "CbxBuscar2"
        Me.CbxBuscar2.Size = New System.Drawing.Size(121, 21)
        Me.CbxBuscar2.TabIndex = 4
        '
        'TxtBuscar2
        '
        Me.TxtBuscar2.Location = New System.Drawing.Point(339, 135)
        Me.TxtBuscar2.Name = "TxtBuscar2"
        Me.TxtBuscar2.Size = New System.Drawing.Size(121, 20)
        Me.TxtBuscar2.TabIndex = 3
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(125, 235)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(480, 263)
        Me.DataGridView1.TabIndex = 5
        '
        'BtnBuscar
        '
        Me.BtnBuscar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnBuscar.Location = New System.Drawing.Point(125, 189)
        Me.BtnBuscar.Name = "BtnBuscar"
        Me.BtnBuscar.Size = New System.Drawing.Size(75, 23)
        Me.BtnBuscar.TabIndex = 6
        Me.BtnBuscar.Text = "Buscar"
        Me.BtnBuscar.UseVisualStyleBackColor = True
        '
        'BuscarSala
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(976, 613)
        Me.Controls.Add(Me.BtnBuscar)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.CbxBuscar2)
        Me.Controls.Add(Me.TxtBuscar2)
        Me.Controls.Add(Me.CbxBuscar1)
        Me.Controls.Add(Me.TxtBuscar1)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Name = "BuscarSala"
        Me.Text = "BuscarSala"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents TxtBuscar1 As TextBox
    Friend WithEvents CbxBuscar1 As ComboBox
    Friend WithEvents CbxBuscar2 As ComboBox
    Friend WithEvents TxtBuscar2 As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents BtnBuscar As Button
End Class
