﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorMisLateral
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BtnTratamientos = New System.Windows.Forms.Button()
        Me.BtnPoliclinicas = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnBuscar = New System.Windows.Forms.Button()
        Me.CbxBuscar2 = New System.Windows.Forms.ComboBox()
        Me.TxtBuscar2 = New System.Windows.Forms.TextBox()
        Me.CbxBuscar1 = New System.Windows.Forms.ComboBox()
        Me.TxtBuscar1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelMedio = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnTratamientos
        '
        Me.BtnTratamientos.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnTratamientos.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnTratamientos.FlatAppearance.BorderSize = 0
        Me.BtnTratamientos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnTratamientos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTratamientos.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnTratamientos.Location = New System.Drawing.Point(2, 0)
        Me.BtnTratamientos.Name = "BtnTratamientos"
        Me.BtnTratamientos.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnTratamientos.Size = New System.Drawing.Size(291, 67)
        Me.BtnTratamientos.TabIndex = 11
        Me.BtnTratamientos.Text = "Tratamientos"
        Me.BtnTratamientos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnTratamientos.UseVisualStyleBackColor = False
        '
        'BtnPoliclinicas
        '
        Me.BtnPoliclinicas.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnPoliclinicas.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnPoliclinicas.FlatAppearance.BorderSize = 0
        Me.BtnPoliclinicas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnPoliclinicas.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPoliclinicas.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnPoliclinicas.Location = New System.Drawing.Point(2, 63)
        Me.BtnPoliclinicas.Name = "BtnPoliclinicas"
        Me.BtnPoliclinicas.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnPoliclinicas.Size = New System.Drawing.Size(291, 67)
        Me.BtnPoliclinicas.TabIndex = 13
        Me.BtnPoliclinicas.Text = "Policlínicas"
        Me.BtnPoliclinicas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnPoliclinicas.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnBuscar)
        Me.Panel1.Controls.Add(Me.CbxBuscar2)
        Me.Panel1.Controls.Add(Me.TxtBuscar2)
        Me.Panel1.Controls.Add(Me.CbxBuscar1)
        Me.Panel1.Controls.Add(Me.TxtBuscar1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(307, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(920, 67)
        Me.Panel1.TabIndex = 24
        '
        'BtnBuscar
        '
        Me.BtnBuscar.Location = New System.Drawing.Point(444, 21)
        Me.BtnBuscar.Name = "BtnBuscar"
        Me.BtnBuscar.Size = New System.Drawing.Size(87, 24)
        Me.BtnBuscar.TabIndex = 5
        Me.BtnBuscar.Text = "Buscar"
        Me.BtnBuscar.UseVisualStyleBackColor = True
        '
        'CbxBuscar2
        '
        Me.CbxBuscar2.FormattingEnabled = True
        Me.CbxBuscar2.Location = New System.Drawing.Point(285, 5)
        Me.CbxBuscar2.Name = "CbxBuscar2"
        Me.CbxBuscar2.Size = New System.Drawing.Size(138, 21)
        Me.CbxBuscar2.TabIndex = 4
        '
        'TxtBuscar2
        '
        Me.TxtBuscar2.Location = New System.Drawing.Point(285, 37)
        Me.TxtBuscar2.Name = "TxtBuscar2"
        Me.TxtBuscar2.Size = New System.Drawing.Size(138, 20)
        Me.TxtBuscar2.TabIndex = 3
        '
        'CbxBuscar1
        '
        Me.CbxBuscar1.FormattingEnabled = True
        Me.CbxBuscar1.Location = New System.Drawing.Point(119, 5)
        Me.CbxBuscar1.Name = "CbxBuscar1"
        Me.CbxBuscar1.Size = New System.Drawing.Size(138, 21)
        Me.CbxBuscar1.TabIndex = 2
        '
        'TxtBuscar1
        '
        Me.TxtBuscar1.Location = New System.Drawing.Point(119, 37)
        Me.TxtBuscar1.Name = "TxtBuscar1"
        Me.TxtBuscar1.Size = New System.Drawing.Size(138, 20)
        Me.TxtBuscar1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(55, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Buscar por"
        '
        'PanelMedio
        '
        Me.PanelMedio.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelMedio.Location = New System.Drawing.Point(307, 63)
        Me.PanelMedio.Name = "PanelMedio"
        Me.PanelMedio.Size = New System.Drawing.Size(843, 580)
        Me.PanelMedio.TabIndex = 23
        '
        'DoctorMisLateral
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1239, 653)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelMedio)
        Me.Controls.Add(Me.BtnPoliclinicas)
        Me.Controls.Add(Me.BtnTratamientos)
        Me.Name = "DoctorMisLateral"
        Me.Text = "DoctorMisLateral"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnTratamientos As Button
    Friend WithEvents BtnPoliclinicas As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnBuscar As Button
    Friend WithEvents CbxBuscar2 As ComboBox
    Friend WithEvents TxtBuscar2 As TextBox
    Friend WithEvents CbxBuscar1 As ComboBox
    Friend WithEvents TxtBuscar1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PanelMedio As Panel
End Class
