﻿Imports MySql.Data.MySqlClient
Public Class BD
    Dim conexion As New MySqlConnection
    Dim comando As New MySqlCommand
    Dim adaptador As New MySqlDataAdapter
    Dim datos As New DataSet
    Public Function Abrir() As Boolean
        Try
            conexion.ConnectionString = "server=192.168.2.195;database=agenda;user=prueba;password=prueba"
            conexion.Open()
            Return True
        Catch ex As Exception
            MsgBox("error al abrir la conexión")
            Return False
        End Try
    End Function
    Public Function SQL(ByVal sentencia As String) As DataTable
        If Abrir() Then
            comando.Connection = conexion
            comando.CommandText = sentencia
            comando.ExecuteNonQuery()
            adaptador.SelectCommand = comando
            adaptador.Fill(datos, "resultado")
            Return datos.Tables("resultado")
        Else
            Return Nothing
        End If
    End Function
    Public Function DML(ByVal sentencia As String) As Long
        If Abrir() Then
            comando.Connection = conexion
            comando.CommandText = sentencia
            comando.ExecuteNonQuery()
            Return comando.LastInsertedId
        Else
            Return 0
        End If
    End Function
    Public Sub CargarCombo(ByVal sentencia As String, ByRef combo As ComboBox)
        Dim lector As MySqlDataReader
        If Abrir() Then
            comando.Connection = conexion
            comando.CommandText = sentencia
            lector = comando.ExecuteReader
            combo.Items.Clear()
            combo.Items.Add("(todos)")
            While lector.Read
                combo.Items.Add(lector.GetString(0))
            End While
            combo.SelectedIndex = 0
        End If
    End Sub
End Class
