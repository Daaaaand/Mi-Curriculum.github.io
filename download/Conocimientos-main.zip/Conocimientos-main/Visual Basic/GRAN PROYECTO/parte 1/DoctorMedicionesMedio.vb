﻿Public Class DoctorMedicionesMedio

End Class