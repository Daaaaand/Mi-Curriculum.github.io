﻿
Public Class AdministradorIngresarLateral

    Private Sub openchildform(childform As Object)
        If (PanelMedio.Controls.Count > 0) Then
            PanelMedio.Controls.RemoveAt(0)
        End If
        Dim frm As Form
        frm = childform
        frm.TopLevel = False
        frm.Dock = DockStyle.Fill
        frm.FormBorderStyle = FormBorderStyle.None
        PanelMedio.Controls.Add(frm)
        PanelMedio.Tag = frm
        frm.Show()

    End Sub
    Public Function EstaAbierto(ByVal Myform As Form)
        Dim objForm As Form
        Dim blnAbierto As Boolean = False
        blnAbierto = False
        For Each objForm In My.Application.OpenForms
            If (Trim(objForm.Name) = Trim(Myform.Name)) Then
                blnAbierto = True
            End If
        Next
        Return blnAbierto
    End Function
    Private Sub BtnPaciente_Click(sender As Object, e As EventArgs) Handles BtnPaciente.Click
        openchildform(New Fichadelpaciente)

    End Sub

    Private Sub AdministradorIngresarLateral_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

    End Sub

    Private Sub BtnMedico_Click(sender As Object, e As EventArgs) Handles BtnMedico.Click
        openchildform(New FichaMédica)
    End Sub

    Private Sub BtnAuxiliar_Click(sender As Object, e As EventArgs) Handles BtnAuxiliar.Click
        openchildform(New FichaAuxiliar)
    End Sub

    Private Sub BtnPersonal_Click(sender As Object, e As EventArgs) Handles BtnPersonal.Click
        openchildform(New FichaPersonal)
    End Sub

    Private Sub BtnAdministrador_Click(sender As Object, e As EventArgs) Handles BtnAdministrador.Click
        openchildform(New FichaAdministrador)
    End Sub

    Private Sub BtnBuscar_Click(sender As Object, e As EventArgs)


    End Sub
End Class