﻿Public Class DoctorBiometriaMedio

End Class