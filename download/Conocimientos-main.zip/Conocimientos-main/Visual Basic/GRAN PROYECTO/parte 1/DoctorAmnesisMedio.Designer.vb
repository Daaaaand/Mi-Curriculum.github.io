﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorAmnesisMedio
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LbxSintomas = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LbxSignos = New System.Windows.Forms.ListBox()
        Me.LbxAntecedentesPersonales = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LbxAntecedentesFamiliares = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnEliminar = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BtnImprimir = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtPulso = New System.Windows.Forms.TextBox()
        Me.TxtPeso = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtAltura = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtPresión = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 101)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Síntomas"
        '
        'LbxSintomas
        '
        Me.LbxSintomas.FormattingEnabled = True
        Me.LbxSintomas.Location = New System.Drawing.Point(70, 101)
        Me.LbxSintomas.Name = "LbxSintomas"
        Me.LbxSintomas.Size = New System.Drawing.Size(281, 82)
        Me.LbxSintomas.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(390, 101)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Signos"
        '
        'LbxSignos
        '
        Me.LbxSignos.FormattingEnabled = True
        Me.LbxSignos.Location = New System.Drawing.Point(476, 101)
        Me.LbxSignos.Name = "LbxSignos"
        Me.LbxSignos.Size = New System.Drawing.Size(325, 82)
        Me.LbxSignos.TabIndex = 3
        '
        'LbxAntecedentesPersonales
        '
        Me.LbxAntecedentesPersonales.FormattingEnabled = True
        Me.LbxAntecedentesPersonales.Location = New System.Drawing.Point(140, 246)
        Me.LbxAntecedentesPersonales.Name = "LbxAntecedentesPersonales"
        Me.LbxAntecedentesPersonales.Size = New System.Drawing.Size(325, 82)
        Me.LbxAntecedentesPersonales.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 246)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Antecedentes Personales"
        '
        'LbxAntecedentesFamiliares
        '
        Me.LbxAntecedentesFamiliares.FormattingEnabled = True
        Me.LbxAntecedentesFamiliares.Location = New System.Drawing.Point(140, 389)
        Me.LbxAntecedentesFamiliares.Name = "LbxAntecedentesFamiliares"
        Me.LbxAntecedentesFamiliares.Size = New System.Drawing.Size(325, 82)
        Me.LbxAntecedentesFamiliares.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(9, 389)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(122, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Antecedentes Familiares"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnCancelar)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.BtnEliminar)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.BtnImprimir)
        Me.Panel1.Location = New System.Drawing.Point(15, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(732, 63)
        Me.Panel1.TabIndex = 8
        '
        'BtnCancelar
        '
        Me.BtnCancelar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnCancelar.Location = New System.Drawing.Point(437, 19)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BtnCancelar.TabIndex = 67
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(24, 19)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 66
        Me.Button2.Text = "Guardar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'BtnEliminar
        '
        Me.BtnEliminar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnEliminar.Location = New System.Drawing.Point(304, 19)
        Me.BtnEliminar.Name = "BtnEliminar"
        Me.BtnEliminar.Size = New System.Drawing.Size(75, 23)
        Me.BtnEliminar.TabIndex = 65
        Me.BtnEliminar.Text = "Eliminar"
        Me.BtnEliminar.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(207, 19)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 64
        Me.Button1.Text = "Modificar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BtnImprimir
        '
        Me.BtnImprimir.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnImprimir.Location = New System.Drawing.Point(116, 19)
        Me.BtnImprimir.Name = "BtnImprimir"
        Me.BtnImprimir.Size = New System.Drawing.Size(75, 23)
        Me.BtnImprimir.TabIndex = 63
        Me.BtnImprimir.Text = "Imprimir"
        Me.BtnImprimir.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(496, 246)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(33, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Pulso"
        '
        'TxtPulso
        '
        Me.TxtPulso.Location = New System.Drawing.Point(545, 243)
        Me.TxtPulso.Name = "TxtPulso"
        Me.TxtPulso.Size = New System.Drawing.Size(100, 20)
        Me.TxtPulso.TabIndex = 10
        '
        'TxtPeso
        '
        Me.TxtPeso.Location = New System.Drawing.Point(712, 243)
        Me.TxtPeso.Name = "TxtPeso"
        Me.TxtPeso.Size = New System.Drawing.Size(100, 20)
        Me.TxtPeso.TabIndex = 12
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(663, 246)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Peso"
        '
        'TxtAltura
        '
        Me.TxtAltura.Location = New System.Drawing.Point(545, 301)
        Me.TxtAltura.Name = "TxtAltura"
        Me.TxtAltura.Size = New System.Drawing.Size(100, 20)
        Me.TxtAltura.TabIndex = 14
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(496, 304)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Altura"
        '
        'TxtPresión
        '
        Me.TxtPresión.Location = New System.Drawing.Point(542, 386)
        Me.TxtPresión.Name = "TxtPresión"
        Me.TxtPresión.Size = New System.Drawing.Size(100, 20)
        Me.TxtPresión.TabIndex = 16
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(493, 389)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 13)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Presión"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'DoctorAmnesisMedio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(827, 541)
        Me.Controls.Add(Me.TxtPresión)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TxtAltura)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TxtPeso)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.TxtPulso)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.LbxAntecedentesFamiliares)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LbxAntecedentesPersonales)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.LbxSignos)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LbxSintomas)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Name = "DoctorAmnesisMedio"
        Me.Text = "DoctorAmnesisMedio"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents LbxSintomas As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents LbxSignos As ListBox
    Friend WithEvents LbxAntecedentesPersonales As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents LbxAntecedentesFamiliares As ListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnCancelar As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents BtnEliminar As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents BtnImprimir As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents TxtPulso As TextBox
    Friend WithEvents TxtPeso As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtAltura As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TxtPresión As TextBox
    Friend WithEvents Label8 As Label
End Class
