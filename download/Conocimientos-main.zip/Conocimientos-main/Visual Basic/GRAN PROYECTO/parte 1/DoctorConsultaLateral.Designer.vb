﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DoctorConsultaLateral
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.BtnAnalisis = New System.Windows.Forms.Button()
        Me.BtnReceta = New System.Windows.Forms.Button()
        Me.BtnOrden = New System.Windows.Forms.Button()
        Me.BtnTest = New System.Windows.Forms.Button()
        Me.PanelMedio = New System.Windows.Forms.Panel()
        Me.BtnAnamnesis = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BtnBuscar2 = New System.Windows.Forms.Button()
        Me.TxtCi = New System.Windows.Forms.TextBox()
        Me.CbxBuscar2 = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtBuscar2 = New System.Windows.Forms.TextBox()
        Me.CbxBuscar1 = New System.Windows.Forms.ComboBox()
        Me.TxtBuscar1 = New System.Windows.Forms.TextBox()
        Me.BtnBuscar = New System.Windows.Forms.Button()
        Me.BtnGuardar = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnAnalisis
        '
        Me.BtnAnalisis.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnAnalisis.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnAnalisis.FlatAppearance.BorderSize = 0
        Me.BtnAnalisis.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnAnalisis.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAnalisis.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnAnalisis.Location = New System.Drawing.Point(1, 65)
        Me.BtnAnalisis.Name = "BtnAnalisis"
        Me.BtnAnalisis.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnAnalisis.Size = New System.Drawing.Size(291, 67)
        Me.BtnAnalisis.TabIndex = 10
        Me.BtnAnalisis.Text = "Análisis"
        Me.BtnAnalisis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnAnalisis.UseVisualStyleBackColor = False
        '
        'BtnReceta
        '
        Me.BtnReceta.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnReceta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnReceta.FlatAppearance.BorderSize = 0
        Me.BtnReceta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnReceta.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnReceta.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnReceta.Location = New System.Drawing.Point(1, 128)
        Me.BtnReceta.Name = "BtnReceta"
        Me.BtnReceta.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnReceta.Size = New System.Drawing.Size(291, 67)
        Me.BtnReceta.TabIndex = 11
        Me.BtnReceta.Text = "Receta"
        Me.BtnReceta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnReceta.UseVisualStyleBackColor = False
        '
        'BtnOrden
        '
        Me.BtnOrden.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnOrden.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnOrden.FlatAppearance.BorderSize = 0
        Me.BtnOrden.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnOrden.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnOrden.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnOrden.Location = New System.Drawing.Point(1, 192)
        Me.BtnOrden.Name = "BtnOrden"
        Me.BtnOrden.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnOrden.Size = New System.Drawing.Size(291, 67)
        Me.BtnOrden.TabIndex = 12
        Me.BtnOrden.Text = "Orden"
        Me.BtnOrden.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnOrden.UseVisualStyleBackColor = False
        '
        'BtnTest
        '
        Me.BtnTest.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnTest.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnTest.FlatAppearance.BorderSize = 0
        Me.BtnTest.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnTest.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTest.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnTest.Location = New System.Drawing.Point(1, 254)
        Me.BtnTest.Name = "BtnTest"
        Me.BtnTest.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnTest.Size = New System.Drawing.Size(291, 67)
        Me.BtnTest.TabIndex = 13
        Me.BtnTest.Text = "Test"
        Me.BtnTest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnTest.UseVisualStyleBackColor = False
        '
        'PanelMedio
        '
        Me.PanelMedio.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(66, Byte), Integer))
        Me.PanelMedio.Location = New System.Drawing.Point(318, 65)
        Me.PanelMedio.Name = "PanelMedio"
        Me.PanelMedio.Size = New System.Drawing.Size(920, 580)
        Me.PanelMedio.TabIndex = 15
        '
        'BtnAnamnesis
        '
        Me.BtnAnamnesis.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnAnamnesis.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnAnamnesis.FlatAppearance.BorderSize = 0
        Me.BtnAnamnesis.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnAnamnesis.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAnamnesis.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnAnamnesis.Location = New System.Drawing.Point(1, 1)
        Me.BtnAnamnesis.Name = "BtnAnamnesis"
        Me.BtnAnamnesis.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnAnamnesis.Size = New System.Drawing.Size(291, 67)
        Me.BtnAnamnesis.TabIndex = 16
        Me.BtnAnamnesis.Text = "Anamnesis"
        Me.BtnAnamnesis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnAnamnesis.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnBuscar2)
        Me.Panel1.Controls.Add(Me.TxtCi)
        Me.Panel1.Controls.Add(Me.CbxBuscar2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.TxtBuscar2)
        Me.Panel1.Controls.Add(Me.CbxBuscar1)
        Me.Panel1.Controls.Add(Me.TxtBuscar1)
        Me.Panel1.Location = New System.Drawing.Point(318, 1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(920, 67)
        Me.Panel1.TabIndex = 17
        '
        'BtnBuscar2
        '
        Me.BtnBuscar2.Location = New System.Drawing.Point(450, 26)
        Me.BtnBuscar2.Name = "BtnBuscar2"
        Me.BtnBuscar2.Size = New System.Drawing.Size(87, 24)
        Me.BtnBuscar2.TabIndex = 32
        Me.BtnBuscar2.Text = "Buscar"
        Me.BtnBuscar2.UseVisualStyleBackColor = True
        Me.BtnBuscar2.Visible = False
        '
        'TxtCi
        '
        Me.TxtCi.Location = New System.Drawing.Point(125, 24)
        Me.TxtCi.Name = "TxtCi"
        Me.TxtCi.Size = New System.Drawing.Size(138, 20)
        Me.TxtCi.TabIndex = 27
        '
        'CbxBuscar2
        '
        Me.CbxBuscar2.FormattingEnabled = True
        Me.CbxBuscar2.Location = New System.Drawing.Point(291, 10)
        Me.CbxBuscar2.Name = "CbxBuscar2"
        Me.CbxBuscar2.Size = New System.Drawing.Size(138, 21)
        Me.CbxBuscar2.TabIndex = 31
        Me.CbxBuscar2.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label1.Location = New System.Drawing.Point(55, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 13)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "CI paciente:"
        '
        'TxtBuscar2
        '
        Me.TxtBuscar2.Location = New System.Drawing.Point(291, 42)
        Me.TxtBuscar2.Name = "TxtBuscar2"
        Me.TxtBuscar2.Size = New System.Drawing.Size(138, 20)
        Me.TxtBuscar2.TabIndex = 30
        Me.TxtBuscar2.Visible = False
        '
        'CbxBuscar1
        '
        Me.CbxBuscar1.FormattingEnabled = True
        Me.CbxBuscar1.Location = New System.Drawing.Point(125, 10)
        Me.CbxBuscar1.Name = "CbxBuscar1"
        Me.CbxBuscar1.Size = New System.Drawing.Size(138, 21)
        Me.CbxBuscar1.TabIndex = 29
        Me.CbxBuscar1.Visible = False
        '
        'TxtBuscar1
        '
        Me.TxtBuscar1.Location = New System.Drawing.Point(125, 42)
        Me.TxtBuscar1.Name = "TxtBuscar1"
        Me.TxtBuscar1.Size = New System.Drawing.Size(138, 20)
        Me.TxtBuscar1.TabIndex = 28
        Me.TxtBuscar1.Visible = False
        '
        'BtnBuscar
        '
        Me.BtnBuscar.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnBuscar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnBuscar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnBuscar.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnBuscar.Location = New System.Drawing.Point(1, 427)
        Me.BtnBuscar.Name = "BtnBuscar"
        Me.BtnBuscar.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnBuscar.Size = New System.Drawing.Size(310, 67)
        Me.BtnBuscar.TabIndex = 22
        Me.BtnBuscar.Text = "Buscar"
        Me.BtnBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnBuscar.UseVisualStyleBackColor = False
        '
        'BtnGuardar
        '
        Me.BtnGuardar.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnGuardar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnGuardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.BtnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnGuardar.ForeColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BtnGuardar.Location = New System.Drawing.Point(1, 364)
        Me.BtnGuardar.Name = "BtnGuardar"
        Me.BtnGuardar.Padding = New System.Windows.Forms.Padding(10, 0, 0, 0)
        Me.BtnGuardar.Size = New System.Drawing.Size(310, 67)
        Me.BtnGuardar.TabIndex = 21
        Me.BtnGuardar.Text = "Guardar"
        Me.BtnGuardar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnGuardar.UseVisualStyleBackColor = False
        '
        'DoctorConsultaLateral
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(49, Byte), Integer), CType(CType(61, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1239, 653)
        Me.Controls.Add(Me.BtnBuscar)
        Me.Controls.Add(Me.BtnGuardar)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.BtnAnamnesis)
        Me.Controls.Add(Me.PanelMedio)
        Me.Controls.Add(Me.BtnTest)
        Me.Controls.Add(Me.BtnOrden)
        Me.Controls.Add(Me.BtnReceta)
        Me.Controls.Add(Me.BtnAnalisis)
        Me.Name = "DoctorConsultaLateral"
        Me.Text = "DoctorConsultaLateral"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnAnalisis As Button
    Friend WithEvents BtnReceta As Button
    Friend WithEvents BtnOrden As Button
    Friend WithEvents BtnTest As Button
    Friend WithEvents PanelMedio As Panel
    Friend WithEvents BtnAnamnesis As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BtnBuscar2 As Button
    Friend WithEvents TxtCi As TextBox
    Friend WithEvents CbxBuscar2 As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtBuscar2 As TextBox
    Friend WithEvents CbxBuscar1 As ComboBox
    Friend WithEvents TxtBuscar1 As TextBox
    Friend WithEvents BtnBuscar As Button
    Friend WithEvents BtnGuardar As Button
End Class
