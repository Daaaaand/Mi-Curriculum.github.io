﻿Public Class DoctorMisLateral
    Private Sub openchildform(childform As Object)
        If (PanelMedio.Controls.Count > 0) Then
            PanelMedio.Controls.RemoveAt(0)
        End If
        Dim frm As Form
        frm = childform
        frm.TopLevel = False
        frm.Dock = DockStyle.Fill
        frm.FormBorderStyle = FormBorderStyle.None
        PanelMedio.Controls.Add(frm)
        PanelMedio.Tag = frm
        frm.Show()

    End Sub
    Private Sub DoctorMisLateral_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BtnTratamientos_Click(sender As Object, e As EventArgs) Handles BtnTratamientos.Click
        openchildform(New DoctorMisTratamientos)
    End Sub

    Private Sub BtnPoliclinicas_Click(sender As Object, e As EventArgs) Handles BtnPoliclinicas.Click
        openchildform(New DoctorMisPoliclinicas)
    End Sub
End Class