﻿Public Class DoctorHistorialLateral

End Class