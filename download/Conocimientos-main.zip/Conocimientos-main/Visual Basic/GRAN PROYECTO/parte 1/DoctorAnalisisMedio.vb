﻿Public Class DoctorAnalisisMedio

End Class