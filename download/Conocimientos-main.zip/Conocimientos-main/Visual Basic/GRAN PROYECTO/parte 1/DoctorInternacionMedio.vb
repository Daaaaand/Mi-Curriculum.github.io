﻿Public Class DoctorInternacionMedio

End Class