﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ConsultaP_M
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtConsultorio = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtCi = New System.Windows.Forms.TextBox()
        Me.BtnFicha = New System.Windows.Forms.Button()
        Me.BtnAmnesishistorial = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LbxSíntomas = New System.Windows.Forms.ListBox()
        Me.Pastillas = New System.Windows.Forms.Label()
        Me.RbnRemediosSi = New System.Windows.Forms.RadioButton()
        Me.RbnRemediosNo = New System.Windows.Forms.RadioButton()
        Me.TxtRemedios = New System.Windows.Forms.TextBox()
        Me.RbnCronicasNo = New System.Windows.Forms.RadioButton()
        Me.RbnCronicasSi = New System.Windows.Forms.RadioButton()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtCronicas = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.RbnOperacionesNo = New System.Windows.Forms.RadioButton()
        Me.RbnOperacionesSi = New System.Windows.Forms.RadioButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TxtOperaciones = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.RbnAlérgiaSi = New System.Windows.Forms.RadioButton()
        Me.RbnAlérgiaNo = New System.Windows.Forms.RadioButton()
        Me.TxtAlérgia = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.LbxIndícaciones = New System.Windows.Forms.ListBox()
        Me.Remedios = New System.Windows.Forms.Label()
        Me.TxtRemediosN = New System.Windows.Forms.TextBox()
        Me.BtnImprimir = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CbxServicio = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.LbxEnfermedad = New System.Windows.Forms.ListBox()
        Me.BtnGuardar = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.CbxServicioN = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TxtFecha = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TxtHora = New System.Windows.Forms.TextBox()
        Me.CbxTiposangre = New System.Windows.Forms.ComboBox()
        Me.BtnHistoriaclínica = New System.Windows.Forms.Button()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.BtnCancelar = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(208, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fecha "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Consultorio"
        '
        'TxtConsultorio
        '
        Me.TxtConsultorio.Location = New System.Drawing.Point(79, 13)
        Me.TxtConsultorio.Name = "TxtConsultorio"
        Me.TxtConsultorio.Size = New System.Drawing.Size(100, 20)
        Me.TxtConsultorio.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 47)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "CI paciente"
        '
        'TxtCi
        '
        Me.TxtCi.Location = New System.Drawing.Point(79, 44)
        Me.TxtCi.Name = "TxtCi"
        Me.TxtCi.Size = New System.Drawing.Size(100, 20)
        Me.TxtCi.TabIndex = 5
        '
        'BtnFicha
        '
        Me.BtnFicha.Location = New System.Drawing.Point(12, 98)
        Me.BtnFicha.Name = "BtnFicha"
        Me.BtnFicha.Size = New System.Drawing.Size(59, 23)
        Me.BtnFicha.TabIndex = 6
        Me.BtnFicha.Text = "Ficha "
        Me.BtnFicha.UseVisualStyleBackColor = True
        '
        'BtnAmnesishistorial
        '
        Me.BtnAmnesishistorial.Location = New System.Drawing.Point(78, 98)
        Me.BtnAmnesishistorial.Name = "BtnAmnesishistorial"
        Me.BtnAmnesishistorial.Size = New System.Drawing.Size(99, 23)
        Me.BtnAmnesishistorial.TabIndex = 7
        Me.BtnAmnesishistorial.Text = "Amnesis Historial"
        Me.BtnAmnesishistorial.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 139)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Síntomas"
        '
        'LbxSíntomas
        '
        Me.LbxSíntomas.FormattingEnabled = True
        Me.LbxSíntomas.Location = New System.Drawing.Point(70, 139)
        Me.LbxSíntomas.Name = "LbxSíntomas"
        Me.LbxSíntomas.Size = New System.Drawing.Size(412, 56)
        Me.LbxSíntomas.TabIndex = 9
        '
        'Pastillas
        '
        Me.Pastillas.AutoSize = True
        Me.Pastillas.Location = New System.Drawing.Point(11, 251)
        Me.Pastillas.Name = "Pastillas"
        Me.Pastillas.Size = New System.Drawing.Size(60, 13)
        Me.Pastillas.TabIndex = 10
        Me.Pastillas.Text = "Remedios?"
        '
        'RbnRemediosSi
        '
        Me.RbnRemediosSi.AutoSize = True
        Me.RbnRemediosSi.Location = New System.Drawing.Point(78, 249)
        Me.RbnRemediosSi.Name = "RbnRemediosSi"
        Me.RbnRemediosSi.Size = New System.Drawing.Size(34, 17)
        Me.RbnRemediosSi.TabIndex = 11
        Me.RbnRemediosSi.TabStop = True
        Me.RbnRemediosSi.Text = "Si"
        Me.RbnRemediosSi.UseVisualStyleBackColor = True
        '
        'RbnRemediosNo
        '
        Me.RbnRemediosNo.AutoSize = True
        Me.RbnRemediosNo.Location = New System.Drawing.Point(118, 249)
        Me.RbnRemediosNo.Name = "RbnRemediosNo"
        Me.RbnRemediosNo.Size = New System.Drawing.Size(39, 17)
        Me.RbnRemediosNo.TabIndex = 12
        Me.RbnRemediosNo.TabStop = True
        Me.RbnRemediosNo.Text = "No"
        Me.RbnRemediosNo.UseVisualStyleBackColor = True
        '
        'TxtRemedios
        '
        Me.TxtRemedios.Location = New System.Drawing.Point(161, 249)
        Me.TxtRemedios.Name = "TxtRemedios"
        Me.TxtRemedios.Size = New System.Drawing.Size(321, 20)
        Me.TxtRemedios.TabIndex = 13
        '
        'RbnCronicasNo
        '
        Me.RbnCronicasNo.AutoSize = True
        Me.RbnCronicasNo.Location = New System.Drawing.Point(183, 213)
        Me.RbnCronicasNo.Name = "RbnCronicasNo"
        Me.RbnCronicasNo.Size = New System.Drawing.Size(39, 17)
        Me.RbnCronicasNo.TabIndex = 16
        Me.RbnCronicasNo.TabStop = True
        Me.RbnCronicasNo.Text = "No"
        Me.RbnCronicasNo.UseVisualStyleBackColor = True
        '
        'RbnCronicasSi
        '
        Me.RbnCronicasSi.AutoSize = True
        Me.RbnCronicasSi.Location = New System.Drawing.Point(143, 213)
        Me.RbnCronicasSi.Name = "RbnCronicasSi"
        Me.RbnCronicasSi.Size = New System.Drawing.Size(34, 17)
        Me.RbnCronicasSi.TabIndex = 15
        Me.RbnCronicasSi.TabStop = True
        Me.RbnCronicasSi.Text = "Si"
        Me.RbnCronicasSi.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 215)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(124, 13)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Enfremedades crónicas?"
        '
        'TxtCronicas
        '
        Me.TxtCronicas.Location = New System.Drawing.Point(228, 212)
        Me.TxtCronicas.Name = "TxtCronicas"
        Me.TxtCronicas.Size = New System.Drawing.Size(257, 20)
        Me.TxtCronicas.TabIndex = 17
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(392, 47)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(78, 13)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Tipo de sangre"
        '
        'RbnOperacionesNo
        '
        Me.RbnOperacionesNo.AutoSize = True
        Me.RbnOperacionesNo.Location = New System.Drawing.Point(137, 282)
        Me.RbnOperacionesNo.Name = "RbnOperacionesNo"
        Me.RbnOperacionesNo.Size = New System.Drawing.Size(39, 17)
        Me.RbnOperacionesNo.TabIndex = 22
        Me.RbnOperacionesNo.TabStop = True
        Me.RbnOperacionesNo.Text = "No"
        Me.RbnOperacionesNo.UseVisualStyleBackColor = True
        '
        'RbnOperacionesSi
        '
        Me.RbnOperacionesSi.AutoSize = True
        Me.RbnOperacionesSi.Location = New System.Drawing.Point(91, 282)
        Me.RbnOperacionesSi.Name = "RbnOperacionesSi"
        Me.RbnOperacionesSi.Size = New System.Drawing.Size(34, 17)
        Me.RbnOperacionesSi.TabIndex = 21
        Me.RbnOperacionesSi.TabStop = True
        Me.RbnOperacionesSi.Text = "Si"
        Me.RbnOperacionesSi.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 284)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 13)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Operaciones?"
        '
        'TxtOperaciones
        '
        Me.TxtOperaciones.Location = New System.Drawing.Point(183, 281)
        Me.TxtOperaciones.Name = "TxtOperaciones"
        Me.TxtOperaciones.Size = New System.Drawing.Size(299, 20)
        Me.TxtOperaciones.TabIndex = 23
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 318)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Alergia?"
        '
        'RbnAlérgiaSi
        '
        Me.RbnAlérgiaSi.AutoSize = True
        Me.RbnAlérgiaSi.Location = New System.Drawing.Point(70, 318)
        Me.RbnAlérgiaSi.Name = "RbnAlérgiaSi"
        Me.RbnAlérgiaSi.Size = New System.Drawing.Size(34, 17)
        Me.RbnAlérgiaSi.TabIndex = 25
        Me.RbnAlérgiaSi.TabStop = True
        Me.RbnAlérgiaSi.Text = "Si"
        Me.RbnAlérgiaSi.UseVisualStyleBackColor = True
        '
        'RbnAlérgiaNo
        '
        Me.RbnAlérgiaNo.AutoSize = True
        Me.RbnAlérgiaNo.Location = New System.Drawing.Point(110, 318)
        Me.RbnAlérgiaNo.Name = "RbnAlérgiaNo"
        Me.RbnAlérgiaNo.Size = New System.Drawing.Size(39, 17)
        Me.RbnAlérgiaNo.TabIndex = 26
        Me.RbnAlérgiaNo.TabStop = True
        Me.RbnAlérgiaNo.Text = "No"
        Me.RbnAlérgiaNo.UseVisualStyleBackColor = True
        '
        'TxtAlérgia
        '
        Me.TxtAlérgia.Location = New System.Drawing.Point(161, 315)
        Me.TxtAlérgia.Name = "TxtAlérgia"
        Me.TxtAlérgia.Size = New System.Drawing.Size(321, 20)
        Me.TxtAlérgia.TabIndex = 27
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(502, 139)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(70, 13)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "Indicaciones "
        '
        'LbxIndícaciones
        '
        Me.LbxIndícaciones.FormattingEnabled = True
        Me.LbxIndícaciones.Location = New System.Drawing.Point(604, 139)
        Me.LbxIndícaciones.Name = "LbxIndícaciones"
        Me.LbxIndícaciones.Size = New System.Drawing.Size(285, 108)
        Me.LbxIndícaciones.TabIndex = 29
        '
        'Remedios
        '
        Me.Remedios.AutoSize = True
        Me.Remedios.Location = New System.Drawing.Point(10, 385)
        Me.Remedios.Name = "Remedios"
        Me.Remedios.Size = New System.Drawing.Size(54, 13)
        Me.Remedios.TabIndex = 30
        Me.Remedios.Text = "Remedios"
        '
        'TxtRemediosN
        '
        Me.TxtRemediosN.Location = New System.Drawing.Point(78, 382)
        Me.TxtRemediosN.Name = "TxtRemediosN"
        Me.TxtRemediosN.Size = New System.Drawing.Size(327, 20)
        Me.TxtRemediosN.TabIndex = 31
        '
        'BtnImprimir
        '
        Me.BtnImprimir.Location = New System.Drawing.Point(411, 377)
        Me.BtnImprimir.Name = "BtnImprimir"
        Me.BtnImprimir.Size = New System.Drawing.Size(85, 29)
        Me.BtnImprimir.TabIndex = 32
        Me.BtnImprimir.Text = "Imprimir orden"
        Me.BtnImprimir.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(208, 47)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(45, 13)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Servicio"
        '
        'CbxServicio
        '
        Me.CbxServicio.FormattingEnabled = True
        Me.CbxServicio.Location = New System.Drawing.Point(259, 44)
        Me.CbxServicio.Name = "CbxServicio"
        Me.CbxServicio.Size = New System.Drawing.Size(121, 21)
        Me.CbxServicio.TabIndex = 34
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(502, 266)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(96, 13)
        Me.Label11.TabIndex = 35
        Me.Label11.Text = "Enfermedad actual"
        '
        'LbxEnfermedad
        '
        Me.LbxEnfermedad.FormattingEnabled = True
        Me.LbxEnfermedad.Location = New System.Drawing.Point(604, 266)
        Me.LbxEnfermedad.Name = "LbxEnfermedad"
        Me.LbxEnfermedad.Size = New System.Drawing.Size(285, 95)
        Me.LbxEnfermedad.TabIndex = 36
        '
        'BtnGuardar
        '
        Me.BtnGuardar.Location = New System.Drawing.Point(818, 412)
        Me.BtnGuardar.Name = "BtnGuardar"
        Me.BtnGuardar.Size = New System.Drawing.Size(71, 29)
        Me.BtnGuardar.TabIndex = 37
        Me.BtnGuardar.Text = "Guardar"
        Me.BtnGuardar.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(537, 384)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(60, 13)
        Me.Label12.TabIndex = 38
        Me.Label12.Text = "Orden para"
        '
        'CbxServicioN
        '
        Me.CbxServicioN.FormattingEnabled = True
        Me.CbxServicioN.Location = New System.Drawing.Point(604, 381)
        Me.CbxServicioN.Name = "CbxServicioN"
        Me.CbxServicioN.Size = New System.Drawing.Size(121, 21)
        Me.CbxServicioN.TabIndex = 39
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TxtFecha)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.TxtHora)
        Me.GroupBox1.Controls.Add(Me.CbxTiposangre)
        Me.GroupBox1.Controls.Add(Me.TxtCi)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TxtConsultorio)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.CbxServicio)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 10)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(586, 82)
        Me.GroupBox1.TabIndex = 40
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Consulta"
        '
        'TxtFecha
        '
        Me.TxtFecha.Location = New System.Drawing.Point(259, 13)
        Me.TxtFecha.Name = "TxtFecha"
        Me.TxtFecha.Size = New System.Drawing.Size(121, 20)
        Me.TxtFecha.TabIndex = 38
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(392, 17)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(30, 13)
        Me.Label13.TabIndex = 36
        Me.Label13.Text = "Hora"
        '
        'TxtHora
        '
        Me.TxtHora.Location = New System.Drawing.Point(476, 14)
        Me.TxtHora.Name = "TxtHora"
        Me.TxtHora.Size = New System.Drawing.Size(100, 20)
        Me.TxtHora.TabIndex = 37
        '
        'CbxTiposangre
        '
        Me.CbxTiposangre.FormattingEnabled = True
        Me.CbxTiposangre.Location = New System.Drawing.Point(476, 44)
        Me.CbxTiposangre.Name = "CbxTiposangre"
        Me.CbxTiposangre.Size = New System.Drawing.Size(84, 21)
        Me.CbxTiposangre.TabIndex = 35
        '
        'BtnHistoriaclínica
        '
        Me.BtnHistoriaclínica.Location = New System.Drawing.Point(183, 98)
        Me.BtnHistoriaclínica.Name = "BtnHistoriaclínica"
        Me.BtnHistoriaclínica.Size = New System.Drawing.Size(87, 23)
        Me.BtnHistoriaclínica.TabIndex = 41
        Me.BtnHistoriaclínica.Text = "Historia clínica"
        Me.BtnHistoriaclínica.UseVisualStyleBackColor = True
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'BtnCancelar
        '
        Me.BtnCancelar.Location = New System.Drawing.Point(724, 412)
        Me.BtnCancelar.Name = "BtnCancelar"
        Me.BtnCancelar.Size = New System.Drawing.Size(71, 29)
        Me.BtnCancelar.TabIndex = 42
        Me.BtnCancelar.Text = "Cancelar"
        Me.BtnCancelar.UseVisualStyleBackColor = True
        '
        'ConsultaP_M
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(908, 504)
        Me.Controls.Add(Me.BtnCancelar)
        Me.Controls.Add(Me.BtnHistoriaclínica)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CbxServicioN)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.BtnGuardar)
        Me.Controls.Add(Me.LbxEnfermedad)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.BtnImprimir)
        Me.Controls.Add(Me.TxtRemediosN)
        Me.Controls.Add(Me.Remedios)
        Me.Controls.Add(Me.LbxIndícaciones)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TxtAlérgia)
        Me.Controls.Add(Me.RbnAlérgiaNo)
        Me.Controls.Add(Me.RbnAlérgiaSi)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TxtOperaciones)
        Me.Controls.Add(Me.RbnOperacionesNo)
        Me.Controls.Add(Me.RbnOperacionesSi)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TxtCronicas)
        Me.Controls.Add(Me.RbnCronicasNo)
        Me.Controls.Add(Me.RbnCronicasSi)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TxtRemedios)
        Me.Controls.Add(Me.RbnRemediosNo)
        Me.Controls.Add(Me.RbnRemediosSi)
        Me.Controls.Add(Me.Pastillas)
        Me.Controls.Add(Me.LbxSíntomas)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.BtnAmnesishistorial)
        Me.Controls.Add(Me.BtnFicha)
        Me.Name = "ConsultaP_M"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtConsultorio As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TxtCi As System.Windows.Forms.TextBox
    Friend WithEvents BtnFicha As System.Windows.Forms.Button
    Friend WithEvents BtnAmnesishistorial As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LbxSíntomas As System.Windows.Forms.ListBox
    Friend WithEvents Pastillas As System.Windows.Forms.Label
    Friend WithEvents RbnRemediosSi As System.Windows.Forms.RadioButton
    Friend WithEvents RbnRemediosNo As System.Windows.Forms.RadioButton
    Friend WithEvents TxtRemedios As System.Windows.Forms.TextBox
    Friend WithEvents RbnCronicasNo As System.Windows.Forms.RadioButton
    Friend WithEvents RbnCronicasSi As System.Windows.Forms.RadioButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TxtCronicas As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents RbnOperacionesNo As System.Windows.Forms.RadioButton
    Friend WithEvents RbnOperacionesSi As System.Windows.Forms.RadioButton
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TxtOperaciones As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents RbnAlérgiaSi As System.Windows.Forms.RadioButton
    Friend WithEvents RbnAlérgiaNo As System.Windows.Forms.RadioButton
    Friend WithEvents TxtAlérgia As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents LbxIndícaciones As System.Windows.Forms.ListBox
    Friend WithEvents Remedios As System.Windows.Forms.Label
    Friend WithEvents TxtRemediosN As System.Windows.Forms.TextBox
    Friend WithEvents BtnImprimir As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents CbxServicio As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents LbxEnfermedad As System.Windows.Forms.ListBox
    Friend WithEvents BtnGuardar As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents CbxServicioN As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents BtnHistoriaclínica As System.Windows.Forms.Button
    Friend WithEvents CbxTiposangre As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TxtHora As System.Windows.Forms.TextBox
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents TxtFecha As System.Windows.Forms.TextBox
    Friend WithEvents BtnCancelar As System.Windows.Forms.Button
End Class
