﻿Public Class AuxiliarInternacion
    Private Sub BtnEliminar_Click(sender As Object, e As EventArgs)

    End Sub
End Class