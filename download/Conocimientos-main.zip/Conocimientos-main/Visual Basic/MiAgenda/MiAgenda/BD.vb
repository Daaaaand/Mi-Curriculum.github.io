﻿Imports MySql.Data.MySqlClient
Public Class BD
    Dim conexion As New MySqlConnection
    Dim comando As New MySqlCommand
    Dim adaptador As New MySqlDataAdapter
    Dim datos As New DataSet
    Public Function Abrir() As Boolean
        Try conexion.ConnectionString = "server=192.168.2.195;database=agenda;user=prueba;password=prueba"
            conexion.Open()
            Return True
        Catch ex As Exception
            MsgBox("Error al abrir la conexion")
            Return False
        End Try
    End Function

    Public Function Sql(ByVal Sentencia As String) As DataTable
        If Abrir() Then
            comando.Connection = conexion
            comando.CommandText = Sentencia
            comando.ExecuteNonQuery()
            adaptador.SelectCommand = comando
            adaptador.Fill(datos, "resultado")
            Return datos.Tables(
        Else
            Return Nothing
        End If
    End Function

    Public Function DML(ByVal Sentencia As String) As Long

        If Abrir() Then
            comando.Connection = conexion
            comando.CommandText = Sentencia
            comando.ExecuteNonQuery()

            Return comando.LastInsertedId
        Else
            Return 0
        End If
    End Function

    Public Sub CargarCombo(ByVal Sentencia As String.ByRef Combo As ComboBox)
        Dim lector As MySqlDataReader
        If Abrir() Then
            comando.Connection = conexion
            comando.CommandText = Sentencia
            lector = comando.ExecuteReader
            combo.Items.clear()
            combo.Items.add("(Todos)")
            While lector.Read
                ComboBox.itemsadd(lector.GetString(0))
            End While
            combo.selectedindex = 0
        End If

End Class
