﻿
Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim miBD As New BD
        Dim miBD2 As New BD
        Try
            DgvDatos.DataSource = miBD.Sql("Select * From datos")
            miBD2.CargarCombo("Select Distinct tipo From usuario", ComboBox1)
        Catch ex As Exception
            MsgBox("Error!" + ex.Message)
        End Try
    End Sub

    Private Sub BtnAgregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAgregar.Click
        Form2.accion = "agregar"
        Form2.Show()
        Me.Close()
    End Sub

    Private Sub BtnEliminar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnEliminar.Click
        With DgvDatos.SelectedRows(0)
            Form2.TxtCI.Text = .Cells(0).Value
            Form2.TxtNombre.Text = .Cells(1).Value
            Form2.DtpFNac.Value = .Cells(2).Value
            If .Cells(3).Value = "femenino" Then
                Form2.RbnFemenino.Checked = True
            Else
                Form2.RbnMasculino.Checked = True
            End If
        End With
        Form2.accion = "eliminar"
        Form2.Show()
        Me.Close()
    End Sub

    Private Sub BtnModificar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnModificar.Click
        With DgvDatos.SelectedRows(0)
            Form2.TxtCI.Text = .Cells(0).Value
            Form2.TxtNombre.Text = .Cells(1).Value
            Form2.DtpFNac.Value = .Cells(2).Value
            If .Cells(3).Value = "femenino" Then
                Form2.RbnFemenino.Checked = True
            Else
                Form2.RbnMasculino.Checked = True
            End If
        End With
        With Form2
            .accion = "modificar"
            .Show()
        End With
        Me.Close()
    End Sub

    Private Sub BtnSalir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSalir.Click
        Application.Exit()
    End Sub
End Class
