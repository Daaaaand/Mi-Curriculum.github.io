﻿Imports MySql.Data.MySqlClient
Public Class Form2
    Public accion As String
    Dim ciAnterior As String '***********************

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Select Case accion
            Case "agregar"
                Me.Text = "Agregar un nuevo Contacto"
                BtnAceptar.Text = "Agregar"
            Case "modificar"
                Me.Text = "Modificar un Contacto"
                BtnAceptar.Text = "Modificar"
                ciAnterior = TxtCI.Text '******************
            Case "eliminar"
                Me.Text = "Eliminar un Contacto"
                BtnAceptar.Text = "Eliminar"
                TxtCI.Enabled = False '******************
                TxtNombre.Enabled = False '******************
                DtpFNac.Enabled = False '******************
                GroupBox1.Enabled = False '******************
        End Select
    End Sub

    Private Sub BtnAceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAceptar.Click
        Dim conexion As New MySqlConnection
        Dim comando As New MySqlCommand
        Dim sentencia As String = ""
        Select Case accion
            Case "agregar"
                sentencia = "INSERT INTO datos values("
                sentencia += TxtCI.Text + ","
                sentencia += "'" + TxtNombre.Text + "',"
                sentencia += "'" + Format(DtpFNac.Value, "yyyy-MM-dd") + "',"
                If RbnFemenino.Checked Then
                    sentencia += "'femenino');"
                Else
                    sentencia += "'masculino');"
                End If
            Case "modificar"
                sentencia = "UPDATE datos SET ci =" + TxtCI.Text + ", "
                sentencia += "nombre = '" + TxtNombre.Text + "', "
                sentencia += "fnac = '" + Format(DtpFNac.Value, "yyyy-MM-dd") + "', "
                If RbnFemenino.Checked Then
                    sentencia += "sexo = 'femenino'     "
                Else
                    sentencia += "sexo = 'masculino'    "
                End If
                sentencia += "WHERE ci = " + ciAnterior
            Case "eliminar"
                sentencia += "DELETE FROM datos WHERE ci = " + TxtCI.Text
        End Select
        conexion.ConnectionString = "server=192.168.2.195;database=agenda;user=prueba;password=prueba"
        conexion.Open()
        comando.Connection = conexion
        comando.CommandText = sentencia
        comando.ExecuteNonQuery()
        Form1.Show()
        Me.Close()
    End Sub

    Private Sub BtnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCancelar.Click
        Form1.Show()
        Me.Close()
    End Sub
End Class