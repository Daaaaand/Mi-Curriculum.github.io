﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAhorcado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Lbl_1 = New System.Windows.Forms.Label()
        Me.Lbl_3 = New System.Windows.Forms.Label()
        Me.Lbl_4 = New System.Windows.Forms.Label()
        Me.Lbl_2 = New System.Windows.Forms.Label()
        Me.Lbl_5 = New System.Windows.Forms.Label()
        Me.Lbl_6 = New System.Windows.Forms.Label()
        Me.LblPalabra = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.LblUsadas = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Lbl_1
        '
        Me.Lbl_1.AutoSize = True
        Me.Lbl_1.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_1.Location = New System.Drawing.Point(104, 55)
        Me.Lbl_1.Name = "Lbl_1"
        Me.Lbl_1.Size = New System.Drawing.Size(69, 73)
        Me.Lbl_1.TabIndex = 0
        Me.Lbl_1.Text = "0"
        Me.Lbl_1.Visible = False
        '
        'Lbl_3
        '
        Me.Lbl_3.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_3.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_3.Location = New System.Drawing.Point(91, 116)
        Me.Lbl_3.Name = "Lbl_3"
        Me.Lbl_3.Size = New System.Drawing.Size(39, 62)
        Me.Lbl_3.TabIndex = 1
        Me.Lbl_3.Text = "/"
        Me.Lbl_3.Visible = False
        '
        'Lbl_4
        '
        Me.Lbl_4.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_4.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_4.Location = New System.Drawing.Point(145, 116)
        Me.Lbl_4.Name = "Lbl_4"
        Me.Lbl_4.Size = New System.Drawing.Size(35, 61)
        Me.Lbl_4.TabIndex = 2
        Me.Lbl_4.Text = "\"
        Me.Lbl_4.Visible = False
        '
        'Lbl_2
        '
        Me.Lbl_2.AutoSize = True
        Me.Lbl_2.BackColor = System.Drawing.SystemColors.Control
        Me.Lbl_2.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_2.Location = New System.Drawing.Point(116, 117)
        Me.Lbl_2.Name = "Lbl_2"
        Me.Lbl_2.Size = New System.Drawing.Size(50, 73)
        Me.Lbl_2.TabIndex = 3
        Me.Lbl_2.Text = "|"
        Me.Lbl_2.Visible = False
        '
        'Lbl_5
        '
        Me.Lbl_5.AutoSize = True
        Me.Lbl_5.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_5.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_5.Location = New System.Drawing.Point(94, 190)
        Me.Lbl_5.Name = "Lbl_5"
        Me.Lbl_5.Size = New System.Drawing.Size(51, 73)
        Me.Lbl_5.TabIndex = 4
        Me.Lbl_5.Text = "/"
        Me.Lbl_5.Visible = False
        '
        'Lbl_6
        '
        Me.Lbl_6.AutoSize = True
        Me.Lbl_6.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_6.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_6.Location = New System.Drawing.Point(137, 190)
        Me.Lbl_6.Name = "Lbl_6"
        Me.Lbl_6.Size = New System.Drawing.Size(51, 73)
        Me.Lbl_6.TabIndex = 5
        Me.Lbl_6.Text = "\"
        Me.Lbl_6.Visible = False
        '
        'LblPalabra
        '
        Me.LblPalabra.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPalabra.Location = New System.Drawing.Point(12, 303)
        Me.LblPalabra.Name = "LblPalabra"
        Me.LblPalabra.Size = New System.Drawing.Size(507, 39)
        Me.LblPalabra.TabIndex = 6
        Me.LblPalabra.Text = "Aca abajo"
        Me.LblPalabra.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(32, 55)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 10)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Label7"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(32, 65)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(10, 210)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Label8"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(0, 275)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(189, 10)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Label9"
        '
        'LblUsadas
        '
        Me.LblUsadas.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblUsadas.Location = New System.Drawing.Point(12, 4)
        Me.LblUsadas.Name = "LblUsadas"
        Me.LblUsadas.Size = New System.Drawing.Size(507, 39)
        Me.LblUsadas.TabIndex = 10
        Me.LblUsadas.Text = "Aca arriba"
        Me.LblUsadas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FrmAhorcado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(531, 351)
        Me.Controls.Add(Me.LblUsadas)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.LblPalabra)
        Me.Controls.Add(Me.Lbl_3)
        Me.Controls.Add(Me.Lbl_4)
        Me.Controls.Add(Me.Lbl_6)
        Me.Controls.Add(Me.Lbl_5)
        Me.Controls.Add(Me.Lbl_2)
        Me.Controls.Add(Me.Lbl_1)
        Me.Name = "FrmAhorcado"
        Me.Text = "nnnn"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Lbl_1 As System.Windows.Forms.Label
    Friend WithEvents Lbl_3 As System.Windows.Forms.Label
    Friend WithEvents Lbl_4 As System.Windows.Forms.Label
    Friend WithEvents Lbl_2 As System.Windows.Forms.Label
    Friend WithEvents Lbl_5 As System.Windows.Forms.Label
    Friend WithEvents Lbl_6 As System.Windows.Forms.Label
    Friend WithEvents LblPalabra As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents LblUsadas As System.Windows.Forms.Label
End Class
