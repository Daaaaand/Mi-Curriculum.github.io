﻿Public Class Form1
    Private Sub BtnAceptar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnAceptar.Click
        If TxtPalabra.TextLength = 0 Then

            MsgBox("Ingrese la palabra secreta!", vbCritical)
            TxtPalabra.Focus()
        Else
            FrmAhorcado.laPalabra = TxtPalabra.Text

            FrmAhorcado.Show()

            Me.Hide()

        End If
    End Sub

End Class
