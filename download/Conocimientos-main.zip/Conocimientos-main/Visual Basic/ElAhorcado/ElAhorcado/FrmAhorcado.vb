﻿Public Class FrmAhorcado
    Public laPalabra As String
    Dim errores As Integer = 0

    Private Sub FrmAhorcado_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If LblUsadas.Text.Contains(e.KeyChar.ToString.ToUpper) Then
            MsgBox("Letra Repetida!", vbCritical)

        Else
            LblUsadas.Text += e.KeyChar.ToString.ToUpper
            If laPalabra.Contains(e.KeyChar.ToString.ToUpper) Then
                'Esta la letra en la palabra
                Dim i As Integer
                Dim aux As String
                For i = 0 To laPalabra.Length - 1
                    If laPalabra(i) = e.KeyChar.ToString.ToUpper Then
                        aux += laPalabra(i)
                    Else
                        aux += LblPalabra.Text(i)
                    End If
                Next

                LblPalabra.Text = aux
                If aux = laPalabra.Replace(" ", "/") Then
                    If MsgBox("¡Ganaste! ¿Queres jugar de nuevo?", vbYesNo) = MsgBoxResult.Yes Then
                        Application.Restart()
                    Else
                        Application.Exit()
                    End If
                End If

            Else
                'No esta la letra en la palabra
                errores += 1
                If NoEsta() Then
                    If MsgBox("¡Perdiste! ¿Queres jugar de nuevo?", vbYesNo) Then
                        Application.Restart()
                    Else
                        Application.Exit()
                    End If

                End If

            End If
        End If

    End Sub

    Private Sub FrmAhorcado_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        LblUsadas.Text = ""
        LblPalabra.Text = ""
        laPalabra = laPalabra.ToUpper

        For i = 0 To laPalabra.Length - 1
            If laPalabra(i) = " " Then
                LblPalabra.Text += "/"
            Else
                LblPalabra.Text += "-"
            End If
        Next
    End Sub

    Private Function NoEsta() As Boolean

        Dim perdio As Boolean = False
        Select Case errores
            Case 1
                Lbl_1.Visible = True
            Case 2
                Lbl_2.Visible = True
            Case 3
                Lbl_3.Visible = True
            Case 4
                Lbl_4.Visible = True
            Case 5
                Lbl_5.Visible = True
            Case 6
                Lbl_6.Visible = True
                perdio = True
        End Select
        NoEsta = perdio
    End Function
End Class

