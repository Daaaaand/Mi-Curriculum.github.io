﻿Public Class Form1
    Dim hora, minuto, segundo, fraccion As Integer

    Private Sub btniniciar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btniniciar.Click
        If btniniciar.Text = "Iniciar" Then
            Timer1.Start()
            btniniciar.Text = "Detener"
            btnparcial.Visible = True
        ElseIf btniniciar.Text = "Detener" Then
            Timer1.Stop()
            btniniciar.Text = "Reanudar"
            btnparcial.Text = "Restablecer"
        Else
            Timer1.Start()
            btniniciar.Text = "Detener"
            btnparcial.Text = "parcial"
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        fraccion += 1
        If fraccion > 99 Then
            fraccion = 0
            segundo += 1
            If segundo > 59 Then
                segundo = 0
                minuto += 1
                If minuto > 59 Then
                    minuto = 0
                    hora += 1
                End If
            End If
        End If

        lblreloj.Text = hora.ToString + ":" + minuto.ToString + ":" + segundo.ToString + ":" + fraccion.ToString

    End Sub
End Class
