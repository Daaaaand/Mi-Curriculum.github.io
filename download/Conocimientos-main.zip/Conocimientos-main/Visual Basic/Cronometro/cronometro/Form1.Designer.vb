﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblreloj = New System.Windows.Forms.Label()
        Me.lbxvuelta = New System.Windows.Forms.ListBox()
        Me.btnparcial = New System.Windows.Forms.Button()
        Me.btniniciar = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'lblreloj
        '
        Me.lblreloj.Font = New System.Drawing.Font("Microsoft Sans Serif", 80.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblreloj.Location = New System.Drawing.Point(36, 9)
        Me.lblreloj.Name = "lblreloj"
        Me.lblreloj.Size = New System.Drawing.Size(616, 131)
        Me.lblreloj.TabIndex = 0
        Me.lblreloj.Text = "0:00:00:00"
        '
        'lbxvuelta
        '
        Me.lbxvuelta.FormattingEnabled = True
        Me.lbxvuelta.Location = New System.Drawing.Point(101, 120)
        Me.lbxvuelta.Name = "lbxvuelta"
        Me.lbxvuelta.Size = New System.Drawing.Size(408, 199)
        Me.lbxvuelta.TabIndex = 1
        '
        'btnparcial
        '
        Me.btnparcial.Location = New System.Drawing.Point(515, 358)
        Me.btnparcial.Name = "btnparcial"
        Me.btnparcial.Size = New System.Drawing.Size(113, 41)
        Me.btnparcial.TabIndex = 2
        Me.btnparcial.Text = "Parcial"
        Me.btnparcial.UseVisualStyleBackColor = True
        Me.btnparcial.Visible = False
        '
        'btniniciar
        '
        Me.btniniciar.Location = New System.Drawing.Point(12, 358)
        Me.btniniciar.Name = "btniniciar"
        Me.btniniciar.Size = New System.Drawing.Size(117, 41)
        Me.btniniciar.TabIndex = 3
        Me.btniniciar.Text = "Iniciar"
        Me.btniniciar.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(640, 411)
        Me.Controls.Add(Me.btniniciar)
        Me.Controls.Add(Me.btnparcial)
        Me.Controls.Add(Me.lbxvuelta)
        Me.Controls.Add(Me.lblreloj)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblreloj As System.Windows.Forms.Label
    Friend WithEvents lbxvuelta As System.Windows.Forms.ListBox
    Friend WithEvents btnparcial As System.Windows.Forms.Button
    Friend WithEvents btniniciar As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer

End Class
