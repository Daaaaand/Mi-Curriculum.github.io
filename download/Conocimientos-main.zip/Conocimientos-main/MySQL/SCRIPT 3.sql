
create table if not exists EntrevistaI (
ide int auto_increment primary key,
ci int (8) not null,
fecha date,
hora time,
foreign key (ci) references Paciente (ci)
);

create table if not exists Diagnostico (
idd int auto_increment primary key,
ci int (8) not null,
fecha date,
hora time,
foreign key (ci) references Paciente (ci)
);

create table if not exists Plan
(
idp int auto_increment primary key,
ci int (8) not null,
fecha date,
hora time,
foreign key (ci) references Paciente (ci)
);

CREATE TABLE `Urinalisis` (
   `id` int(11) NOT NULL,
   `Roja` varchar(50) DEFAULT NULL,
   `Plaqueta` varchar(50) DEFAULT NULL,
   `Nitritos` varchar(50) DEFAULT NULL,
   `Blanca` varchar(50) DEFAULT NULL,
   `Cristales` varchar(50) DEFAULT NULL,
   `Bacterias` varchar(50) DEFAULT NULL,
   PRIMARY KEY (`id`),
   CONSTRAINT `Urinalisis_ibfk_1` FOREIGN KEY (`id`) REFERENCES `Analisis` (`id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
 ;

CREATE TABLE `Tratamiento` (
   `ID` int auto_increment not null,
   idp int not null,
   `Pasos` varchar(50) NOT NULL,
   `Nombre` varchar(50) NOT NULL,
   `Observaciones` varchar(50) NOT NULL,
   `Descripcion` varchar(50) NOT NULL,
   PRIMARY KEY (`ID`),
   foreign key (idp) references Plan (idp)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Renal` (
   `id` int(11) NOT NULL,
   `BUN` varchar(50) DEFAULT NULL,
   `Creatina` varchar(50) DEFAULT NULL,
   `Acido` varchar(50) DEFAULT NULL,
   PRIMARY KEY (`id`),
   CONSTRAINT `Renal_ibfk_1` FOREIGN KEY (`id`) REFERENCES `Analisis` (`id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Receta` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `ci` int(8) DEFAULT NULL,
   `Fecha` date DEFAULT NULL,
   `Envases` int(5) DEFAULT NULL,
   `Duracion` varchar(50) DEFAULT NULL,
   `Posologia` varchar(50) DEFAULT NULL,
   `Via` varchar(50) DEFAULT NULL,
   `Informacion` varchar(200) DEFAULT NULL,
   `Instruccion` varchar(200) DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `ci` (`ci`),
   CONSTRAINT `Receta_ibfk_1` FOREIGN KEY (`ci`) REFERENCES `Paciente` (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Prueba2` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `Enfermedad` varchar(30) DEFAULT NULL,
   `Resultado` enum('Verdadero positivo','Falso positivo','Falso negativo','Verdadero negativo') DEFAULT NULL,
   PRIMARY KEY (`id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Prueba1` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `Enfermedad` varchar(30) DEFAULT NULL,
   `Resultado` enum('Positivo','Negativo') DEFAULT NULL,
   `idA` int(11) DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `idA` (`idA`),
   CONSTRAINT `Prueba1_ibfk_1` FOREIGN KEY (`idA`) REFERENCES `Analisis` (`id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `DiagnosticoCompleto` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `idd` int(11) DEFAULT NULL,
   `Nombre` varchar(50) DEFAULT NULL,
    Tipo varchar (50) not null,
    Diagnostico varchar (50) not null,
   `Observaciones` varchar(300) DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `idd` (`idd`),
   CONSTRAINT `PreDiagnostico_ibfk_1` FOREIGN KEY (`idd`) REFERENCES `Diagnostico` (`idd`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1
;
CREATE TABLE `Personal` (
   `ci` int(8) NOT NULL,
   `Nombre` varchar(50) DEFAULT NULL,
   `Apellido` varchar(50) DEFAULT NULL,
   `Genero` enum('masculino','femenino','otro') DEFAULT NULL,
   `Direccion` varchar(50) DEFAULT NULL,
   `Email` varchar(50) DEFAULT NULL,
   `Telefono1` int(9) unsigned zerofill DEFAULT NULL,
   `Telefono2` int(9) unsigned zerofill DEFAULT NULL,
   `Fnac` date DEFAULT NULL,
   `Puesto` varchar(20) DEFAULT NULL,
   PRIMARY KEY (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Paciente` (
   `ci` int (8) default null,
   `Nombre` varchar(50) DEFAULT NULL,
   `Apellido` varchar(50) DEFAULT NULL,
   `Genero` enum('masculino','femenino','otro') DEFAULT NULL,
   `Direccion` varchar(50) DEFAULT NULL,
   `Email` varchar(50) DEFAULT NULL,
   `Telefono` int(9) unsigned zerofill DEFAULT NULL,
   `Telefono2` int(9) unsigned zerofill DEFAULT NULL,
   `Fnac` date DEFAULT NULL,
   `Nacionalidad` varchar(30) DEFAULT NULL,
   `Ocupacion` varchar(30) DEFAULT NULL,
   `Estudios` varchar(30) DEFAULT NULL,
   `Tiposangre` char(5) DEFAULT NULL,
   `EC` varchar(15) DEFAULT NULL,
   PRIMARY KEY (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;



CREATE TABLE `ModeloFormulario` (
   `idM` int(11) NOT NULL AUTO_INCREMENT,
   `ciMedico` int(8) DEFAULT NULL,
   `Nombre` varchar(40) DEFAULT NULL,
   `Fecha` date DEFAULT NULL,
   `Pregunta1` varchar(100) DEFAULT NULL,
   `Pregunta2` varchar(100) DEFAULT NULL,
   `Pregunta3` varchar(100) DEFAULT NULL,
   `Pregunta4` varchar(100) DEFAULT NULL,
   `Pregunta5` varchar(100) DEFAULT NULL,
   `Pregunta6` varchar(100) DEFAULT NULL,
   `Pregunta7` varchar(100) DEFAULT NULL,
   `Pregunta8` varchar(100) DEFAULT NULL,
   `Pregunta9` varchar(100) DEFAULT NULL,
   `Pregunta10` varchar(100) DEFAULT NULL,
   `Pregunta11` varchar(100) DEFAULT NULL,
   `Pregunta12` varchar(100) DEFAULT NULL,
   PRIMARY KEY (`idM`),
   KEY `ciMedico` (`ciMedico`),
   CONSTRAINT `ModeloFormulario_ibfk_1` FOREIGN KEY (`ciMedico`) REFERENCES `Medico` (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `ModeloFormulario` (
   `idM` int(11) NOT NULL AUTO_INCREMENT,
   `ciMedico` int(8) DEFAULT NULL,
   `Nombre` varchar(40) DEFAULT NULL,
   `Fecha` date DEFAULT NULL,
   `Pregunta1` varchar(100) DEFAULT NULL,
   `Pregunta2` varchar(100) DEFAULT NULL,
   `Pregunta3` varchar(100) DEFAULT NULL,
   `Pregunta4` varchar(100) DEFAULT NULL,
   `Pregunta5` varchar(100) DEFAULT NULL,
   `Pregunta6` varchar(100) DEFAULT NULL,
   `Pregunta7` varchar(100) DEFAULT NULL,
   `Pregunta8` varchar(100) DEFAULT NULL,
   `Pregunta9` varchar(100) DEFAULT NULL,
   `Pregunta10` varchar(100) DEFAULT NULL,
   `Pregunta11` varchar(100) DEFAULT NULL,
   `Pregunta12` varchar(100) DEFAULT NULL,
   PRIMARY KEY (`idM`),
   KEY `ciMedico` (`ciMedico`),
   CONSTRAINT `ModeloFormulario_ibfk_1` FOREIGN KEY (`ciMedico`) REFERENCES `Medico` (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Medico` (
   `ci` int(8) NOT NULL,
   `Nombre` varchar(50) NOT NULL,
   `Apellido` varchar(50) NOT NULL,
   `Genero` enum('masculino','femenino','otro') DEFAULT NULL,
   `Direccion` varchar(50) NOT NULL,
   `Email` varchar(50) NOT NULL,
   `Telefono` int(9) unsigned zerofill DEFAULT NULL,
   `Telefono2` int(9) unsigned zerofill DEFAULT NULL,
   `Fnac` date DEFAULT NULL,
   `PresedenciaClinica` varchar(50) NOT NULL,
   `FormHoraria` varchar(50) NOT NULL,
   `Grado` varchar(50) NOT NULL,
   `Especializacion` varchar(50) NOT NULL,
   PRIMARY KEY (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Mediciones` (
   `ID` int auto_increment NOT NULL,
   `Tipo` varchar(50) NOT NULL,
   `Valor` varchar(50) NOT NULL,
   `CadaCuantasHoras` varchar(50) NOT NULL,
   PRIMARY KEY (`ID`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Lipidico` (
   `id` int(11) NOT NULL,
   `Colesterol` varchar(50) DEFAULT NULL,
   `LDL` varchar(50) DEFAULT NULL,
   `HDL` varchar(50) DEFAULT NULL,
   `Triglicerido` varchar(50) DEFAULT NULL,
   PRIMARY KEY (`id`),
   CONSTRAINT `Lipidico_ibfk_1` FOREIGN KEY (`id`) REFERENCES `Analisis` (`id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Internacion` (
   `observaciones` varchar(50) NOT NULL,
   `indicaciones` varchar(50) NOT NULL,
   `motivo` varchar(50) NOT NULL,
   `id` varchar(50) NOT NULL,
   PRIMARY KEY (`id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Hemograma` (
   `id` int(11) NOT NULL,
   `RContenido` varchar(50) DEFAULT NULL,
   `RDiametro` varchar(50) DEFAULT NULL,
   `Neutrofilos` varchar(50) DEFAULT NULL,
   `Linfocitos` varchar(50) DEFAULT NULL,
   `Monocitos` varchar(50) DEFAULT NULL,
   `Eosinofilos` varchar(50) DEFAULT NULL,
   `Basofilos` varchar(50) DEFAULT NULL,
   `Total` varchar(50) DEFAULT NULL,
   `PContenido` varchar(50) DEFAULT NULL,
   `PDiametro` varchar(50) DEFAULT NULL,
   PRIMARY KEY (`id`),
   CONSTRAINT `Hemograma_ibfk_1` FOREIGN KEY (`id`) REFERENCES `Analisis` (`id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE if not exists `Entrevista` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `ide` int(11) not NULL,
   `Estado` varchar(300) DEFAULT NULL,
   `Grado` varchar(300) DEFAULT NULL,
   `Movilidad` varchar(300) DEFAULT NULL,
   `Actitud` enum ('Apatia','Coma','Exitacion') DEFAULT NULL,
   `Peso` varchar(50) DEFAULT NULL,
   `Hidratacion` varchar(50) DEFAULT NULL,
   `Pulso` varchar(50) DEFAULT NULL,
   `Temperatura` int(2) DEFAULT NULL,
   `FrecuenciaC` int(4) DEFAULT NULL,
   `FrecuenciaR` int(3) DEFAULT NULL,
   `SintomasG` varchar(30) DEFAULT NULL,
   `Revision` varchar(300) DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `ide` (`ide`),
   CONSTRAINT `Entrevista_ibfk_1` FOREIGN KEY (`ide`) REFERENCES `EntrevistaI` (`ide`)
 ) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1
;
CREATE TABLE `Enfermedad` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `Nombrecientifico` varchar(50) DEFAULT NULL,
   `Nombre` varchar(50) DEFAULT NULL,
   `Descripcion` varchar(200) DEFAULT NULL,
   `Sintomas` varchar(100) DEFAULT NULL,
   `NivelG` enum('baja','media','alta') DEFAULT NULL,
   PRIMARY KEY (`id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Consulta` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `Fecha` date DEFAULT NULL,
   `Horario` time DEFAULT NULL,
   `Consultorio` int(3) DEFAULT NULL,
   `CiMedico` int (8) DEFAULT NULL,
   `NombreM` varchar(50) DEFAULT NULL,
   `ApellidoM` varchar(50) DEFAULT NULL,
   `CiPaciente` int(8) DEFAULT NULL,
   `NombreP` varchar(50) DEFAULT NULL,
   `ApellidoP` varchar(50) DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `CiMedico` (`CiMedico`),
   KEY `CiPaciente` (`CiPaciente`),
   CONSTRAINT `Consulta_ibfk_1` FOREIGN KEY (`CiMedico`) REFERENCES `Medico` (`ci`),
   CONSTRAINT `Consulta_ibfk_2` FOREIGN KEY (`CiPaciente`) REFERENCES `Paciente` (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Auxiliar` (
   `ci` int(8) NOT NULL,
   `Nombre` varchar(50) NOT NULL,
   `Apellido` varchar(50) NOT NULL,
   `Direccion` varchar(50) NOT NULL,
   `Email` varchar(50) NOT NULL,
   `Telefono1` int(9) unsigned zerofill DEFAULT NULL,
   `Telefono2` int(9) unsigned zerofill DEFAULT NULL,
   `Fnac` date DEFAULT NULL,
   `Especializacion` char(3) NOT NULL,
   `Genero` enum('masculino','femenino','otro') DEFAULT NULL,
   PRIMARY KEY (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Analisis` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `idd` int(11) DEFAULT NULL,
   `Genero` enum('masculino','femenino','otro') DEFAULT NULL,
   `ci` int (8) DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `idd` (`idd`),
   KEY `ci` (`ci`),
   CONSTRAINT `Analisis_ibfk_2` FOREIGN KEY (`ci`) REFERENCES `Paciente` (`ci`),
   CONSTRAINT `Analisis_ibfk_1` FOREIGN KEY (`idd`) REFERENCES `Diagnostico` (`idd`)
 ) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1
;
CREATE TABLE `Agenda` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `Dias` varchar(40) DEFAULT NULL,
   `Horai` time DEFAULT NULL,
   `Horaf` time DEFAULT NULL,
   `Nombresala` varchar(20) DEFAULT NULL,
   `Sala` int(3) DEFAULT NULL,
   `Cimedico` int(8) DEFAULT NULL,
   `Ciauxiliar` int(8) DEFAULT NULL,
   PRIMARY KEY (`id`),
   UNIQUE KEY `Dias` (`Dias`,`Horai`,`Horaf`,`Nombresala`,`Sala`),
   KEY `Cimedico` (`Cimedico`),
   KEY `Ciauxiliar` (`Ciauxiliar`),
   CONSTRAINT `Agenda_ibfk_1` FOREIGN KEY (`Cimedico`) REFERENCES `Medico` (`ci`),
   CONSTRAINT `Agenda_ibfk_2` FOREIGN KEY (`Ciauxiliar`) REFERENCES `Auxiliar` (`ci`)
 ) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1
;
CREATE TABLE `Administrador` (
   `ci` int (8) NOT NULL,
   `Nombre` varchar(50) NOT NULL,
   `Apellido` varchar(50) NOT NULL,
   `Genero` enum('masculino','femenino','otro') DEFAULT NULL,
   `Email` varchar(50) NOT NULL,
   `Telefono` int(9) unsigned zerofill DEFAULT NULL,
   `Telefono2` int(9) unsigned zerofill DEFAULT NULL,
   `Fnac` date DEFAULT NULL,
   `FormHoraria` varchar(50) NOT NULL,
   PRIMARY KEY (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Acompañante` (
   `ci` int (8) NOT NULL,
   `Nombre` varchar(50) NOT NULL,
   `ApellidoUno` varchar(50) NOT NULL,
   `ApellidoDos` varchar(50) NOT NULL,
   `Genero` enum('masculino','femenino','otro') DEFAULT NULL,
   `Direccion` varchar(50) NOT NULL,
   `Email` varchar(50) NOT NULL,
   `Telefono` varchar(50) NOT NULL,
   `Fnac` date DEFAULT NULL,
   `Nacionalidad` varchar(50) NOT NULL,
   PRIMARY KEY (`ci`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
;
CREATE TABLE `Anamnesis` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `ide` int(11) DEFAULT NULL,
   `Motivo` varchar(500) DEFAULT NULL,
   `Sintomas` varchar(100) DEFAULT NULL,
   `EnfermedadActual` varchar(100) DEFAULT NULL,
   `AntecedentesPersonales` varchar(300) DEFAULT NULL,
   `AntecedentesFamiliares` varchar(300) DEFAULT NULL,
   `Banderas` varchar(100) DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `ide` (`ide`),
   CONSTRAINT `Anamnesis_ibfk_1` FOREIGN KEY (`ide`) REFERENCES `EntrevistaI` (`ide`)
 ) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1

;
CREATE TABLE `Examen` (
   `id` int(11) NOT NULL AUTO_INCREMENT,
   `ide` int(11) DEFAULT NULL,
   `Inspeccion` varchar(500) DEFAULT NULL,
   `Palpacion` varchar(100) DEFAULT NULL,
   `Percusion` varchar(100) DEFAULT NULL,
   `Auscultacion` varchar(100) DEFAULT NULL,
   `Olfaccion` varchar(100) DEFAULT NULL,
   `Tipo` varchar(100) DEFAULT NULL,
   `Resultado` varchar(100) DEFAULT NULL,
   PRIMARY KEY (`id`),
   KEY `ide` (`ide`),
   CONSTRAINT `Examen_ibfk_1` FOREIGN KEY (`ide`) REFERENCES `EntrevistaI` (`ide`)
 ) ENGINE=InnoDB DEFAULT CHARSET=latin1 
 ;
 
 
####################################################################################################################################
#																									                               #
#     PERMISOS              PERMISOS                 PERMISOS            PERMISOS               PERMISOS          PERMISOS         #
#																																   #
#################################################################################################################################### 
    
    
 --                          ADMINISTRADOR                        --
  
grant all on suscipioratio.Usuarios to 'suscipio_adm' @'%';
grant all on suscipioratio.Administrador to 'suscipio_adm' @'%';
grant all on suscipioratio.Medico to 'suscipio_adm' @'%';
grant all on suscipioratio.Usuario to 'suscipio_adm' @'%';
grant all on suscipioratio.Paciente to 'suscipio_adm' @'%';
grant all on suscipioratio.Acompañante to 'suscipio_adm' @'%';
grant all on suscipioratio.Auxiliar to 'suscipio_adm' @'%';
grant all on suscipioratio.Personal to 'suscipio_adm' @'%';

grant all on suscipioratio.Consulta to 'suscipio_adm' @'%';
grant all on suscipioratio.Agenda to 'suscipio_adm' @'%';
grant all on suscipioratio.Enfermedad to 'suscipio_adm' @'%';
 --  ------------------------------------------------------------- --
 
 
 --                         MEDICO                                --
grant all on suscipioratio.* to 'suscipio_med' @'%';
revoke all on suscipioratio.Usuarios from 'suscipio.med' @'%';
revoke all on suscipioratio.Administrador from 'suscipio.med' @'%';
revoke all on suscipioratio.Medico from 'suscipio.med' @'%';
revoke all on suscipioratio.Paciente from 'suscipio.med' @'%';
revoke all on suscipioratio.Acompañante from 'suscipio.med' @'%';
revoke all on suscipioratio.Auxiliar from 'suscipio.med' @'%';
revoke all on suscipioratio.Personal from 'suscipio.med' @'%';

revoke all on suscipioratio.Consulta from 'suscipio.med' @'%';
revoke all on suscipioratio.Agenda from 'suscipio.med' @'%';
revoke all on suscipioratio.Enfermedad from 'suscipio.med' @'%';
 -- ------------------------------------------------------------- --
 
 
 --                         AXUILIAR                              --
 grant all on suscipioratio.* to 'suscipio_aux' @'%';
revoke all on suscipioratio.Usuarios from 'suscipio.aux' @'%';
revoke all on suscipioratio.Administrador from 'suscipio.aux' @'%';
revoke all on suscipioratio.Medico from 'suscipio.aux' @'%';
revoke all on suscipioratio.Paciente from 'suscipio.aux' @'%';
revoke all on suscipioratio.Acompañante from 'suscipio.aux' @'%';
revoke all on suscipioratio.Auxiliar from 'suscipio.aux' @'%';
revoke all on suscipioratio.Personal from 'suscipio.aux' @'%';

revoke all on suscipioratio.Consulta from 'suscipio.aux' @'%';
revoke all on suscipioratio.Agenda from 'suscipio.aux' @'%';
revoke all on suscipioratio.Enfermedad from 'suscipio.aux' @'%';
 -- ------------------------------------------------------------- --
 
 
 
 
 
 
 
 
 
 
 
 