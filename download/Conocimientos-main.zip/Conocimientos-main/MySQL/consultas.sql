##                         1                                               ##
select Tipo_de_Usuario, Cantidad, count(Tipo_de_Usuario)
from Usuarios
order by Tipo_de_Usuario asc;


##                         2                                           ##
select Especialidad, Cantidad, count(Especialidad)
from Medico 
order by Cantidad desc;


##                           3                                               ##
select Cantidad, Nombre_Tratamiento, count(Cantidad)
from Tratamiento 
where month(now()) -1 
order by Cantidad desc;


##                                   4                                            ##
select Cantidad, Nombre_Diagnóstico, count(Cantidad)
from Diagnostico 
where month(now()) -1 
order by Cantidad desc ;


##                                         5                                                ##
select  Fecha, Paciente, Motivo_de_la_consulta 
from Medico 
where ci = '56350574' 
and month(now()) -1
order by datetime;


##                                                  6                                              ##
select Fecha, Médico, Motivo_de_la_consulta 
from Paciente 
where ci = '56350685' 
and year(now()) -1
order by datetime;

##                                                          7                                              ##
select  Fecha, Médico, Paciente, Motivo_de_la_consulta 
from Acompañante left join Consulta on Acompañante.ci = Consulta.ci
where ci = '56350796' 
and month(now()) -1 
order by datetime;

##                                                                  8                                              ##
select NombreCompleto, DatosDeContacto 
from Medico left join Consultas on Medico.ci = Consulta.ci
where Consultas = null 
and month(now()) -3
and month(now()) -2
and month(now()) -1;

##                                                                           9                                          ##
select NombreCompleto, DatosDeContacto 
from Paciente left join Consulta on Paciente.ci = Consulta.ci
where Cantidad_de_Consultas = null 
and month(now()) -3
and month(now()) -2
and month(now()) -1;

##                                                                                10                                      ##
select NombreCompleto, DatosDeContacto, CantidadConsultas 
from Paciente 
order by CantidadConsultas asc 
limit 10;

##                                                                                        11                                  ##
select Cantidad_de_Consultas, NombreCompleto, count(Cantidad_de_Consultas) 
from Paciente left join Consulta on Paciente.ci = Consulta.ci 
where ifnull(0, 0) 
order by Cantidad_de_Consultas desc;

##                                                                                                 12                         ## 
select NombreCompleto, Cantidad_de_Consultas, count(Cantidad_de_Consultas) 
from Medico left join Consulta on Medico.ci = Consulta.ci 
where ifnull(0, 0)
order by Cantidad_de_Consultas desc;