##              1
select * from region order by nombre ASC;

##             2
select nombre, poblacion, superficie from territorio order by superficie DESC;

##              3
select nombre, poblacion from territorio where poblacion > 50000000 order by poblacion ASC;

##              4
select nombre, superficie, poblacion from territorio where superficie between 30000 and 70000 order by superficie DESC;

##             5
select oficial, capital, superficie, poblacion from territorio where nombre = 'Argentina'
union
select oficial, capital, superficie, poblacion from territorio where nombre = 'Uruguay'
union
select oficial, capital, superficie, poblacion from territorio where nombre = 'Bolivia'
union
select oficial, capital, superficie, poblacion from territorio where nombre = 'Brasil'
union
select oficial, capital, superficie, poblacion from territorio where nombre = 'Paraguay';

##            6
select oficial, capital from territorio where oficial like '%Estado%' order by nombre ASC;

##         7
select nombre, poblacion from territorio where nombre like 'A%a' order by nombre ASC;

##         8
select sum(poblacion) from territorio as alias_SumaPoblacio
union
select avg(poblacion) from territorio as alias_PromedioPoblacion
union
select count(idter) from territorio as alias_CantidadTerritorio;

##        9
select oficial, capital, poblacion from territorio where tipo = 'ultramar' order by oficial ASC;

##      10
select tipo from territorio group by tipo order by tipo ASC;

##      11

select * from territorio where nombre like '!isla' order by poblacion ASC limit 12