create database if not exists bvillalba;
use bvillalba;

create table if not exists Alumno(
ci char (8) not null primary key,
nombre varchar (10) not null,
apellido varchar (10) not null,
f_nac date,
sexo enum ('masculino','femenino','otro'),
idg varchar (10),
-- ----------------------------------------------------
foreign key (idg) references Grupo (idg));


create table if not exists Grupo(
idg varchar (10) not null primary key,
año char (3) unique,
curso varchar (10) unique,
letra varchar (10) unique,
turno enum ('matutino','verspetino','nocturno'));

create table if not exists Representa(
ci_coordinador char (8) not null unique,
ci_subcoordinador char (8) not null unique,
-- -------------------------------------------------------------------------------
foreign key (ci_coordinador) references GrupoProyecto (ci_coordinador),
foreign key (ci_subcoordinador) references GrupoProyecto (ci_subcoordinador));

create table if not exists GrupoProyecto(
idgp varchar (10) not null primary key,
nombre varchar (10) unique,
ci_coordinador char (8) not null unique,
ci_subcoordinador char (8) not null unique);

create table if not exists Integra(
ci char (8) not null unique,
idg varchar (10) not null unique,
-- ------------------------------------------------
foreign key (ci) references Alumno (ci),
foreign key (idg) references Grupo (idg));

-- _____________________________________________________________________________________________________________-----_____--__--__-___-___-_
drop table Grupo;

-- GRUPOS GRUPOS GRUPOS GRUPOS GRUPOS GRUPOS GRUPOS GRUPOSGRUPOS GRUPOS GRUPOS GRUPOSGRUPOS GRUPOS GRUPOS GRUPOSGRUPOS GRUPOS GRUPOS GRUPOS

insert into Grupo
(idg, año, curso, letra, turno)
values
("3ib", "tercero", "informatica", "b", "matutino");

insert into Grupo
(idg, año, curso, letra, turno)
values
("3ia", "tercero", "informatica", "a", "matutino");

insert into Grupo
(idg, año, curso, letra, turno)
values
("3ii", "tercero", "informatica", "i", "verspetino");

-- ---------------------------------------------------------

insert into GrupoProyecto
(idgp, nombre, ci_coordinador, ci_subcoordinador)
values
("3ii", "Sql", "12345678", "87654321");

insert into GrupoProyecto
(idgp, nombre, ci_coordinador, ci_subcoordinador)
values
("3ia", "cibernsake", "55555558", "22336688");

insert into GrupoProyecto
(idgp, nombre, ci_coordinador, ci_subcoordinador)
values
("3ib", "notdata", "33552277", "83746196");


 
-- ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS ALUMNOS

insert into Alumno
(ci, nombre, apellido, f_nac, sexo, idg)
values
("12345678", "Juan", "Ramirez", "2002-05-24", "masculino", "3ii");

insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("87654321", "Mateo", "Suarez", "2002-04-12", "masculino", "3ii");

insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("11223344", "Camilo", "Mateu", "2002-01-02", "masculino", "3ii");

insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("11335577", "Esperanza", "Rodriguez", "2002-11-11", "femenino", "3ii");




insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("55555558", "David", "Garcia", "2002-12-24", "masculino", "3ia");

insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("22336688", "Marcos", "Juarez", "2002-08-07", "masculino", "3ia");

insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("77776666", "Maria", "Herrera", "2002-08-07", "femenino", "3ia");

insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("66665555", "Tania", "Balsamo", "2002-08-07", "otro", "3ia");



insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("33552277", "Martin", "Mateu", "2002-09-27", "masculino", "3ib");

insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("83746196", "Eric", "Morales", "2002-01-02", "masculino", "3ib");

insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("92856471", "Sofia", "DeThales", "2002-06-19", "femenino", "3ib");

insert into Alumno
(ci, nombre,apellido, f_nac, sexo, idg)
values
("13578753", "Pablo", "DeSantos", "2002-02-08", "masculino", "3ib");